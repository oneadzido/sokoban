# ============================================================================
# Sokoban - ProGuard Rules
# ============================================================================
# 
# This ProGuard configuration file controls code shrinking, optimization, and
# obfuscation for the Sokoban app. The configuration follows a balanced
# approach focused on performance while maintaining debuggability.
# 
# <p>Balanced approach:</p>
# <ul>
#   <li>YES to performance optimizations (inlining, dead code removal)</li>
#   <li>NO to obfuscation (keep readable stack traces for crash reporting)</li>
#   <li>YES to resource shrinking (smaller APK size)</li>
# </ul>
#
# File Location: app/proguard-rules.pro
# 
# @author Richard Korbla Adzido
# @version 1.0.0
# @since 1.0
# ============================================================================

# ============================================================================
# Performance Optimizations
# ============================================================================
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes Exceptions,Signature,Deprecated,EnclosingMethod,InnerClasses

# ============================================================================
# IMPORTANT: Disable Obfuscation (keep readable stack traces)
# ============================================================================
-dontobfuscate
-dontusemixedcaseclassnames

# ============================================================================
# Keep all app classes (full package)
# ============================================================================
-keep class com.ark.sokoban.** { *; }
-keep interface com.ark.sokoban.** { *; }

# ============================================================================
# Keep Android Components
# ============================================================================
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.app.Dialog
-keep public class * extends android.view.View

# ============================================================================
# Keep Custom View Constructors
# ============================================================================
-keep public class * extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}

# ============================================================================
# Keep Serialization
# ============================================================================
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}

# ============================================================================
# Keep Parcelable
# ============================================================================
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# ============================================================================
# Keep Resource IDs
# ============================================================================
-keepclassmembers class **.R$* {
    public static <fields>;
}

# ============================================================================
# Third-party Libraries (AndroidX, Gson)
# ============================================================================
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**
-keep class com.google.gson.** { *; }
-dontwarn com.google.gson.**
-keep class android.media.** { *; }
-dontwarn android.media.**

# ============================================================================
# Performance: Remove verbose logging in release
# ============================================================================
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}