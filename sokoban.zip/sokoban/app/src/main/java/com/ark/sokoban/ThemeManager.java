package com.ark.sokoban;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

/**
 * Manages the app's theme mode.
 *
 * <p>The theme mode is one of three values — SYSTEM, LIGHT, or DARK —
 * stored under a single key in the shared preferences file the game
 * already uses. SYSTEM follows the device's light/dark setting; LIGHT
 * and DARK override it. The mode is applied to the whole app through
 * {@link AppCompatDelegate#setDefaultNightMode(int)}.</p>
 *
 * <p>The stored mode is read at startup and applied before the first
 * frame, so the app opens in the correct theme without a flash of the
 * wrong one. When the player taps the theme button, the mode advances
 * one step around the cycle and the new value is persisted. The cycle
 * is SYSTEM → LIGHT → DARK → SYSTEM.</p>
 *
 * <p>Each mode carries three things: the FontAwesome glyph that
 * represents it on the theme button, the AppCompatDelegate constant
 * that maps to it, and the string value persisted for it. Keeping
 * those three mappings inside the enum means callers never need a
 * switch over modes; they ask the enum.</p>
 *
 * File Location: app/src/main/java/com/ark/sokoban/ThemeManager.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class ThemeManager {

    // ========================================================================
    // Constants
    // ========================================================================

    /** SharedPreferences file name — the same file the game uses. */
    private static final String PREFS_NAME = "SokobanPrefs";

    /** Key under which the theme mode is stored. */
    private static final String KEY_THEME_MODE = "theme_mode";

    /** Stored value for the SYSTEM mode. */
    private static final String VALUE_SYSTEM = "system";

    /** Stored value for the LIGHT mode. */
    private static final String VALUE_LIGHT = "light";

    /** Stored value for the DARK mode. */
    private static final String VALUE_DARK = "dark";

    // ========================================================================
    // Mode
    // ========================================================================

    /**
     * The three theme modes the player can cycle through.
     *
     * <p>Each value carries its FontAwesome glyph, its AppCompatDelegate
     * constant, and the string value persisted for it. The {@link #next()}
     * method advances the cycle; the {@link #fromStoredValue(String)}
     * factory parses a stored string back into a mode.</p>
     */
    public enum Mode {
        /** Follow the device's light/dark setting. */
        SYSTEM(FontAwesome.SYSTEM, AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM, VALUE_SYSTEM),
        /** Force the light theme regardless of the device setting. */
        LIGHT(FontAwesome.SUN, AppCompatDelegate.MODE_NIGHT_NO, VALUE_LIGHT),
        /** Force the dark theme regardless of the device setting. */
        DARK(FontAwesome.MOON, AppCompatDelegate.MODE_NIGHT_YES, VALUE_DARK);

        private final String icon;
        private final int delegateMode;
        private final String storedValue;

        Mode(String icon, int delegateMode, String storedValue) {
            this.icon = icon;
            this.delegateMode = delegateMode;
            this.storedValue = storedValue;
        }

        /** Returns the FontAwesome glyph that represents this mode. */
        public String icon() {
            return icon;
        }

        /** Returns the AppCompatDelegate constant for this mode. */
        public int delegateMode() {
            return delegateMode;
        }

        /** Returns the string persisted for this mode. */
        public String storedValue() {
            return storedValue;
        }

        /** Returns the next mode in the cycle. */
        public Mode next() {
            switch (this) {
                case SYSTEM: return LIGHT;
                case LIGHT:  return DARK;
                case DARK:   return SYSTEM;
            }
            return SYSTEM;
        }

        /** Parses a stored value back into a Mode. Unknown values map to SYSTEM. */
        public static Mode fromStoredValue(String value) {
            if (VALUE_LIGHT.equals(value)) return LIGHT;
            if (VALUE_DARK.equals(value)) return DARK;
            return SYSTEM;
        }
    }

    // ========================================================================
    // Private Constructor
    // ========================================================================

    /**
     * Private constructor to prevent instantiation.
     *
     * <p>This class follows the utility class pattern and should never
     * be instantiated. All methods and fields are static.</p>
     */
    private ThemeManager() {
        // Private constructor to prevent instantiation
    }

    // ========================================================================
    // Public Methods
    // ========================================================================

    /**
     * Returns the currently stored theme mode. When no mode has been
     * stored, returns {@link Mode#SYSTEM}.
     *
     * @param context the application context
     * @return the stored mode, or SYSTEM when none has been stored
     */
    public static Mode getStoredMode(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME,
                Context.MODE_PRIVATE);
        String value = prefs.getString(KEY_THEME_MODE, null);
        return Mode.fromStoredValue(value);
    }

    /**
     * Stores the given theme mode.
     *
     * @param context the application context
     * @param mode the mode to store
     */
    public static void saveMode(Context context, Mode mode) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME,
                Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_THEME_MODE, mode.storedValue()).apply();
    }

    /**
     * Applies the stored theme mode to the whole app through
     * {@link AppCompatDelegate#setDefaultNightMode(int)}.
     *
     * <p>Calling this method triggers a configuration change and the
     * activity is recreated. The stored mode is read on the new
     * instance, so the correct theme is applied before the first frame.</p>
     *
     * @param context the application context
     */
    public static void applyStoredMode(Context context) {
        Mode mode = getStoredMode(context);
        AppCompatDelegate.setDefaultNightMode(mode.delegateMode());
    }
}