package com.ark.sokoban;

import com.ark.sokoban.models.Direction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * History of moves for undo functionality in the Sokoban game.
 * 
 * <p>This class stores the sequence of moves made by the player using a
 * <b>delta-based approach</b>. Instead of storing full game states for each
 * move, we store only the direction of each move. To undo, we replay all
 * moves from the beginning up to the desired point.</p>
 * 
 * <p>This is extremely memory-efficient and allows for unlimited undo
 * history. Moves are stored as {@link Direction} objects, which are small
 * enums, so keeping all moves has negligible memory cost.</p>
 * 
 * File Location: app/src/main/java/com/ark/sokoban/MoveHistory.java
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class MoveHistory implements Serializable {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Serial version UID for compatibility across versions. */
    private static final long serialVersionUID = 1L;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** List of move directions in chronological order. */
    private List<Direction> moves = new ArrayList<>();
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Adds a move to the history.
     *
     * @param direction The direction of the move
     * @return true if the move was added successfully
     */
    public boolean addMove(Direction direction) {
        if (direction == null) {
            return false;
        }
        moves.add(direction);
        return true;
    }
    
    /**
     * Removes and returns the last move from history.
     *
     * @return The last move direction, or null if history is empty
     */
    public Direction undoLastMove() {
        if (moves.isEmpty()) {
            return null;
        }
        return moves.remove(moves.size() - 1);
    }
    
    /**
     * Returns whether there are moves to undo.
     *
     * @return true if history is not empty
     */
    public boolean hasMoves() {
        return !moves.isEmpty();
    }
    
    /**
     * Returns the number of moves in history.
     *
     * @return The move count
     */
    public int size() {
        return moves.size();
    }
    
    /**
     * Returns a copy of all moves in chronological order.
     * 
     * <p>The returned list is a copy, so modifications to it will not
     * affect this history.</p>
     *
     * @return A list of Direction objects
     */
    public List<Direction> getAllMoves() {
        return new ArrayList<>(moves);
    }
    
    /**
     * Returns the move at the specified index (0-based).
     *
     * @param index The index of the move
     * @return The Direction at the index, or null if index is out of bounds
     */
    public Direction getMove(int index) {
        if (index < 0 || index >= moves.size()) {
            return null;
        }
        return moves.get(index);
    }
    
    /**
     * Clears all move history.
     */
    public void clear() {
        moves.clear();
    }
    
    /**
     * Returns whether the history is empty.
     *
     * @return true if no moves are stored
     */
    public boolean isEmpty() {
        return moves.isEmpty();
    }
    
    /**
     * Sets the history from a list of Directions.
     * 
     * <p>This is used when restoring history from a saved state.</p>
     *
     * @param records The list of Directions to restore
     */
    public void restoreFrom(List<Direction> records) {
        moves.clear();
        if (records != null) {
            moves.addAll(records);
        }
    }
    
    @Override
    public String toString() {
        return "MoveHistory{" + moves.size() + " moves}";
    }
}