package com.ark.sokoban;

import android.content.Context;
import android.graphics.Typeface;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Utility class for managing FontAwesome icon font for the Sokoban game.
 * 
 * <p>This class provides access to the FontAwesome font for displaying
 * vector icons in TextViews, Buttons, and Canvas drawings. The font
 * is loaded once from assets and reused throughout the application.</p>
 * 
 * <p>FontAwesome icons are displayed as Unicode characters that map to
 * specific glyphs in the font file. This approach allows for scalable,
 * colorable icons that can be styled with standard TextView properties.</p>
 * 
 * <p>Usage example:</p>
 * <pre>
 * // Initialize once at application start
 * FontAwesome.init(context);
 * 
 * // Use in a TextView
 * TextView icon = findViewById(R.id.icon);
 * icon.setTypeface(FontAwesome.getTypeface());
 * icon.setText(FontAwesome.WALL);
 * </pre>
 * 
 * <p>Follows Google's recommendations for utility class design with
 * private constructor and static methods only.</p>
 * 
 * @see Typeface
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class FontAwesome {
    
    // ========================================================================
    // Constants - Game Board Icons (Unicode)
    // ========================================================================
    
    /** Wall icon: "\uF1B2" - fa-cube (solid). */
    public static final String WALL = "\uF1B2";
    
    /** Target icon: "\uF140" - fa-bullseye (solid). */
    public static final String TARGET = "\uF140";
    
    /** Box icon: "\uF466" - fa-box (solid). */
    public static final String BOX = "\uF466";
    
    /** Player icon: "\uF007" - fa-user (solid). */
    public static final String PLAYER = "\uF007";
    
    // ========================================================================
    // Constants - UI Icons (Unicode)
    // ========================================================================
    
    /** Star icon: "\uF005" - fa-star (solid). */
    public static final String STAR = "\uF005";
    
    /** Pause icon: "\uF04C" - fa-pause (solid). */
    public static final String PAUSE = "\uF04C";
    
    /** Play icon: "\uF04B" - fa-play (solid). */
    public static final String PLAY = "\uF04B";
    
    /** Forward/Skip Next icon: "\uF04E" - fa-forward (solid). */
    public static final String FORWARD = "\uF04E";
    
    /** Backward/Skip Previous icon: "\uF04A" - fa-backward (solid). */
    public static final String BACKWARD = "\uF04A";
    
    /** Undo icon: "\uF0E2" - fa-undo (solid). */
    public static final String UNDO = "\uF0E2";
    
    /** Redo/Reset icon: "\uF01E" - fa-redo (solid). */
    public static final String REDO = "\uF01E";
    
    /** Trash icon: "\uF1F8" - fa-trash (solid). */
    public static final String TRASH = "\uF1F8";
    
    /** Arrow Up icon: "\uF062" - fa-arrow-up (solid). */
    public static final String ARROW_UP = "\uF062";
    
    /** Arrow Down icon: "\uF063" - fa-arrow-down (solid). */
    public static final String ARROW_DOWN = "\uF063";
    
    /** Arrow Left icon: "\uF060" - fa-arrow-left (solid). */
    public static final String ARROW_LEFT = "\uF060";
    
    /** Arrow Right icon: "\uF061" - fa-arrow-right (solid). */
    public static final String ARROW_RIGHT = "\uF061";
    
    /** Footsteps icon: "\uF17B" - fa-shoe-prints (solid). */
    public static final String FOOTSTEPS = "\uF17B";
    
    /** Clock icon: "\uF017" - fa-clock (solid). */
    public static final String CLOCK = "\uF017";
    
    /** Cube icon (for header): "\uF1B2" - fa-cube (solid). */
    public static final String CUBE = "\uF1B2";
    
    // ========================================================================
    // Static Variables
    // ========================================================================
    
    /** Cached Typeface instance for the FontAwesome font. */
    @Nullable
    private static Typeface sTypeface;
    
    // ========================================================================
    // Private Constructor
    // ========================================================================
    
    /**
     * Private constructor to prevent instantiation.
     * 
     * <p>This class follows the utility class pattern and should never
     * be instantiated. All methods and fields are static.</p>
     */
    private FontAwesome() {
        // Private constructor to prevent instantiation
    }
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Initializes the FontAwesome typeface by loading the font from assets.
     * 
     * <p>This method must be called before using FontAwesome icons.
     * It is typically called in the Application class onCreate() method,
     * or in the MainActivity onCreate() method.</p>
     * 
     * <p>If the font file is missing, the typeface remains null, and
     * icons will not render. The app will continue to function.</p>
     *
     * @param context The application context used to access assets.
     *                 Must not be null.
     */
    public static void init(@NonNull Context context) {
        if (sTypeface == null) {
            try {
                sTypeface = Typeface.createFromAsset(context.getAssets(), "fonts/fa-solid-900.ttf");
            } catch (Exception e) {
                // If font loading fails, typeface remains null - icons will show as blank
                // but the app will continue to function
            }
        }
    }
    
    /**
     * Returns the loaded FontAwesome typeface.
     * 
     * <p>Returns null if init() has not been called or if font loading failed.
     * Callers should handle null gracefully by falling back to default typeface.</p>
     *
     * @return The FontAwesome Typeface, or null if not loaded.
     */
    @Nullable
    public static Typeface getTypeface() {
        return sTypeface;
    }
}