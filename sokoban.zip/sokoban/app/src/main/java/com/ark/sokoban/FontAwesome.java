package com.ark.sokoban;

import android.content.Context;
import android.graphics.Typeface;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Utility class for managing FontAwesome icon font.
 * 
 * <p>This class provides access to the FontAwesome font for displaying
 * vector icons in TextViews and other text-based UI components. The font
 * is loaded once from assets and reused throughout the application.</p>
 * 
 * <p>FontAwesome icons are displayed as Unicode characters that map to
 * specific glyphs in the font file. This approach allows for scalable,
 * colorable icons that can be styled with standard TextView properties.</p>
 * 
 * <p>Usage example:
 * <pre>
 * // Initialize once at application start
 * FontAwesome.init(context);
 * 
 * // Use in a TextView
 * TextView icon = findViewById(R.id.icon);
 * icon.setTypeface(FontAwesome.getTypeface());
 * icon.setText(FontAwesome.PLAY);
 * </pre>
 * </p>
 * 
 * <p>Follows Google's recommendations for utility class design with
 * private constructor and static methods only.</p>
 * 
 * @see Typeface
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class FontAwesome {
    
    // ========================================================================
    // Constants - Sokoban Game Controls
    // ========================================================================
    
    /** Reset Game icon: "\uF363" - Solid circular arrows. */
    public static final String RESET_GAME = "\uF363";
    
    /** Previous Level icon: "\uF04A" - Solid double left chevrons. */
    public static final String PREVIOUS_LEVEL = "\uF04A";
    
    /** Pause icon: "\uF04C" - Solid pause bars. */
    public static final String PAUSE = "\uF04C";
    
    /** Resume icon: "\uF04B" - Solid play triangle. */
    public static final String RESUME = "\uF04B";
    
    /** Next Level icon: "\uF04E" - Solid double right chevrons. */
    public static final String NEXT_LEVEL = "\uF04E";
    
    /** Reset Level icon: "\uF2F1" - Solid converging circular arrows. */
    public static final String RESET_LEVEL = "\uF2F1";
    
    /** Undo Move icon: "\uF0E2" - Solid undo arrow. */
    public static final String UNDO = "\uF0E2";
    
    // ========================================================================
    // Constants - D-Pad Controls
    // ========================================================================
    
    /** D-Pad Up icon: "\uF077" - Solid chevron up. */
    public static final String DPAD_UP = "\uF077";
    
    /** D-Pad Down icon: "\uF078" - Solid chevron down. */
    public static final String DPAD_DOWN = "\uF078";
    
    /** D-Pad Left icon: "\uF053" - Solid chevron left. */
    public static final String DPAD_LEFT = "\uF053";
    
    /** D-Pad Right icon: "\uF054" - Solid chevron right. */
    public static final String DPAD_RIGHT = "\uF054";
    
    // ========================================================================
    // Constants - Overlay Icons
    // ========================================================================
    
    /** Star icon: "\uF005" - Solid star (used for level completion overlay). */
    public static final String STAR = "\uF005";
    
    // ========================================================================
    // Static Variables
    // ========================================================================
    
    /** Cached Typeface instance for the FontAwesome font. */
    @Nullable
    private static Typeface sTypeface;
    
    // ========================================================================
    // Private Constructor
    // ========================================================================
    
    /**
     * Private constructor to prevent instantiation.
     * 
     * <p>This class follows the utility class pattern and should never
     * be instantiated. All methods and fields are static.</p>
     */
    private FontAwesome() {
        // Private constructor to prevent instantiation
    }
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Initializes the FontAwesome typeface by loading the font from assets.
     * 
     * <p>This method must be called before using FontAwesome icons.
     * It is typically called in the Application class onCreate() method.</p>
     *
     * @param context The application context used to access assets
     */
    public static void init(@NonNull Context context) {
        if (sTypeface == null) {
            try {
                sTypeface = Typeface.createFromAsset(context.getAssets(), "fonts/fa-solid-900.ttf");
            } catch (Exception e) {
                // If font loading fails, typeface remains null - icons will show as blank
                // but the app will continue to function
            }
        }
    }
    
    /**
     * Returns the loaded FontAwesome typeface.
     * 
     * <p>Returns null if init() has not been called or if font loading failed.
     * Callers should handle null gracefully by falling back to default typeface.</p>
     *
     * @return The FontAwesome Typeface, or null if not loaded
     */
    @Nullable
    public static Typeface getTypeface() {
        return sTypeface;
    }
}