package com.ark.sokoban.utils;

import com.ark.sokoban.models.CellType;
import com.ark.sokoban.models.Direction;

/**
 * Utility class for grid operations in the Sokoban game.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 */
public final class GridUtils {
    
    private GridUtils() {
        // Utility class - prevent instantiation
    }
    
    /**
     * Creates a deep copy of a 2D grid.
     * 
     * @param grid The source grid
     * @return A deep copy, or null if grid is null
     */
    public static int[][] copyGrid(int[][] grid) {
        if (grid == null) return null;
        int[][] copy = new int[grid.length][];
        for (int i = 0; i < grid.length; i++) {
            copy[i] = grid[i].clone();
        }
        return copy;
    }
    
    /**
     * Checks if a position is within the grid bounds.
     * 
     * @param grid The grid
     * @param row The row index
     * @param col The column index
     * @return True if the position is valid
     */
    public static boolean isValidPosition(int[][] grid, int row, int col) {
        return grid != null && 
               row >= 0 && row < grid.length && 
               col >= 0 && col < grid[0].length;
    }
    
    /**
     * Gets the cell type at a position.
     * 
     * @param grid The grid
     * @param row The row index
     * @param col The column index
     * @return The CellType, or null if position is invalid
     */
    public static CellType getCellType(int[][] grid, int row, int col) {
        if (!isValidPosition(grid, row, col)) {
            return null;
        }
        return CellType.fromValue(grid[row][col]);
    }
    
    /**
     * Checks if a position contains a wall.
     * 
     * @param grid The grid
     * @param row The row index
     * @param col The column index
     * @return True if the cell is a wall
     */
    public static boolean isWall(int[][] grid, int row, int col) {
        CellType type = getCellType(grid, row, col);
        return type != null && type.isWall();
    }
    
    /**
     * Checks if a position is traversable (not a wall).
     * 
     * @param grid The grid
     * @param row The row index
     * @param col The column index
     * @return True if the cell is traversable
     */
    public static boolean isTraversable(int[][] grid, int row, int col) {
        CellType type = getCellType(grid, row, col);
        return type != null && type.isTraversable();
    }
    
    /**
     * Counts the number of remaining goals in the grid.
     * 
     * @param grid The grid
     * @return The number of remaining goals
     */
    public static int countRemainingGoals(int[][] grid) {
        if (grid == null) return 0;
        int count = 0;
        for (int[] row : grid) {
            for (int cell : row) {
                if (cell == CellType.GOAL.getValue()) {
                    count++;
                }
            }
        }
        return count;
    }
    
    /**
     * Counts the total number of goals in the grid (including covered ones).
     * 
     * @param grid The grid
     * @return The total number of goals
     */
    public static int countTotalGoals(int[][] grid) {
        if (grid == null) return 0;
        int count = 0;
        for (int[] row : grid) {
            for (int cell : row) {
                if (cell == CellType.GOAL.getValue() || 
                    cell == CellType.BOX_ON_GOAL.getValue() || 
                    cell == CellType.PLAYER_ON_GOAL.getValue()) {
                    count++;
                }
            }
        }
        return count;
    }
    
    /**
     * Finds the player position in the grid.
     * 
     * @param grid The grid
     * @return An array [row, col] or null if player not found
     */
    public static int[] findPlayer(int[][] grid) {
        if (grid == null) return null;
        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                int val = grid[r][c];
                if (val == CellType.PLAYER.getValue() || 
                    val == CellType.PLAYER_ON_GOAL.getValue()) {
                    return new int[]{r, c};
                }
            }
        }
        return null;
    }
    
    /**
     * Checks if the level is completed (no remaining goals).
     * 
     * @param grid The grid
     * @return True if all goals are covered
     */
    public static boolean isLevelCompleted(int[][] grid) {
        return countRemainingGoals(grid) == 0;
    }
    
    /**
     * Validates that a grid has consistent dimensions.
     * 
     * @param grid The grid to validate
     * @return True if the grid is valid
     */
    public static boolean validateGrid(int[][] grid) {
        if (grid == null || grid.length == 0) return false;
        int cols = grid[0].length;
        for (int[] row : grid) {
            if (row.length != cols) {
                return false;
            }
        }
        return true;
    }
}