package com.ark.sokoban.utils;

import com.ark.sokoban.models.CellType;

/**
 * Utility class for grid operations in the Sokoban game.
 * 
 * <p>This class provides static utility methods for common grid operations
 * such as copying, validation, finding the player position, and counting
 * goals. All methods are static and the class cannot be instantiated.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class GridUtils {
    
    /**
     * Private constructor to prevent instantiation.
     * This class follows the utility class pattern.
     */
    private GridUtils() {
        // Utility class - prevent instantiation
    }
    
    /**
     * Creates a deep copy of a 2D grid.
     * 
     * @param grid The source grid to copy
     * @return A deep copy of the grid, or null if input is null
     */
    public static int[][] copyGrid(int[][] grid) {
        if (grid == null) return null;
        int[][] copy = new int[grid.length][];
        for (int i = 0; i < grid.length; i++) {
            copy[i] = grid[i].clone();
        }
        return copy;
    }
    
    /**
     * Checks if a position is within the grid bounds.
     * 
     * @param grid The grid to check against
     * @param row The row index to validate
     * @param col The column index to validate
     * @return True if the position is valid, false otherwise
     */
    public static boolean isValidPosition(int[][] grid, int row, int col) {
        return grid != null && 
               row >= 0 && row < grid.length && 
               col >= 0 && col < grid[0].length;
    }
    
    /**
     * Gets the cell type at a position.
     * 
     * @param grid The grid to query
     * @param row The row index
     * @param col The column index
     * @return The CellType at the position, or null if position is invalid
     */
    public static CellType getCellType(int[][] grid, int row, int col) {
        if (!isValidPosition(grid, row, col)) {
            return null;
        }
        return CellType.fromValue(grid[row][col]);
    }
    
    /**
     * Checks if a position contains a wall.
     * 
     * @param grid The grid to query
     * @param row The row index
     * @param col The column index
     * @return True if the cell is a wall, false otherwise
     */
    public static boolean isWall(int[][] grid, int row, int col) {
        CellType type = getCellType(grid, row, col);
        return type != null && type.isWall();
    }
    
    /**
     * Checks if a position is traversable (not a wall).
     * 
     * @param grid The grid to query
     * @param row The row index
     * @param col The column index
     * @return True if the cell is traversable, false otherwise
     */
    public static boolean isTraversable(int[][] grid, int row, int col) {
        CellType type = getCellType(grid, row, col);
        return type != null && type.isTraversable();
    }
    
    /**
     * Counts the number of remaining goals in the grid.
     * Goals are represented by cell value 2.
     * 
     * @param grid The grid to count goals in
     * @return The number of remaining goals, or 0 if grid is null
     */
    public static int countRemainingGoals(int[][] grid) {
        if (grid == null) return 0;
        int count = 0;
        for (int[] row : grid) {
            for (int cell : row) {
                if (cell == CellType.GOAL.getValue()) {
                    count++;
                }
            }
        }
        return count;
    }
    
    /**
     * Counts the total number of goals in the grid (including covered ones).
     * 
     * @param grid The grid to count goals in
     * @return The total number of goals, or 0 if grid is null
     */
    public static int countTotalGoals(int[][] grid) {
        if (grid == null) return 0;
        int count = 0;
        for (int[] row : grid) {
            for (int cell : row) {
                if (cell == CellType.GOAL.getValue() || 
                    cell == CellType.BOX_ON_GOAL.getValue() || 
                    cell == CellType.PLAYER_ON_GOAL.getValue()) {
                    count++;
                }
            }
        }
        return count;
    }
    
    /**
     * Finds the player position in the grid.
     * 
     * @param grid The grid to search
     * @return An array [row, col] containing the player position, or null if not found
     */
    public static int[] findPlayer(int[][] grid) {
        if (grid == null) return null;
        for (int r = 0; r < grid.length; r++) {
            for (int c = 0; c < grid[0].length; c++) {
                int val = grid[r][c];
                if (val == CellType.PLAYER.getValue() || 
                    val == CellType.PLAYER_ON_GOAL.getValue()) {
                    return new int[]{r, c};
                }
            }
        }
        return null;
    }
    
    /**
     * Checks if the level is completed (no remaining goals).
     * 
     * @param grid The grid to check
     * @return True if all goals are covered, false otherwise
     */
    public static boolean isLevelCompleted(int[][] grid) {
        return countRemainingGoals(grid) == 0;
    }
    
    /**
     * Validates that a grid has consistent dimensions.
     * 
     * @param grid The grid to validate
     * @return True if the grid is valid (non-null and all rows have same length)
     */
    public static boolean validateGrid(int[][] grid) {
        if (grid == null || grid.length == 0) return false;
        int cols = grid[0].length;
        for (int[] row : grid) {
            if (row.length != cols) {
                return false;
            }
        }
        return true;
    }
}