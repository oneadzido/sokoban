package com.ark.sokoban;

import android.content.res.AssetManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for parsing Sokoban level files (.sbl format).
 * 
 * <p>This class reads a level file from assets, parses it line by line,
 * and converts each level into a 2D integer grid. The format follows
 * the standard Sokoban level definition:</p>
 * 
 * <ul>
 *   <li><code>#</code> - Wall</li>
 *   <li><code>.</code> - Goal (target)</li>
 *   <li><code>$</code> - Box</li>
 *   <li><code>@</code> - Player</li>
 *   <li><code>*</code> - Box on goal</li>
 *   <li><code>+</code> - Player on goal</li>
 *   <li><code> </code> (space) - Floor</li>
 * </ul>
 * 
 * <p>Levels are separated by comment lines starting with <code>;</code>.</p>
 * 
 * <p>All methods are static – this is a utility class.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class LevelParser {
    
    // ========================================================================
    // Private Constructor
    // ========================================================================
    
    /**
     * Private constructor to prevent instantiation.
     * This class is a utility and should never be instantiated.
     */
    private LevelParser() {
        // Utility class
    }
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Loads all levels from the given asset file.
     * 
     * <p>This method reads the file line by line, collects rows for each level,
     * and parses them into integer grids. Each grid is returned as a 2D array.</p>
     * 
     * <p>The file is expected to be in the <code>assets/</code> folder.</p>
     *
     * @param assetManager The AssetManager used to open the file.
     *                     Must not be null.
     * @param fileName The name of the file in the assets folder (e.g., "original.sbl").
     *                 Must not be null or empty.
     * @return A list of 2D integer arrays, each representing a level.
     *         Returns an empty list if the file contains no levels.
     * @throws Exception If the file cannot be read, is malformed, or
     *                   any IO error occurs.
     */
    public static List<int[][]> loadLevelsFromAsset(AssetManager assetManager, String fileName) throws Exception {
        List<int[][]> levelList = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(assetManager.open(fileName)));
        StringBuilder currentLevelBuilder = new StringBuilder();
        String line;

        while ((line = reader.readLine()) != null) {
            // Remove trailing whitespace
            line = line.replaceFirst("\\s+$", "");
            
            // Comment line: start of a new level
            if (line.startsWith(";")) {
                if (currentLevelBuilder.length() > 0) {
                    levelList.add(parseLevelString(currentLevelBuilder.toString()));
                    currentLevelBuilder.setLength(0);
                }
                continue;
            }
            
            // Skip empty lines
            if (line.trim().isEmpty()) continue;
            
            // Level row: contains Sokoban characters
            if (line.matches("^[# @$.*+\\-].*") || line.startsWith(" ")) {
                currentLevelBuilder.append(line).append("\n");
            } else {
                // If we encounter something else, treat as a separator
                if (currentLevelBuilder.length() > 0) {
                    levelList.add(parseLevelString(currentLevelBuilder.toString()));
                    currentLevelBuilder.setLength(0);
                }
            }
        }
        
        // Add the last level if any
        if (currentLevelBuilder.length() > 0) {
            levelList.add(parseLevelString(currentLevelBuilder.toString()));
        }
        
        reader.close();
        return levelList;
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Parses a level string into a 2D integer grid.
     * 
     * <p>The level string is split into rows. Each row is padded to the
     * maximum width using spaces. Each character is then mapped to an
     * integer value according to the Sokoban encoding.</p>
     *
     * @param levelText The full text of a single level, with rows separated by newline.
     *                  Must not be null.
     * @return A 2D integer array representing the level grid.
     */
    private static int[][] parseLevelString(String levelText) {
        String[] rows = levelText.split("\n");
        int height = rows.length;
        int width = 0;
        
        // Find the maximum row width
        for (String row : rows) {
            width = Math.max(width, row.length());
        }
        
        int[][] grid = new int[height][width];
        
        for (int rowIndex = 0; rowIndex < height; rowIndex++) {
            String row = rows[rowIndex];
            for (int colIndex = 0; colIndex < width; colIndex++) {
                char character = colIndex < row.length() ? row.charAt(colIndex) : ' ';
                switch (character) {
                    case '#':
                        grid[rowIndex][colIndex] = 1; // wall
                        break;
                    case '.':
                        grid[rowIndex][colIndex] = 2; // goal
                        break;
                    case '$':
                        grid[rowIndex][colIndex] = 3; // box
                        break;
                    case '@':
                        grid[rowIndex][colIndex] = 4; // player
                        break;
                    case '*':
                        grid[rowIndex][colIndex] = 5; // box on goal
                        break;
                    case '+':
                        grid[rowIndex][colIndex] = 6; // player on goal
                        break;
                    default:
                        grid[rowIndex][colIndex] = 0; // floor
                        break;
                }
            }
        }
        return grid;
    }
}