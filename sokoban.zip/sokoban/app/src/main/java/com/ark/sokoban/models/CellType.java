package com.ark.sokoban.models;

/**
 * Represents the types of cells in the Sokoban game grid.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 */
public enum CellType {
    FLOOR(0, " "),
    WALL(1, "#"),
    GOAL(2, "."),
    BOX(3, "$"),
    PLAYER(4, "@"),
    BOX_ON_GOAL(5, "*"),
    PLAYER_ON_GOAL(6, "+");
    
    private final int value;
    private final String symbol;
    
    CellType(int value, String symbol) {
        this.value = value;
        this.symbol = symbol;
    }
    
    public int getValue() {
        return value;
    }
    
    public String getSymbol() {
        return symbol;
    }
    
    /**
     * Converts a symbol character to a CellType.
     * 
     * @param symbol The symbol character
     * @return The corresponding CellType, or FLOOR if unknown
     */
    public static CellType fromSymbol(char symbol) {
        for (CellType type : values()) {
            if (type.symbol.charAt(0) == symbol) {
                return type;
            }
        }
        return FLOOR;
    }
    
    /**
     * Converts an integer value to a CellType.
     * 
     * @param value The integer value
     * @return The corresponding CellType, or FLOOR if unknown
     */
    public static CellType fromValue(int value) {
        for (CellType type : values()) {
            if (type.value == value) {
                return type;
            }
        }
        return FLOOR;
    }
    
    /**
     * Checks if this cell type is a wall.
     */
    public boolean isWall() {
        return this == WALL;
    }
    
    /**
     * Checks if this cell type is a goal.
     */
    public boolean isGoal() {
        return this == GOAL || this == BOX_ON_GOAL || this == PLAYER_ON_GOAL;
    }
    
    /**
     * Checks if this cell type is a box.
     */
    public boolean isBox() {
        return this == BOX || this == BOX_ON_GOAL;
    }
    
    /**
     * Checks if this cell type is a player.
     */
    public boolean isPlayer() {
        return this == PLAYER || this == PLAYER_ON_GOAL;
    }
    
    /**
     * Checks if this cell type is traversable (not a wall).
     */
    public boolean isTraversable() {
        return this != WALL;
    }
}