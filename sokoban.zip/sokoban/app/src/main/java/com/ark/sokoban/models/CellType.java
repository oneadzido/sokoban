package com.ark.sokoban.models;

/**
 * Represents the types of cells in the Sokoban game grid.
 * 
 * <p>This enum defines all possible cell types in a Sokoban level,
 * each with an associated integer value and symbol character. The
 * values correspond to the standard Sokoban encoding used in .sbl files.</p>
 * 
 * <p>Cell values:</p>
 * <ul>
 *   <li>0 - FLOOR: Empty traversable space</li>
 *   <li>1 - WALL: Impassable barrier</li>
 *   <li>2 - GOAL: Target location for boxes</li>
 *   <li>3 - BOX: Pushable object</li>
 *   <li>4 - PLAYER: Player character</li>
 *   <li>5 - BOX_ON_GOAL: Box correctly placed on a goal</li>
 *   <li>6 - PLAYER_ON_GOAL: Player standing on a goal</li>
 * </ul>
 * 
 * File Location: app/src/main/java/com/ark/sokoban/models/CellType.java
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public enum CellType {
    
    // ========================================================================
    // Enum Constants
    // ========================================================================
    
    /** Empty traversable space. */
    FLOOR(0, " "),
    
    /** Impassable barrier. */
    WALL(1, "#"),
    
    /** Target location for boxes. */
    GOAL(2, "."),
    
    /** Pushable object. */
    BOX(3, "$"),
    
    /** Player character. */
    PLAYER(4, "@"),
    
    /** Box correctly placed on a goal. */
    BOX_ON_GOAL(5, "*"),
    
    /** Player standing on a goal. */
    PLAYER_ON_GOAL(6, "+");
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** The integer value representing this cell type. */
    private final int value;
    
    /** The symbol character used in level files. */
    private final String symbol;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new CellType.
     *
     * @param value The integer value
     * @param symbol The symbol character
     */
    CellType(int value, String symbol) {
        this.value = value;
        this.symbol = symbol;
    }
    
    // ========================================================================
    // Getters
    // ========================================================================
    
    /**
     * Gets the integer value of this cell type.
     *
     * @return The integer value
     */
    public int getValue() {
        return value;
    }
    
    /**
     * Gets the symbol character of this cell type.
     *
     * @return The symbol string
     */
    public String getSymbol() {
        return symbol;
    }
    
    // ========================================================================
    // Static Factory Methods
    // ========================================================================
    
    /**
     * Converts a symbol character to a CellType.
     *
     * @param symbol The symbol character
     * @return The corresponding CellType, or FLOOR if unknown
     */
    public static CellType fromSymbol(char symbol) {
        for (CellType type : values()) {
            if (type.symbol.charAt(0) == symbol) {
                return type;
            }
        }
        return FLOOR;
    }
    
    /**
     * Converts an integer value to a CellType.
     *
     * @param value The integer value
     * @return The corresponding CellType, or FLOOR if unknown
     */
    public static CellType fromValue(int value) {
        for (CellType type : values()) {
            if (type.value == value) {
                return type;
            }
        }
        return FLOOR;
    }
    
    // ========================================================================
    // Type Checking Methods
    // ========================================================================
    
    /**
     * Checks if this cell type is a wall.
     *
     * @return True if this is a WALL
     */
    public boolean isWall() {
        return this == WALL;
    }
    
    /**
     * Checks if this cell type is a goal (including covered goals).
     *
     * @return True if this is GOAL, BOX_ON_GOAL, or PLAYER_ON_GOAL
     */
    public boolean isGoal() {
        return this == GOAL || this == BOX_ON_GOAL || this == PLAYER_ON_GOAL;
    }
    
    /**
     * Checks if this cell type is a box (including boxes on goals).
     *
     * @return True if this is BOX or BOX_ON_GOAL
     */
    public boolean isBox() {
        return this == BOX || this == BOX_ON_GOAL;
    }
    
    /**
     * Checks if this cell type is a player (including players on goals).
     *
     * @return True if this is PLAYER or PLAYER_ON_GOAL
     */
    public boolean isPlayer() {
        return this == PLAYER || this == PLAYER_ON_GOAL;
    }
    
    /**
     * Checks if this cell type is traversable (not a wall).
     *
     * @return True if this is not a WALL
     */
    public boolean isTraversable() {
        return this != WALL;
    }
}