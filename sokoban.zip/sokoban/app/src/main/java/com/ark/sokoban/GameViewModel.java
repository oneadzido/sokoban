package com.ark.sokoban;

import android.app.Application;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ViewModel for the Sokoban game.
 * 
 * <p>This class holds all game state and business logic, following the
 * Model-View-ViewModel (MVVM) architecture. It exposes LiveData objects
 * for the UI to observe, and persists the game state using SharedPreferences
 * and Gson.</p>
 * 
 * <p>The ViewModel is lifecycle-aware and survives configuration changes
 * (e.g., screen rotation). It also handles the game timer, undo history,
 * level navigation, and save/restore.</p>
 * 
 * <p>Follows Google's recommendations for ViewModel design with
 * LiveData and lifecycle awareness.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameViewModel extends AndroidViewModel {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Shared preferences file name. */
    private static final String PREFS_NAME = "SokobanPrefs";
    
    /** Key for the saved game state. */
    private static final String KEY_SAVE_STATE = "save_state";
    
    // ========================================================================
    // Dependencies
    // ========================================================================
    
    /** SharedPreferences instance for saving/restoring state. */
    private final SharedPreferences sharedPreferences;
    
    /** Gson instance for JSON serialization. */
    private final Gson gson = new Gson();
    
    // ========================================================================
    // Level Data
    // ========================================================================
    
    /** List of all levels (each level is a 2D grid). */
    private List<int[][]> allLevels = new ArrayList<>();
    
    /** Total number of levels. */
    private int totalLevels = 0;
    
    // ========================================================================
    // LiveData State
    // ========================================================================
    
    /** Current level index (0-based). */
    private final MutableLiveData<Integer> currentLevelIndex = new MutableLiveData<>(0);
    
    /** The current grid state. */
    private final MutableLiveData<int[][]> grid = new MutableLiveData<>();
    
    /** Player row position. */
    private final MutableLiveData<Integer> playerRow = new MutableLiveData<>(0);
    
    /** Player column position. */
    private final MutableLiveData<Integer> playerCol = new MutableLiveData<>(0);
    
    /** Number of moves made. */
    private final MutableLiveData<Integer> moveCount = new MutableLiveData<>(0);
    
    /** Elapsed timer in seconds. */
    private final MutableLiveData<Integer> timerSeconds = new MutableLiveData<>(0);
    
    /** Whether the game is paused. */
    private final MutableLiveData<Boolean> isPaused = new MutableLiveData<>(false);
    
    /** Whether the current level is completed. */
    private final MutableLiveData<Boolean> isGameCompleted = new MutableLiveData<>(false);
    
    /** Set of completed level indices. */
    private final MutableLiveData<Set<Integer>> completedLevels = new MutableLiveData<>(new HashSet<>());
    
    // ========================================================================
    // Undo History
    // ========================================================================
    
    /** Stack of previous game states for undo functionality. */
    private List<GameState> history = new ArrayList<>();
    
    // ========================================================================
    // Timer
    // ========================================================================
    
    /** Whether the timer is currently running. */
    private boolean timerRunning = false;
    
    /** Handler for posting timer updates. */
    private final Handler timerHandler = new Handler(Looper.getMainLooper());
    
    /** Runnable that increments the timer every second. */
    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (timerRunning) {
                timerSeconds.setValue(timerSeconds.getValue() + 1);
                timerHandler.postDelayed(this, 1000);
            }
        }
    };
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs the ViewModel.
     *
     * @param application The application context. Must not be null.
     */
    public GameViewModel(@NonNull Application application) {
        super(application);
        sharedPreferences = application.getSharedPreferences(PREFS_NAME, Application.MODE_PRIVATE);
    }
    
    // ========================================================================
    // Level Loading
    // ========================================================================
    
    /**
     * Sets the list of levels and attempts to restore a saved state.
     * 
     * <p>If a saved state exists, it is restored. Otherwise, the first level
     * is loaded.</p>
     *
     * @param levels The list of level grids. Must not be null.
     */
    public void setLevels(List<int[][]> levels) {
        this.allLevels = levels;
        this.totalLevels = levels.size();
        if (totalLevels == 0) return;
        
        String json = sharedPreferences.getString(KEY_SAVE_STATE, null);
        if (json != null) {
            GameState savedState = gson.fromJson(json, GameState.class);
            if (savedState != null && savedState.currentLevelIndex >= 0 && savedState.currentLevelIndex < totalLevels) {
                currentLevelIndex.setValue(savedState.currentLevelIndex);
                grid.setValue(savedState.grid);
                playerRow.setValue(savedState.playerRow);
                playerCol.setValue(savedState.playerCol);
                moveCount.setValue(savedState.moveCount);
                timerSeconds.setValue(savedState.timerSeconds);
                
                Set<Integer> completed = new HashSet<>();
                for (int i = 0; i < savedState.completedLevels.length; i++) {
                    if (savedState.completedLevels[i]) completed.add(i);
                }
                completedLevels.setValue(completed);
                
                if (moveCount.getValue() > 0 && !isPaused.getValue() && !isGameCompleted.getValue()) {
                    startTimer();
                }
                return;
            }
        }
        currentLevelIndex.setValue(0);
        loadLevel(0, null);
    }
    
    /**
     * Loads a specific level, optionally restoring a saved grid.
     * 
     * <p>If savedGrid is provided, it is used directly; otherwise, a fresh
     * copy of the level is created from the original. The player position
     * is determined from the grid.</p>
     * 
     * <p>When loading a fresh level, player markers (value 4 or 6) are
     * converted to floor (0) or goal (2) respectively, and the player
     * position is stored separately.</p>
     *
     * @param levelIndex The index of the level to load (0-based).
     * @param savedGrid A previously saved grid (or null for fresh).
     *                  If provided, must match the dimensions of the original level.
     */
    public void loadLevel(int levelIndex, int[][] savedGrid) {
        if (levelIndex < 0 || levelIndex >= totalLevels) return;
        currentLevelIndex.setValue(levelIndex);
        
        int[][] original = allLevels.get(levelIndex);
        int height = original.length;
        int width = original[0].length;
        int[][] newGrid = new int[height][width];
        int playerR = -1, playerC = -1;
        
        if (savedGrid != null && savedGrid.length == height && savedGrid[0].length == width) {
            // Restore from saved grid
            for (int r = 0; r < height; r++) {
                System.arraycopy(savedGrid[r], 0, newGrid[r], 0, width);
            }
            // Find player in saved grid
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    if (newGrid[r][c] == 4 || newGrid[r][c] == 6) {
                        playerR = r;
                        playerC = c;
                        break;
                    }
                }
                if (playerR != -1) break;
            }
        } else {
            // Fresh copy from original - convert player markers
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    int val = original[r][c];
                    if (val == 4 || val == 6) {
                        playerR = r;
                        playerC = c;
                        newGrid[r][c] = (val == 6) ? 2 : 0;
                    } else {
                        newGrid[r][c] = val;
                    }
                }
            }
        }
        
        // If no player found, place at first empty floor
        if (playerR == -1) {
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    if (newGrid[r][c] == 0) {
                        playerR = r;
                        playerC = c;
                        break;
                    }
                }
                if (playerR != -1) break;
            }
        }
        
        // Ensure player is valid
        if (playerR == -1) {
            playerR = 0;
            playerC = 0;
        }
        
        grid.setValue(newGrid);
        playerRow.setValue(playerR);
        playerCol.setValue(playerC);
        moveCount.setValue(0);
        timerSeconds.setValue(0);
        isGameCompleted.setValue(false);
        history.clear();
        stopTimer();
    }
    
    // ========================================================================
    // Game Logic
    // ========================================================================
    
    /**
     * Attempts to move the player by the given delta.
     * 
     * <p>This method handles both walking and pushing boxes, updates the
     * grid and player position, checks for win condition, and saves the
     * state after each move.</p>
     * 
     * <p>If the move results in a win, the level is marked as completed
     * and the state is saved.</p>
     * 
     * <p>The grid is copied before modification to ensure the LiveData
     * observer is properly triggered.</p>
     *
     * @param deltaRow The change in row (-1, 0, 1). Must be between -1 and 1.
     * @param deltaCol The change in column (-1, 0, 1). Must be between -1 and 1.
     */
    public void attemptMove(int deltaRow, int deltaCol) {
        if (isPaused.getValue() || isGameCompleted.getValue()) return;
        
        int row = playerRow.getValue();
        int col = playerCol.getValue();
        int newRow = row + deltaRow;
        int newCol = col + deltaCol;
        
        int[][] currentGrid = grid.getValue();
        if (newRow < 0 || newRow >= currentGrid.length || newCol < 0 || newCol >= currentGrid[0].length) return;
        int target = currentGrid[newRow][newCol];
        if (target == 1) return;
        
        // Save state before moving
        GameState previousState = createStateSnapshot();
        history.add(previousState);
        
        // Create a copy to modify
        int[][] newGrid = copyGrid(currentGrid);
        boolean moved = false;
        
        // Pushing a box
        if (target == 3 || target == 5) {
            int boxNewRow = newRow + deltaRow;
            int boxNewCol = newCol + deltaCol;
            if (boxNewRow < 0 || boxNewRow >= newGrid.length || boxNewCol < 0 || boxNewCol >= newGrid[0].length) {
                history.remove(history.size() - 1);
                return;
            }
            int beyond = newGrid[boxNewRow][boxNewCol];
            
            // Box can only be pushed into empty floor or goal
            if (beyond == 0 || beyond == 2) {
                // Remove box from current position
                newGrid[newRow][newCol] = (target == 5) ? 2 : 0;
                // Place box in new position
                newGrid[boxNewRow][boxNewCol] = (beyond == 2) ? 5 : 3;
                
                // Move player
                playerRow.setValue(newRow);
                playerCol.setValue(newCol);
                moved = true;
            } else {
                history.remove(history.size() - 1);
                return;
            }
        } 
        // Walking into empty floor or goal
        else if (target == 0 || target == 2) {
            playerRow.setValue(newRow);
            playerCol.setValue(newCol);
            moved = true;
        }
        
        if (moved) {
            int newMoves = moveCount.getValue() + 1;
            moveCount.setValue(newMoves);
            if (newMoves == 1 && !timerRunning) startTimer();
            
            // Update grid (triggers observer)
            grid.setValue(newGrid);
            
            if (checkWin(newGrid)) {
                isGameCompleted.setValue(true);
                stopTimer();
                Set<Integer> completed = new HashSet<>(completedLevels.getValue());
                completed.add(currentLevelIndex.getValue());
                completedLevels.setValue(completed);
                saveState();
            }
            saveState();
        } else {
            // No move happened, remove the saved state from history
            history.remove(history.size() - 1);
        }
    }
    
    /**
     * Checks if the current grid has no remaining goals.
     *
     * @param grid The grid to check. Must not be null.
     * @return True if all goals are covered (i.e., no cell with value 2).
     */
    private boolean checkWin(int[][] grid) {
        for (int[] row : grid) {
            for (int cell : row) {
                if (cell == 2) return false;
            }
        }
        return true;
    }
    
    // ========================================================================
    // Undo
    // ========================================================================
    
    /**
     * Reverses the last move.
     * 
     * <p>Pops the last state from the history and restores it. The completed
     * levels set is not affected by undo.</p>
     */
    public void undoMove() {
        if (isPaused.getValue() || isGameCompleted.getValue() || history.isEmpty()) return;
        GameState previous = history.remove(history.size() - 1);
        restoreStateFromSnapshot(previous);
        saveState();
    }
    
    // ========================================================================
    // Reset
    // ========================================================================
    
    /**
     * Resets the current level to its initial state.
     * 
     * <p>Reloads the level from the original data. The completed status
     * of the level is not changed.</p>
     */
    public void resetCurrentLevel() {
        int index = currentLevelIndex.getValue();
        loadLevel(index, null);
        saveState();
    }
    
    /**
     * Resets the entire game: clears all progress, returns to level 1.
     * 
     * <p>Clears the completed levels set, resets the current level index
     * to 0, removes the saved state from SharedPreferences, and stops the
     * timer.</p>
     */
    public void resetEntireGame() {
        completedLevels.setValue(new HashSet<>());
        currentLevelIndex.setValue(0);
        loadLevel(0, null);
        sharedPreferences.edit().remove(KEY_SAVE_STATE).apply();
        stopTimer();
        timerSeconds.setValue(0);
    }
    
    // ========================================================================
    // Level Navigation
    // ========================================================================
    
    /**
     * Moves to the next level, or wraps to the first if at the end.
     * 
     * <p>Saves the current state before switching.</p>
     */
    public void goToNextLevel() {
        if (isPaused.getValue()) return;
        int index = currentLevelIndex.getValue();
        if (index < totalLevels - 1) {
            currentLevelIndex.setValue(index + 1);
            loadLevel(index + 1, null);
        } else {
            currentLevelIndex.setValue(0);
            loadLevel(0, null);
        }
        saveState();
    }
    
    /**
     * Moves to the previous level, if possible.
     * 
     * <p>Saves the current state before switching.</p>
     */
    public void goToPreviousLevel() {
        if (isPaused.getValue()) return;
        int index = currentLevelIndex.getValue();
        if (index > 0) {
            currentLevelIndex.setValue(index - 1);
            loadLevel(index - 1, null);
            saveState();
        }
    }
    
    // ========================================================================
    // Timer Control
    // ========================================================================
    
    /**
     * Starts the timer if not already running.
     * 
     * <p>The timer increments every second and updates the timerSeconds
     * LiveData.</p>
     */
    public void startTimer() {
        if (timerRunning) return;
        timerRunning = true;
        timerHandler.post(timerRunnable);
    }
    
    /**
     * Stops the timer.
     * 
     * <p>Removes any pending timer updates and sets the running flag to false.</p>
     */
    public void stopTimer() {
        timerRunning = false;
        timerHandler.removeCallbacks(timerRunnable);
    }
    
    // ========================================================================
    // Pause Toggle
    // ========================================================================
    
    /**
     * Toggles the pause state.
     * 
     * <p>If pausing, stops the timer. If resuming and there have been moves,
     * starts the timer.</p>
     */
    public void togglePause() {
        boolean paused = isPaused.getValue() != null && isPaused.getValue();
        isPaused.setValue(!paused);
        if (!paused) {
            stopTimer();
        } else {
            if (moveCount.getValue() > 0 && !isGameCompleted.getValue()) {
                startTimer();
            }
        }
        saveState();
    }
    
    // ========================================================================
    // Save / Restore Helpers
    // ========================================================================
    
    /**
     * Saves the current state to SharedPreferences.
     * 
     * <p>Creates a snapshot of the current state and stores it as a JSON
     * string using Gson.</p>
     */
    private void saveState() {
        GameState state = createStateSnapshot();
        String json = gson.toJson(state);
        sharedPreferences.edit().putString(KEY_SAVE_STATE, json).apply();
    }
    
    /**
     * Creates a snapshot of the current game state.
     *
     * @return A GameState object representing the current state.
     */
    private GameState createStateSnapshot() {
        GameState state = new GameState();
        state.currentLevelIndex = currentLevelIndex.getValue();
        state.grid = copyGrid(grid.getValue());
        state.playerRow = playerRow.getValue();
        state.playerCol = playerCol.getValue();
        state.moveCount = moveCount.getValue();
        state.timerSeconds = timerSeconds.getValue();
        int total = totalLevels;
        state.completedLevels = new boolean[total];
        Set<Integer> completed = completedLevels.getValue();
        for (int i = 0; i < total; i++) {
            state.completedLevels[i] = completed.contains(i);
        }
        return state;
    }
    
    /**
     * Restores the state from a snapshot (used for undo).
     *
     * @param state The GameState to restore. Must not be null.
     */
    private void restoreStateFromSnapshot(GameState state) {
        currentLevelIndex.setValue(state.currentLevelIndex);
        grid.setValue(state.grid);
        playerRow.setValue(state.playerRow);
        playerCol.setValue(state.playerCol);
        moveCount.setValue(state.moveCount);
        timerSeconds.setValue(state.timerSeconds);
        // Do not restore completed levels from undo
    }
    
    /**
     * Deep copies a 2D integer grid.
     *
     * @param src The source grid. May be null.
     * @return A deep copy of the grid, or null if src is null.
     */
    private int[][] copyGrid(int[][] src) {
        if (src == null) return null;
        int[][] copy = new int[src.length][];
        for (int i = 0; i < src.length; i++) {
            copy[i] = src[i].clone();
        }
        return copy;
    }
    
    // ========================================================================
    // Public Getters
    // ========================================================================
    
    /** Returns the current level index as LiveData. */
    public LiveData<Integer> getCurrentLevelIndex() { return currentLevelIndex; }
    
    /** Returns the current grid as LiveData. */
    public LiveData<int[][]> getGrid() { return grid; }
    
    /** Returns the player row as LiveData. */
    public LiveData<Integer> getPlayerRow() { return playerRow; }
    
    /** Returns the player column as LiveData. */
    public LiveData<Integer> getPlayerCol() { return playerCol; }
    
    /** Returns the move count as LiveData. */
    public LiveData<Integer> getMoveCount() { return moveCount; }
    
    /** Returns the timer seconds as LiveData. */
    public LiveData<Integer> getTimerSeconds() { return timerSeconds; }
    
    /** Returns the pause state as LiveData. */
    public LiveData<Boolean> getIsPaused() { return isPaused; }
    
    /** Returns the game completion state as LiveData. */
    public LiveData<Boolean> getIsGameCompleted() { return isGameCompleted; }
    
    /** Returns the set of completed levels as LiveData. */
    public LiveData<Set<Integer>> getCompletedLevels() { return completedLevels; }
    
    /** Returns the total number of levels. */
    public int getTotalLevels() { return totalLevels; }
    
    /**
     * Counts the number of remaining goals in the given grid.
     *
     * @param grid The grid to count goals in. Must not be null.
     * @return The number of remaining goals (cells with value 2).
     */
    public int countRemainingGoals(int[][] grid) {
        int count = 0;
        for (int[] row : grid) {
            for (int cell : row) {
                if (cell == 2) count++;
            }
        }
        return count;
    }
}