package com.ark.sokoban;

import android.app.Application;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.ark.sokoban.models.Direction;
import com.ark.sokoban.models.Level;
import com.ark.sokoban.repository.LevelRepository;
import com.ark.sokoban.utils.GridUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ViewModel for the Sokoban game.
 *
 * <p>This class manages all game state and logic, including level loading,
 * player movement, undo functionality, timer management, and state persistence.
 * It follows the MVVM architecture pattern.</p>
 *
 * <h3>Key Features:</h3>
 * <ul>
 *   <li>Level management with save/restore</li>
 *   <li>Player movement with box pushing</li>
 *   <li>Undo functionality with history</li>
 *   <li>Timer management</li>
 *   <li>Pause/Resume support</li>
 *   <li>State persistence via SharedPreferences</li>
 *   <li>Record stats tracking for completed levels (persists across app restarts)</li>
 *   <li>Atomic display state for consistent rendering</li>
 * </ul>
 *
 * <p>The {@link GameDisplayState} inner class bundles all rendering data
 * (grid, player position, completion status) into a single immutable object.
 * This ensures the UI always receives a consistent snapshot of the game state.</p>
 *
 * File Location: app/src/main/java/com/ark/sokoban/GameViewModel.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameViewModel extends AndroidViewModel {

    // ========================================================================
    // Constants
    // ========================================================================

    /** SharedPreferences name for game state. */
    private static final String PREFS_NAME = "SokobanPrefs";

    /** Key for saved game state in SharedPreferences. */
    private static final String KEY_SAVE_STATE = "save_state";

    /** Key prefix for record moves. */
    private static final String KEY_RECORD_MOVES = "record_moves_";

    /** Key prefix for record time. */
    private static final String KEY_RECORD_TIME = "record_time_";

    /** Maximum number of undo steps. */
    private static final int MAX_HISTORY = 100;

    // ========================================================================
    // Dependencies
    // ========================================================================

    /** SharedPreferences for persisting game state. */
    private final SharedPreferences sharedPreferences;

    /** Gson instance for JSON serialization. */
    private final Gson gson = new GsonBuilder().create();

    /** Repository for loading levels. */
    private final LevelRepository repository = new LevelRepository();

    // ========================================================================
    // Level Data
    // ========================================================================

    /** List of all levels loaded from assets. */
    private List<Level> levels = new ArrayList<>();

    /** Total number of levels available. */
    private int totalLevels = 0;

    // ========================================================================
    // State (LiveData)
    // ========================================================================

    /** Atomic game display state – used for rendering the board. */
    private final MutableLiveData<GameDisplayState> displayState = new MutableLiveData<>();

    /** Current level index (0-based). */
    private final MutableLiveData<Integer> currentLevelIndex = new MutableLiveData<>(0);

    /** Number of moves made in the current level. */
    private final MutableLiveData<Integer> moveCount = new MutableLiveData<>(0);

    /** Elapsed timer in seconds. */
    private final MutableLiveData<Integer> timerSeconds = new MutableLiveData<>(0);

    /** Pause state. */
    private final MutableLiveData<Boolean> isPaused = new MutableLiveData<>(false);

    /** Set of completed level indices. */
    private final MutableLiveData<Set<Integer>> completedLevels =
            new MutableLiveData<>(new HashSet<>());

    // ========================================================================
    // Internal State
    // ========================================================================

    /** History of states for undo functionality. */
    private List<GameState> history = new ArrayList<>();

    /** Timer running flag. */
    private boolean timerRunning = false;

    /** Handler for timer updates. */
    private final Handler timerHandler = new Handler(Looper.getMainLooper());

    /** Runnable for timer updates. */
    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (timerRunning) {
                timerSeconds.setValue(timerSeconds.getValue() + 1);
                timerHandler.postDelayed(this, 1000);
            }
        }
    };

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new GameViewModel.
     *
     * @param application The application context
     */
    public GameViewModel(@NonNull Application application) {
        super(application);
        this.sharedPreferences = application.getSharedPreferences(PREFS_NAME,
                Application.MODE_PRIVATE);
    }

    // ========================================================================
    // Level Loading
    // ========================================================================

    /**
     * Loads levels from the asset file and restores saved state if available.
     *
     * @param fileName The file name in the assets folder
     * @throws Exception If loading fails
     */
    public void loadLevels(String fileName) throws Exception {
        repository.loadLevels(getApplication().getAssets(), fileName);
        this.levels = repository.getAllLevels();
        this.totalLevels = levels.size();

        if (totalLevels == 0) return;

        // Try to restore saved state
        String json = sharedPreferences.getString(KEY_SAVE_STATE, null);
        if (json != null) {
            GameState savedState = gson.fromJson(json, GameState.class);
            if (savedState != null && savedState.currentLevelIndex < totalLevels) {
                restoreState(savedState);
                return;
            }
        }

        // Load first level
        currentLevelIndex.setValue(0);
        loadLevel(0, null);
    }

    /**
     * Loads a specific level. Updates displayState atomically.
     *
     * @param levelIndex The level index (0-based)
     * @param savedGrid A previously saved grid, or null for fresh load
     */
    public void loadLevel(int levelIndex, int[][] savedGrid) {
        if (levelIndex < 0 || levelIndex >= totalLevels) return;

        Level level = levels.get(levelIndex);
        int[][] original = level.getGrid();
        int height = original.length;
        int width = original[0].length;
        int[][] newGrid = new int[height][width];
        int playerR = -1;
        int playerC = -1;

        if (savedGrid != null && savedGrid.length == height
                && savedGrid[0].length == width) {
            // Restore from saved grid
            for (int r = 0; r < height; r++) {
                System.arraycopy(savedGrid[r], 0, newGrid[r], 0, width);
            }
            int[] pos = GridUtils.findPlayer(newGrid);
            if (pos != null) {
                playerR = pos[0];
                playerC = pos[1];
            }
        } else {
            // Fresh copy from original - convert player markers
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    int val = original[r][c];
                    if (val == 4 || val == 6) {
                        playerR = r;
                        playerC = c;
                        newGrid[r][c] = (val == 6) ? 2 : 0;
                    } else {
                        newGrid[r][c] = val;
                    }
                }
            }
        }

        // If no player found, place at first empty floor
        if (playerR == -1) {
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    if (newGrid[r][c] == 0) {
                        playerR = r;
                        playerC = c;
                        break;
                    }
                }
                if (playerR != -1) break;
            }
        }

        if (playerR == -1) {
            playerR = 0;
            playerC = 0;
        }

        // Update all state atomically
        currentLevelIndex.setValue(levelIndex);
        moveCount.setValue(0);
        timerSeconds.setValue(0);
        isPaused.setValue(false);
        history.clear();
        stopTimer();

        // Set the display state – this triggers a single UI update
        displayState.setValue(new GameDisplayState(newGrid, playerR, playerC, false));

        // Save state for persistence
        saveState();
    }

    // ========================================================================
    // Game Logic
    // ========================================================================

    /**
     * Attempts to move the player in the given direction.
     *
     * @param direction The direction to move
     */
    public void attemptMove(Direction direction) {
        if (isPaused.getValue() || displayState.getValue() == null) return;

        GameDisplayState currentState = displayState.getValue();
        int row = currentState.playerRow;
        int col = currentState.playerCol;
        int newRow = row + direction.getDeltaRow();
        int newCol = col + direction.getDeltaCol();

        int[][] currentGrid = currentState.grid;
        if (!GridUtils.isValidPosition(currentGrid, newRow, newCol)) return;
        if (GridUtils.isWall(currentGrid, newRow, newCol)) return;

        // Save state for undo
        history.add(createStateSnapshot());
        if (history.size() > MAX_HISTORY) {
            history.remove(0);
        }

        int[][] newGrid = GridUtils.copyGrid(currentGrid);
        int target = newGrid[newRow][newCol];
        boolean moved = false;

        // Check if pushing a box
        if (target == 3 || target == 5) {
            int boxNewRow = newRow + direction.getDeltaRow();
            int boxNewCol = newCol + direction.getDeltaCol();
            if (!GridUtils.isValidPosition(newGrid, boxNewRow, boxNewCol)) {
                history.remove(history.size() - 1);
                return;
            }
            int beyond = newGrid[boxNewRow][boxNewCol];

            if (beyond == 0 || beyond == 2) {
                // Remove box from current position
                newGrid[newRow][newCol] = (target == 5) ? 2 : 0;
                // Place box in new position
                newGrid[boxNewRow][boxNewCol] = (beyond == 2) ? 5 : 3;
                moved = true;
            } else {
                history.remove(history.size() - 1);
                return;
            }
        } else if (target == 0 || target == 2) {
            // Walk into empty space or goal
            moved = true;
        }

        if (moved) {
            int newMoves = moveCount.getValue() + 1;
            moveCount.setValue(newMoves);
            if (newMoves == 1 && !timerRunning) startTimer();

            boolean completed = GridUtils.isLevelCompleted(newGrid);
            if (completed) {
                stopTimer();
                Set<Integer> completedSet = new HashSet<>(completedLevels.getValue());
                completedSet.add(currentLevelIndex.getValue());
                completedLevels.setValue(completedSet);
            }

            // Update display state with new grid and player position
            displayState.setValue(new GameDisplayState(newGrid, newRow, newCol, completed));
            saveState();
        } else {
            history.remove(history.size() - 1);
        }
    }

    // ========================================================================
    // Undo Functionality
    // ========================================================================

    /**
     * Reverses the last move.
     */
    public void undoMove() {
        if (isPaused.getValue() || history.isEmpty() || displayState.getValue() == null) return;
        GameState previous = history.remove(history.size() - 1);
        restoreState(previous);
        saveState();
    }

    // ========================================================================
    // Reset Operations
    // ========================================================================

    /**
     * Resets the current level to its initial state.
     * This properly resets both the grid and player position on first tap.
     */
    public void resetCurrentLevel() {
        int index = currentLevelIndex.getValue();
        if (index < 0 || index >= totalLevels) return;

        Level level = levels.get(index);
        int[][] original = level.getGrid();
        int height = original.length;
        int width = original[0].length;
        int[][] newGrid = new int[height][width];
        int playerR = -1;
        int playerC = -1;

        // Reset from original level data - convert player markers
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                int val = original[r][c];
                if (val == 4 || val == 6) {
                    playerR = r;
                    playerC = c;
                    newGrid[r][c] = (val == 6) ? 2 : 0;
                } else {
                    newGrid[r][c] = val;
                }
            }
        }

        // If no player found, place at first empty floor
        if (playerR == -1) {
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    if (newGrid[r][c] == 0) {
                        playerR = r;
                        playerC = c;
                        break;
                    }
                }
                if (playerR != -1) break;
            }
        }

        // Fallback - place at (0,0) if still not found
        if (playerR == -1) {
            playerR = 0;
            playerC = 0;
        }

        // Update all LiveData values
        moveCount.setValue(0);
        timerSeconds.setValue(0);
        isPaused.setValue(false);
        history.clear();
        stopTimer();
        displayState.setValue(new GameDisplayState(newGrid, playerR, playerC, false));
        saveState();
    }

    /**
     * Resets the entire game, clearing all progress.
     */
    public void resetEntireGame() {
        completedLevels.setValue(new HashSet<>());
        currentLevelIndex.setValue(0);
        loadLevel(0, null);
        sharedPreferences.edit().remove(KEY_SAVE_STATE).apply();
        stopTimer();
        timerSeconds.setValue(0);
    }

    // ========================================================================
    // Level Navigation
    // ========================================================================

    /**
     * Moves to the next level, or wraps to the first if at the end.
     */
    public void goToNextLevel() {
        if (isPaused.getValue()) return;
        int index = currentLevelIndex.getValue();
        if (index < totalLevels - 1) {
            loadLevel(index + 1, null);
        } else {
            loadLevel(0, null);
        }
        saveState();
    }

    /**
     * Moves to the previous level if possible.
     */
    public void goToPreviousLevel() {
        if (isPaused.getValue()) return;
        int index = currentLevelIndex.getValue();
        if (index > 0) {
            loadLevel(index - 1, null);
            saveState();
        }
    }

    // ========================================================================
    // Timer Control
    // ========================================================================

    /**
     * Starts the timer if not already running.
     */
    public void startTimer() {
        if (timerRunning) return;
        timerRunning = true;
        timerHandler.post(timerRunnable);
    }

    /**
     * Stops the timer.
     */
    public void stopTimer() {
        timerRunning = false;
        timerHandler.removeCallbacks(timerRunnable);
    }

    // ========================================================================
    // Pause Control
    // ========================================================================

    /**
     * Toggles the pause state.
     */
    public void togglePause() {
        boolean paused = isPaused.getValue() != null && isPaused.getValue();
        isPaused.setValue(!paused);
        if (paused) {
            // Was paused, now resuming
            if (moveCount.getValue() > 0 && displayState.getValue() != null
                    && !displayState.getValue().isCompleted) {
                startTimer();
            }
        } else {
            // Was running, now pausing
            stopTimer();
        }
        saveState();
    }

    // ========================================================================
    // Record Stats Management (Persisted)
    // ========================================================================

    /**
     * Saves record stats for a level when completed.
     * Stats persist across app restarts via SharedPreferences.
     *
     * @param levelIndex The level index
     * @param moves The number of moves made
     * @param seconds The time taken in seconds
     */
    public void saveRecordStats(int levelIndex, int moves, int seconds) {
        // Only save if level is completed
        GameDisplayState state = displayState.getValue();
        if (state == null || !state.isCompleted) {
            return;
        }

        String movesKey = KEY_RECORD_MOVES + levelIndex;
        String timeKey = KEY_RECORD_TIME + levelIndex;

        int recordMoves = sharedPreferences.getInt(movesKey, Integer.MAX_VALUE);
        int recordTime = sharedPreferences.getInt(timeKey, Integer.MAX_VALUE);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        if (moves < recordMoves) {
            editor.putInt(movesKey, moves);
        }

        if (seconds < recordTime) {
            editor.putInt(timeKey, seconds);
        }

        editor.apply();
    }

    /**
     * Gets record stats for a level.
     *
     * @param levelIndex The level index
     * @return RecordStats object, or null if level never completed
     */
    public RecordStats getRecordStats(int levelIndex) {
        String movesKey = KEY_RECORD_MOVES + levelIndex;
        String timeKey = KEY_RECORD_TIME + levelIndex;

        int recordMoves = sharedPreferences.getInt(movesKey, -1);
        int recordTime = sharedPreferences.getInt(timeKey, -1);

        if (recordMoves == -1 || recordTime == -1) {
            return null;
        }

        return new RecordStats(recordMoves, recordTime);
    }

    /**
     * Clears all record stats.
     */
    public void clearRecordStats() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        for (int i = 0; i < totalLevels; i++) {
            editor.remove(KEY_RECORD_MOVES + i);
            editor.remove(KEY_RECORD_TIME + i);
        }
        editor.apply();
    }

    // ========================================================================
    // State Management
    // ========================================================================

    /**
     * Saves the current game state to SharedPreferences.
     */
    private void saveState() {
        GameState state = createStateSnapshot();
        String json = gson.toJson(state);
        sharedPreferences.edit().putString(KEY_SAVE_STATE, json).apply();
    }

    /**
     * Creates a snapshot of the current game state.
     *
     * @return The current GameState
     */
    private GameState createStateSnapshot() {
        GameDisplayState disp = displayState.getValue();
        GameState state = new GameState();
        state.currentLevelIndex = currentLevelIndex.getValue();
        state.grid = disp != null ? GridUtils.copyGrid(disp.grid) : null;
        state.playerRow = disp != null ? disp.playerRow : 0;
        state.playerCol = disp != null ? disp.playerCol : 0;
        state.moveCount = moveCount.getValue();
        state.timerSeconds = timerSeconds.getValue();
        state.completedLevels = new HashSet<>(completedLevels.getValue());
        return state;
    }

    /**
     * Restores a previously saved game state.
     *
     * @param state The state to restore
     */
    private void restoreState(GameState state) {
        if (state == null) return;
        currentLevelIndex.setValue(state.currentLevelIndex);
        moveCount.setValue(state.moveCount);
        timerSeconds.setValue(state.timerSeconds);
        completedLevels.setValue(state.completedLevels);
        displayState.setValue(new GameDisplayState(state.grid, state.playerRow, state.playerCol,
                state.isLevelCompleted(state.currentLevelIndex)));
    }

    // ========================================================================
    // Getters
    // ========================================================================

    /** Returns the atomic display state as LiveData. */
    public LiveData<GameDisplayState> getDisplayState() {
        return displayState;
    }

    /** Returns the current level index as LiveData. */
    public LiveData<Integer> getCurrentLevelIndex() {
        return currentLevelIndex;
    }

    /** Returns the move count as LiveData. */
    public LiveData<Integer> getMoveCount() {
        return moveCount;
    }

    /** Returns the elapsed timer seconds as LiveData. */
    public LiveData<Integer> getTimerSeconds() {
        return timerSeconds;
    }

    /** Returns the pause state as LiveData. */
    public LiveData<Boolean> getIsPaused() {
        return isPaused;
    }

    /** Returns the set of completed levels as LiveData. */
    public LiveData<Set<Integer>> getCompletedLevels() {
        return completedLevels;
    }

    /** Returns the total number of levels. */
    public int getTotalLevels() {
        return totalLevels;
    }

    /**
     * Returns the number of remaining goals in the current level.
     *
     * @return The number of remaining goals
     */
    public int getRemainingGoals() {
        GameDisplayState state = displayState.getValue();
        return state != null ? GridUtils.countRemainingGoals(state.grid) : 0;
    }

    // ========================================================================
    // Cleanup
    // ========================================================================

    @Override
    protected void onCleared() {
        super.onCleared();
        stopTimer();
        timerHandler.removeCallbacksAndMessages(null);
    }

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Immutable container for all data needed to render the board.
     *
     * <p>This class bundles the grid, player position, and completion status
     * into a single object. When any of these values change, a new instance
     * is created and emitted via LiveData, ensuring the UI always receives
     * a consistent snapshot of the game state.</p>
     */
    public static class GameDisplayState {
        /** The current game grid. */
        public final int[][] grid;

        /** Player's row position. */
        public final int playerRow;

        /** Player's column position. */
        public final int playerCol;

        /** Whether the level is completed. */
        public final boolean isCompleted;

        /**
         * Constructs a new GameDisplayState.
         *
         * @param grid The game grid
         * @param playerRow The player's row
         * @param playerCol The player's column
         * @param isCompleted Whether the level is completed
         */
        public GameDisplayState(int[][] grid, int playerRow, int playerCol, boolean isCompleted) {
            this.grid = grid;
            this.playerRow = playerRow;
            this.playerCol = playerCol;
            this.isCompleted = isCompleted;
        }
    }

    /**
     * Immutable container for record stats.
     * Persisted across app restarts via SharedPreferences.
     */
    public static class RecordStats {
        /** Record moves for the level. */
        public final int recordMoves;

        /** Record time for the level in seconds. */
        public final int recordTime;

        /**
         * Constructs a new RecordStats.
         *
         * @param recordMoves The record moves
         * @param recordTime The record time in seconds
         */
        public RecordStats(int recordMoves, int recordTime) {
            this.recordMoves = recordMoves;
            this.recordTime = recordTime;
        }
    }
}