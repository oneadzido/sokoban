package com.ark.sokoban;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.ark.sokoban.models.Direction;
import com.ark.sokoban.models.Level;
import com.ark.sokoban.repository.LevelRepository;
import com.ark.sokoban.utils.GridUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ViewModel for the Sokoban game.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameViewModel extends AndroidViewModel {
    
    // Constants
    private static final String PREFS_NAME = "SokobanPrefs";
    private static final String KEY_SAVE_STATE = "save_state";
    private static final int MAX_HISTORY = 100;
    
    // Dependencies
    private final SharedPreferences sharedPreferences;
    private final Gson gson = new GsonBuilder().create();
    private final LevelRepository repository = new LevelRepository();
    
    // Level data
    private List<Level> levels = new ArrayList<>();
    private int totalLevels = 0;
    
    // State
    private final MutableLiveData<Integer> currentLevelIndex = new MutableLiveData<>(0);
    private final MutableLiveData<int[][]> grid = new MutableLiveData<>();
    private final MutableLiveData<Integer> playerRow = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> playerCol = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> moveCount = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> timerSeconds = new MutableLiveData<>(0);
    private final MutableLiveData<Boolean> isPaused = new MutableLiveData<>(false);
    private final MutableLiveData<Boolean> isCompleted = new MutableLiveData<>(false);
    private final MutableLiveData<Set<Integer>> completedLevels = new MutableLiveData<>(new HashSet<>());
    
    // Undo history
    private List<GameState> history = new ArrayList<>();
    
    // Timer
    private boolean timerRunning = false;
    private final android.os.Handler timerHandler = new android.os.Handler(
        android.os.Looper.getMainLooper()
    );
    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (timerRunning) {
                timerSeconds.setValue(timerSeconds.getValue() + 1);
                timerHandler.postDelayed(this, 1000);
            }
        }
    };
    
    public GameViewModel(@NonNull Application application) {
        super(application);
        this.sharedPreferences = application.getSharedPreferences(PREFS_NAME, Application.MODE_PRIVATE);
    }
    
    // ========================================================================
    // Level Loading
    // ========================================================================
    
    /**
     * Loads levels from the asset file.
     * 
     * @param fileName The file name in the assets folder
     * @throws Exception If loading fails
     */
    public void loadLevels(String fileName) throws Exception {
        repository.loadLevels(getApplication().getAssets(), fileName);
        this.levels = repository.getAllLevels();
        this.totalLevels = levels.size();
        
        if (totalLevels == 0) return;
        
        // Try to restore saved state
        String json = sharedPreferences.getString(KEY_SAVE_STATE, null);
        if (json != null) {
            GameState savedState = gson.fromJson(json, GameState.class);
            if (savedState != null && savedState.currentLevelIndex < totalLevels) {
                restoreState(savedState);
                return;
            }
        }
        
        // Load first level
        currentLevelIndex.setValue(0);
        loadLevel(0, null);
    }
    
    /**
     * Loads a specific level.
     */
    public void loadLevel(int levelIndex, int[][] savedGrid) {
        if (levelIndex < 0 || levelIndex >= totalLevels) return;
        
        Level level = levels.get(levelIndex);
        int[][] original = level.getGrid();
        int height = original.length;
        int width = original[0].length;
        int[][] newGrid = new int[height][width];
        int playerR = -1;
        int playerC = -1;
        
        if (savedGrid != null && savedGrid.length == height && savedGrid[0].length == width) {
            // Restore from saved grid
            for (int r = 0; r < height; r++) {
                System.arraycopy(savedGrid[r], 0, newGrid[r], 0, width);
            }
            int[] pos = GridUtils.findPlayer(newGrid);
            if (pos != null) {
                playerR = pos[0];
                playerC = pos[1];
            }
        } else {
            // Fresh copy from original - convert player markers
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    int val = original[r][c];
                    if (val == 4 || val == 6) {
                        playerR = r;
                        playerC = c;
                        newGrid[r][c] = (val == 6) ? 2 : 0;
                    } else {
                        newGrid[r][c] = val;
                    }
                }
            }
        }
        
        // If no player found, place at first empty floor
        if (playerR == -1) {
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    if (newGrid[r][c] == 0) {
                        playerR = r;
                        playerC = c;
                        break;
                    }
                }
                if (playerR != -1) break;
            }
        }
        
        if (playerR == -1) {
            playerR = 0;
            playerC = 0;
        }
        
        currentLevelIndex.setValue(levelIndex);
        grid.setValue(newGrid);
        playerRow.setValue(playerR);
        playerCol.setValue(playerC);
        moveCount.setValue(0);
        timerSeconds.setValue(0);
        isCompleted.setValue(false);
        history.clear();
        stopTimer();
        saveState();
    }
    
    // ========================================================================
    // Game Logic
    // ========================================================================
    
    /**
     * Attempts to move the player in the given direction.
     */
    public void attemptMove(Direction direction) {
        if (isPaused.getValue() || isCompleted.getValue()) return;
        
        int row = playerRow.getValue();
        int col = playerCol.getValue();
        int newRow = row + direction.getDeltaRow();
        int newCol = col + direction.getDeltaCol();
        
        int[][] currentGrid = grid.getValue();
        if (!GridUtils.isValidPosition(currentGrid, newRow, newCol)) return;
        if (GridUtils.isWall(currentGrid, newRow, newCol)) return;
        
        // Save state before moving
        history.add(createStateSnapshot());
        if (history.size() > MAX_HISTORY) {
            history.remove(0);
        }
        
        int[][] newGrid = GridUtils.copyGrid(currentGrid);
        int target = newGrid[newRow][newCol];
        boolean moved = false;
        
        // Check if pushing a box
        if (target == 3 || target == 5) {
            int boxNewRow = newRow + direction.getDeltaRow();
            int boxNewCol = newCol + direction.getDeltaCol();
            if (!GridUtils.isValidPosition(newGrid, boxNewRow, boxNewCol)) {
                history.remove(history.size() - 1);
                return;
            }
            int beyond = newGrid[boxNewRow][boxNewCol];
            
            if (beyond == 0 || beyond == 2) {
                // Remove box from current position
                newGrid[newRow][newCol] = (target == 5) ? 2 : 0;
                // Place box in new position
                newGrid[boxNewRow][boxNewCol] = (beyond == 2) ? 5 : 3;
                
                // Move player
                playerRow.setValue(newRow);
                playerCol.setValue(newCol);
                moved = true;
            } else {
                history.remove(history.size() - 1);
                return;
            }
        } else if (target == 0 || target == 2) {
            // Walk into empty space or goal
            playerRow.setValue(newRow);
            playerCol.setValue(newCol);
            moved = true;
        }
        
        if (moved) {
            int newMoves = moveCount.getValue() + 1;
            moveCount.setValue(newMoves);
            if (newMoves == 1 && !timerRunning) startTimer();
            
            grid.setValue(newGrid);
            
            if (GridUtils.isLevelCompleted(newGrid)) {
                isCompleted.setValue(true);
                stopTimer();
                Set<Integer> completed = new HashSet<>(completedLevels.getValue());
                completed.add(currentLevelIndex.getValue());
                completedLevels.setValue(completed);
                saveState();
            }
            saveState();
        } else {
            history.remove(history.size() - 1);
        }
    }
    
    // ========================================================================
    // Undo
    // ========================================================================
    
    public void undoMove() {
        if (isPaused.getValue() || isCompleted.getValue() || history.isEmpty()) return;
        GameState previous = history.remove(history.size() - 1);
        restoreState(previous);
        saveState();
    }
    
    // ========================================================================
    // Reset
    // ========================================================================
    
    public void resetCurrentLevel() {
        int index = currentLevelIndex.getValue();
        loadLevel(index, null);
        saveState();
    }
    
    public void resetEntireGame() {
        completedLevels.setValue(new HashSet<>());
        currentLevelIndex.setValue(0);
        loadLevel(0, null);
        sharedPreferences.edit().remove(KEY_SAVE_STATE).apply();
        stopTimer();
        timerSeconds.setValue(0);
    }
    
    // ========================================================================
    // Navigation
    // ========================================================================
    
    public void goToNextLevel() {
        if (isPaused.getValue()) return;
        int index = currentLevelIndex.getValue();
        if (index < totalLevels - 1) {
            loadLevel(index + 1, null);
        } else {
            loadLevel(0, null);
        }
        saveState();
    }
    
    public void goToPreviousLevel() {
        if (isPaused.getValue()) return;
        int index = currentLevelIndex.getValue();
        if (index > 0) {
            loadLevel(index - 1, null);
            saveState();
        }
    }
    
    // ========================================================================
    // Timer
    // ========================================================================
    
    public void startTimer() {
        if (timerRunning) return;
        timerRunning = true;
        timerHandler.post(timerRunnable);
    }
    
    public void stopTimer() {
        timerRunning = false;
        timerHandler.removeCallbacks(timerRunnable);
    }
    
    // ========================================================================
    // Pause
    // ========================================================================
    
    public void togglePause() {
        boolean paused = isPaused.getValue() != null && isPaused.getValue();
        isPaused.setValue(!paused);
        if (!paused) {
            stopTimer();
        } else {
            if (moveCount.getValue() > 0 && !isCompleted.getValue()) {
                startTimer();
            }
        }
        saveState();
    }
    
    // ========================================================================
    // State Management
    // ========================================================================
    
    private void saveState() {
        GameState state = createStateSnapshot();
        String json = gson.toJson(state);
        sharedPreferences.edit().putString(KEY_SAVE_STATE, json).apply();
    }
    
    private GameState createStateSnapshot() {
        GameState state = new GameState();
        state.currentLevelIndex = currentLevelIndex.getValue();
        state.grid = GridUtils.copyGrid(grid.getValue());
        state.playerRow = playerRow.getValue();
        state.playerCol = playerCol.getValue();
        state.moveCount = moveCount.getValue();
        state.timerSeconds = timerSeconds.getValue();
        state.completedLevels = new HashSet<>(completedLevels.getValue());
        return state;
    }
    
    private void restoreState(GameState state) {
        if (state == null) return;
        currentLevelIndex.setValue(state.currentLevelIndex);
        grid.setValue(state.grid);
        playerRow.setValue(state.playerRow);
        playerCol.setValue(state.playerCol);
        moveCount.setValue(state.moveCount);
        timerSeconds.setValue(state.timerSeconds);
        completedLevels.setValue(state.completedLevels);
    }
    
    // ========================================================================
    // Getters
    // ========================================================================
    
    public LiveData<Integer> getCurrentLevelIndex() { return currentLevelIndex; }
    public LiveData<int[][]> getGrid() { return grid; }
    public LiveData<Integer> getPlayerRow() { return playerRow; }
    public LiveData<Integer> getPlayerCol() { return playerCol; }
    public LiveData<Integer> getMoveCount() { return moveCount; }
    public LiveData<Integer> getTimerSeconds() { return timerSeconds; }
    public LiveData<Boolean> getIsPaused() { return isPaused; }
    public LiveData<Boolean> getIsCompleted() { return isCompleted; }
    public LiveData<Set<Integer>> getCompletedLevels() { return completedLevels; }
    public int getTotalLevels() { return totalLevels; }
    public int getRemainingGoals() {
        int[][] currentGrid = grid.getValue();
        return currentGrid != null ? GridUtils.countRemainingGoals(currentGrid) : 0;
    }
    
    @Override
    protected void onCleared() {
        super.onCleared();
        stopTimer();
        timerHandler.removeCallbacksAndMessages(null);
    }
}