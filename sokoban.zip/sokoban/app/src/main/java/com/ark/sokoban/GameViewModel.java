package com.ark.sokoban;

import android.app.Application;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.ark.sokoban.models.Direction;
import com.ark.sokoban.models.Level;
import com.ark.sokoban.repository.LevelRepository;
import com.ark.sokoban.utils.GridUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ViewModel for the Sokoban game.
 *
 * <p>This class manages all game state and logic, including level loading,
 * player movement, undo functionality, timer management, and state
 * persistence. It follows the MVVM architecture pattern.</p>
 *
 * <h3>Overlay model</h3>
 * <p>The board is either fully visible and playable, or covered by an
 * overlay that hides it. The overlay exists in three states — the level
 * has just loaded and is waiting for the player, the player has paused
 * mid-level, or the level has just been solved — and is represented by
 * {@link OverlayState}. Absence of an overlay is {@code null}.</p>
 *
 * <p>A freshly loaded level starts in {@link OverlayState#LEVEL_LOADED},
 * so the player sees the level number rather than the board until they
 * tap Resume. Pausing an in-progress level transitions to
 * {@link OverlayState#LEVEL_PAUSED}. Solving a level transitions to
 * {@link OverlayState#LEVEL_SOLVED} with a short delay handled by the
 * view so the final move remains visible. Resuming from any of these
 * states returns to {@code null}.</p>
 *
 * <p>Movement and undo are accepted only while the overlay is absent.
 * This is the single guard that replaces every previous pause check.</p>
 *
 * <h3>Undo</h3>
 * <p>Undo uses a <b>delta-based approach</b>: instead of storing full
 * GameState objects for each move, only the direction of each move is
 * stored. To undo, all moves are replayed from the beginning up to the
 * desired point. This is extremely memory-efficient.</p>
 *
 * <p>The {@link GameDisplayState} inner class bundles all rendering data
 * (grid, player position, solved status) into a single immutable object.
 * This ensures the UI always receives a consistent snapshot of the game
 * state.</p>
 *
 * <h3>Timer</h3>
 * <p>The timer is computed from {@link SystemClock#elapsedRealtime()}
 * rather than accumulated wall-clock ticks, ensuring the displayed
 * duration is monotonic and immune to clock changes or scheduled-tick
 * drift. The timer value is stored in the save state for app restart,
 * but is not restored during undo operations to keep it immutable during
 * gameplay.</p>
 *
 * <h3>Persistence and restore</h3>
 * <p>A save describes the game at the moment it was written. The overlay
 * state is not part of the save, because it is a UI concern, not a game
 * concern. On restore, the save is classified by its content and the app
 * continues from where the player was headed:</p>
 * <ul>
 *   <li><b>Solved board.</b> The app was killed in the window between
 *       solving a level and the auto-advance firing. The next level is
 *       loaded fresh, exactly as the auto-advance would have done. On
 *       the last level, the last level is reloaded so the player can
 *       replay it or navigate away.</li>
 *   <li><b>No moves, board not solved.</b> The player had opened a level
 *       but had not started playing. There is nothing to restore — the
 *       board is at its starting layout — so the level is loaded fresh
 *       with the {@link OverlayState#LEVEL_LOADED} overlay.</li>
 *   <li><b>Some moves, board not solved.</b> A game was genuinely in
 *       progress. The board is restored from the save and shown with the
 *       {@link OverlayState#LEVEL_PAUSED} overlay so the player resumes
 *       deliberately.</li>
 * </ul>
 *
 * File Location: app/src/main/java/com/ark/sokoban/GameViewModel.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameViewModel extends AndroidViewModel {

    // ========================================================================
    // Constants
    // ========================================================================

    /** SharedPreferences name for game state. */
    private static final String PREFS_NAME = "SokobanPrefs";

    /** Key for saved game state in SharedPreferences. */
    private static final String KEY_SAVE_STATE = "save_state";

    /** Key prefix for best moves. */
    private static final String KEY_BEST_MOVES = "best_moves_";

    /** Key prefix for best time. */
    private static final String KEY_BEST_TIME = "best_time_";

    /** Timer tick interval in milliseconds. */
    private static final long TIMER_INTERVAL_MS = 1000L;

    // ========================================================================
    // Overlay States
    // ========================================================================

    /**
     * Reasons the board is covered by an overlay. Absence of an overlay is
     * represented by {@code null} on the {@link #overlayState} LiveData,
     * not by a value of this enum.
     */
    public enum OverlayState {
        /** A fresh level has loaded and is waiting for the player to resume. */
        LEVEL_LOADED,
        /** The player paused an in-progress level. */
        LEVEL_PAUSED,
        /** The level was solved and the auto-advance is pending. */
        LEVEL_SOLVED
    }

    // ========================================================================
    // Dependencies
    // ========================================================================

    /** SharedPreferences for persisting game state. */
    private final SharedPreferences sharedPreferences;

    /** Gson instance for JSON serialization. */
    private final Gson gson = new GsonBuilder().create();

    /** Repository for loading levels. */
    private final LevelRepository repository = new LevelRepository();

    // ========================================================================
    // Level Data
    // ========================================================================

    /** List of all levels loaded from assets. */
    private List<Level> levels = new ArrayList<>();

    /** Total number of levels available. */
    private int totalLevels = 0;

    // ========================================================================
    // State (LiveData)
    // ========================================================================

    /** Atomic game display state – used for rendering the board. */
    private final MutableLiveData<GameDisplayState> displayState = new MutableLiveData<>();

    /** Current level index (0-based). */
    private final MutableLiveData<Integer> currentLevelIndex = new MutableLiveData<>(0);

    /** Number of moves made in the current level. */
    private final MutableLiveData<Integer> moveCount = new MutableLiveData<>(0);

    /** Elapsed timer in seconds. */
    private final MutableLiveData<Integer> timerSeconds = new MutableLiveData<>(0);

    /**
     * Current overlay state, or {@code null} when the board is visible and
     * playable. This is the single source of truth for whether the game is
     * paused, freshly loaded, or solved.
     */
    private final MutableLiveData<OverlayState> overlayState = new MutableLiveData<>(null);

    /** Set of solved level indices. */
    private final MutableLiveData<Set<Integer>> solvedLevels =
            new MutableLiveData<>(new HashSet<>());

    /** Trigger for refreshing best stats display. */
    private final MutableLiveData<Boolean> refreshBestStatsTrigger = new MutableLiveData<>(false);

    /** Whether undo is available (history has moves). */
    private final MutableLiveData<Boolean> undoAvailable = new MutableLiveData<>(false);

    /** Whether previous level is available. */
    private final MutableLiveData<Boolean> prevAvailable = new MutableLiveData<>(false);

    /** Whether next level is available. */
    private final MutableLiveData<Boolean> nextAvailable = new MutableLiveData<>(false);

    // ========================================================================
    // Internal State - Delta-Based Undo
    // ========================================================================

    /** The base state of the level (before any moves). */
    private GameState baseState;

    /** History of moves (directions only) for undo. */
    private MoveHistory moveHistory = new MoveHistory();

    // ========================================================================
    // Internal State - Timer
    // ========================================================================

    /** Timer running flag. */
    private boolean timerRunning = false;

    /**
     * Realtime (ms) captured when the current timer segment started.
     * Used as the base for computing elapsed time against
     * {@link SystemClock#elapsedRealtime()}.
     */
    private long timerStartRealtime = 0L;

    /**
     * Displayed seconds accumulated up to the moment the current running
     * segment started. Preserved across pause/resume so the displayed time
     * continues from where it left off.
     */
    private int timerStartSeconds = 0;

    /** Handler for timer updates. */
    private final Handler timerHandler = new Handler(Looper.getMainLooper());

    /**
     * Runnable that refreshes the displayed timer every interval.
     *
     * <p>The displayed value is computed from
     * {@link SystemClock#elapsedRealtime()} minus the segment start, so a
     * delayed or coalesced tick never causes cumulative drift. The
     * {@link #TIMER_INTERVAL_MS} interval therefore controls refresh
     * cadence, not accuracy.</p>
     */
    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (!timerRunning) return;

            long elapsedMs = SystemClock.elapsedRealtime() - timerStartRealtime;
            int totalSeconds = timerStartSeconds + (int) (elapsedMs / 1000L);

            Integer current = timerSeconds.getValue();
            if (current == null || current != totalSeconds) {
                timerSeconds.setValue(totalSeconds);
            }

            timerHandler.postDelayed(this, TIMER_INTERVAL_MS);
        }
    };

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new GameViewModel.
     *
     * @param application The application context
     */
    public GameViewModel(@NonNull Application application) {
        super(application);
        this.sharedPreferences = application.getSharedPreferences(PREFS_NAME,
                Application.MODE_PRIVATE);
    }

    // ========================================================================
    // Level Loading
    // ========================================================================

    /**
     * Loads levels from the asset file and restores saved state if available.
     *
     * @param fileName The file name in the assets folder
     * @throws Exception If loading fails
     */
    public void loadLevels(String fileName) throws Exception {
        repository.loadLevels(getApplication().getAssets(), fileName);
        this.levels = repository.getAllLevels();
        this.totalLevels = levels.size();

        if (totalLevels == 0) return;

        // Try to restore saved state
        String json = sharedPreferences.getString(KEY_SAVE_STATE, null);
        if (json != null) {
            GameState savedState = gson.fromJson(json, GameState.class);
            if (savedState != null && savedState.currentLevelIndex < totalLevels) {
                restoreState(savedState);
                return;
            }
        }

        // Load first level
        currentLevelIndex.setValue(0);
        loadLevel(0, null);
    }

    /**
     * Loads a specific level and places it in {@link OverlayState#LEVEL_LOADED}
     * so the board stays hidden until the player resumes.
     *
     * @param levelIndex The level index (0-based)
     * @param savedGrid A previously saved grid, or null for fresh load
     */
    public void loadLevel(int levelIndex, int[][] savedGrid) {
        if (levelIndex < 0 || levelIndex >= totalLevels) return;

        Level level = levels.get(levelIndex);
        int[][] original = level.getGrid();
        int height = original.length;
        int width = original[0].length;
        int[][] newGrid = new int[height][width];
        int playerR = -1;
        int playerC = -1;

        if (savedGrid != null && savedGrid.length == height
                && savedGrid[0].length == width) {
            // Restore from saved grid
            for (int r = 0; r < height; r++) {
                System.arraycopy(savedGrid[r], 0, newGrid[r], 0, width);
            }
            int[] pos = GridUtils.findPlayer(newGrid);
            if (pos != null) {
                playerR = pos[0];
                playerC = pos[1];
            }
        } else {
            // Fresh copy from original - convert player markers
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    int val = original[r][c];
                    if (val == 4 || val == 6) {
                        playerR = r;
                        playerC = c;
                        newGrid[r][c] = (val == 6) ? 2 : 0;
                    } else {
                        newGrid[r][c] = val;
                    }
                }
            }
        }

        // If no player found, place at first empty floor
        if (playerR == -1) {
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    if (newGrid[r][c] == 0) {
                        playerR = r;
                        playerC = c;
                        break;
                    }
                }
                if (playerR != -1) break;
            }
        }

        if (playerR == -1) {
            playerR = 0;
            playerC = 0;
        }

        // Build the base state from the original level data
        baseState = buildBaseState(levelIndex);

        // Update all state atomically
        currentLevelIndex.setValue(levelIndex);
        moveCount.setValue(0);
        timerSeconds.setValue(0);
        overlayState.setValue(OverlayState.LEVEL_LOADED);
        moveHistory.clear();
        undoAvailable.setValue(false);
        stopTimer();

        // Set the display state - isSolved is always false when loading
        displayState.setValue(new GameDisplayState(newGrid, playerR, playerC, false));

        // Update navigation availability
        updateNavigationAvailability();

        // Save state for persistence
        saveState();
    }

    // ========================================================================
    // Game Logic
    // ========================================================================

    /**
     * Returns true when the board is covered by an overlay and therefore
     * not accepting input. Movement, undo, and navigation are guarded by
     * this single check.
     *
     * @return true if an overlay is showing
     */
    private boolean isOverlayShowing() {
        return overlayState.getValue() != null;
    }

    /**
     * Replays moves from the beginning up to the current history size.
     * This is the core of the delta-based undo approach.
     *
     * @return The GameState after replaying all moves in history, or null if baseState is null
     */
    private GameState replayMoves() {
        if (baseState == null) {
            return null;
        }

        GameState state = baseState.deepCopy();

        for (Direction dir : moveHistory.getAllMoves()) {
            state = applyMove(state, dir);
            if (state == null) break;
        }

        return state;
    }

    /**
     * Applies a single move to a GameState and returns the new state.
     *
     * @param state The current state
     * @param direction The direction to move
     * @return The new state after the move, or null if move was invalid
     */
    private GameState applyMove(GameState state, Direction direction) {
        if (state == null || direction == null) {
            return null;
        }

        int row = state.playerRow;
        int col = state.playerCol;
        int newRow = row + direction.getDeltaRow();
        int newCol = col + direction.getDeltaCol();

        int[][] grid = state.grid;
        if (!GridUtils.isValidPosition(grid, newRow, newCol)) return null;
        if (GridUtils.isWall(grid, newRow, newCol)) return null;

        GameState newState = state.deepCopy();
        int[][] newGrid = newState.grid;
        int target = newGrid[newRow][newCol];
        boolean moved = false;

        // Check if pushing a box
        if (target == 3 || target == 5) {
            int boxNewRow = newRow + direction.getDeltaRow();
            int boxNewCol = newCol + direction.getDeltaCol();
            if (!GridUtils.isValidPosition(newGrid, boxNewRow, boxNewCol)) return null;
            int beyond = newGrid[boxNewRow][boxNewCol];

            if (beyond == 0 || beyond == 2) {
                newGrid[newRow][newCol] = (target == 5) ? 2 : 0;
                newGrid[boxNewRow][boxNewCol] = (beyond == 2) ? 5 : 3;
                moved = true;
            }
        } else if (target == 0 || target == 2) {
            moved = true;
        }

        if (moved) {
            newState.playerRow = newRow;
            newState.playerCol = newCol;
            newState.moveCount = state.moveCount + 1;
            return newState;
        }

        return null;
    }

    /**
     * Attempts to move the player in the given direction.
     *
     * <p>Ignored while an overlay is showing. The first accepted move of a
     * loaded level clears the overlay so play begins.</p>
     *
     * @param direction The direction to move
     */
    public void attemptMove(Direction direction) {
        if (isOverlayShowing() || displayState.getValue() == null) return;

        GameState currentState = replayMoves();
        if (currentState == null) return;

        GameState newState = applyMove(currentState, direction);
        if (newState == null) return;

        moveHistory.addMove(direction);
        undoAvailable.setValue(moveHistory.hasMoves());

        int newMoves = moveCount.getValue() + 1;
        moveCount.setValue(newMoves);

        if (!timerRunning) {
            startTimer();
        }

        boolean levelSolved = GridUtils.isLevelSolved(newState.grid);

        if (levelSolved) {
            stopTimer();
            if (!solvedLevels.getValue().contains(currentLevelIndex.getValue())) {
                Set<Integer> solvedSet = new HashSet<>(solvedLevels.getValue());
                solvedSet.add(currentLevelIndex.getValue());
                solvedLevels.setValue(solvedSet);
            }
            refreshBestStats();
            overlayState.setValue(OverlayState.LEVEL_SOLVED);
        }

        displayState.setValue(new GameDisplayState(
                newState.grid, newState.playerRow, newState.playerCol, levelSolved));
        saveState();
    }

    // ========================================================================
    // Undo Functionality
    // ========================================================================

    /**
     * Reverses the last move by replaying from the beginning.
     * Timer is not affected by undo — it remains immutable during gameplay.
     *
     * <p>Ignored while an overlay is showing.</p>
     */
    public void undoMove() {
        if (isOverlayShowing() || !moveHistory.hasMoves()) return;

        if (!timerRunning) {
            startTimer();
        }

        moveHistory.undoLastMove();
        undoAvailable.setValue(moveHistory.hasMoves());

        GameState newState = replayMoves();
        if (newState == null) return;

        moveCount.setValue(newState.moveCount);

        boolean levelSolved = GridUtils.isLevelSolved(newState.grid);

        displayState.setValue(new GameDisplayState(
                newState.grid, newState.playerRow, newState.playerCol, levelSolved));

        refreshBestStats();
        saveState();
    }

    // ========================================================================
    // Reset Operations
    // ========================================================================

    /**
     * Resets the current level to its initial state and places it in
     * {@link OverlayState#LEVEL_LOADED}, matching the behaviour of a fresh
     * level load.
     */
    public void resetCurrentLevel() {
        int index = currentLevelIndex.getValue();
        if (index < 0 || index >= totalLevels) return;

        if (baseState == null) {
            baseState = buildBaseState(index);
        }

        GameState newState = baseState.deepCopy();

        moveCount.setValue(0);
        timerSeconds.setValue(0);
        overlayState.setValue(OverlayState.LEVEL_LOADED);
        moveHistory.clear();
        undoAvailable.setValue(false);
        stopTimer();

        displayState.setValue(new GameDisplayState(
                newState.grid, newState.playerRow, newState.playerCol, false));
        updateNavigationAvailability();
        saveState();
    }

    /**
     * Resets the entire game, clearing all progress.
     */
    public void resetEntireGame() {
        solvedLevels.setValue(new HashSet<>());
        currentLevelIndex.setValue(0);
        loadLevel(0, null);
        sharedPreferences.edit().remove(KEY_SAVE_STATE).apply();
        stopTimer();
        timerSeconds.setValue(0);
        undoAvailable.setValue(false);
        updateNavigationAvailability();
    }

    // ========================================================================
    // Level Navigation
    // ========================================================================

    /**
     * Moves to the next level if available. Ignored while the game is
     * paused. A fresh or solved level allows navigation.
     */
    public void goToNextLevel() {
        if (overlayState.getValue() == OverlayState.LEVEL_PAUSED) return;
        int index = currentLevelIndex.getValue();
        if (index < totalLevels - 1) {
            loadLevel(index + 1, null);
            saveState();
        }
    }

    /**
     * Moves to the previous level if available. Ignored while the game is
     * paused. A fresh or solved level allows navigation.
     */
    public void goToPreviousLevel() {
        if (overlayState.getValue() == OverlayState.LEVEL_PAUSED) return;
        int index = currentLevelIndex.getValue();
        if (index > 0) {
            loadLevel(index - 1, null);
            saveState();
        }
    }

    // ========================================================================
    // Timer Control
    // ========================================================================

    /**
     * Starts the timer if not already running.
     *
     * <p>Captures the current displayed seconds and the current
     * {@link SystemClock#elapsedRealtime()} as the base for the new running
     * segment. The first tick fires after one full interval has elapsed so
     * the displayed time transitions correctly from its starting value.</p>
     */
    public void startTimer() {
        if (timerRunning) return;
        timerRunning = true;
        timerStartSeconds = timerSeconds.getValue() != null
                ? timerSeconds.getValue() : 0;
        timerStartRealtime = SystemClock.elapsedRealtime();
        timerHandler.postDelayed(timerRunnable, TIMER_INTERVAL_MS);
    }

    /**
     * Stops the timer.
     *
     * <p>The most recently displayed value is preserved on
     * {@link #timerSeconds} so that a subsequent {@link #startTimer()} call
     * resumes from where the timer stopped.</p>
     */
    public void stopTimer() {
        timerRunning = false;
        timerHandler.removeCallbacks(timerRunnable);
    }

    // ========================================================================
    // Overlay Control
    // ========================================================================

    /**
     * Advances the game through its overlay transitions.
     *
     * <p>Behaviour depends on the current overlay state:</p>
     * <ul>
     *   <li>{@code null} → pauses the game, showing
     *       {@link OverlayState#LEVEL_PAUSED} and stopping the timer.</li>
     *   <li>{@link OverlayState#LEVEL_PAUSED} → resumes the game, clearing
     *       the overlay and restarting the timer if there are moves to
     *       preserve.</li>
     *   <li>{@link OverlayState#LEVEL_LOADED} → clears the overlay so the
     *       player can start the freshly loaded level.</li>
     *   <li>{@link OverlayState#LEVEL_SOLVED} → clears the overlay; the
     *       auto-advance handler will move on shortly.</li>
     * </ul>
     */
    public void togglePause() {
        OverlayState state = overlayState.getValue();

        if (state == null) {
            overlayState.setValue(OverlayState.LEVEL_PAUSED);
            stopTimer();
            saveState();
            return;
        }

        overlayState.setValue(null);

        if (state == OverlayState.LEVEL_PAUSED
                && moveCount.getValue() != null && moveCount.getValue() > 0
                && displayState.getValue() != null) {
            startTimer();
        }

        saveState();
    }

    // ========================================================================
    // Best Stats Management
    // ========================================================================

    /**
     * Saves best stats for a level when solved.
     * Stats persist across app restarts via SharedPreferences.
     *
     * @param levelIndex The level index
     * @param moves The number of moves made
     * @param seconds The time taken in seconds
     */
    public void saveBestStats(int levelIndex, int moves, int seconds) {
        GameDisplayState state = displayState.getValue();
        if (state == null || !state.isSolved) {
            return;
        }

        String movesKey = KEY_BEST_MOVES + levelIndex;
        String timeKey = KEY_BEST_TIME + levelIndex;

        int bestMoves = sharedPreferences.getInt(movesKey, Integer.MAX_VALUE);
        int bestTime = sharedPreferences.getInt(timeKey, Integer.MAX_VALUE);

        boolean updated = false;
        SharedPreferences.Editor editor = sharedPreferences.edit();

        if (moves < bestMoves) {
            editor.putInt(movesKey, moves);
            updated = true;
        }

        if (seconds < bestTime) {
            editor.putInt(timeKey, seconds);
            updated = true;
        }

        if (updated) {
            editor.apply();
            refreshBestStats();
        }
    }

    /**
     * Gets best stats for a level.
     *
     * @param levelIndex The level index
     * @return BestStats object, or null if level never solved
     */
    public BestStats getBestStats(int levelIndex) {
        String movesKey = KEY_BEST_MOVES + levelIndex;
        String timeKey = KEY_BEST_TIME + levelIndex;

        int bestMoves = sharedPreferences.getInt(movesKey, -1);
        int bestTime = sharedPreferences.getInt(timeKey, -1);

        if (bestMoves == -1 || bestTime == -1) {
            return null;
        }

        return new BestStats(bestMoves, bestTime);
    }

    /**
     * Clears all best stats.
     */
    public void clearBestStats() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        for (int i = 0; i < totalLevels; i++) {
            editor.remove(KEY_BEST_MOVES + i);
            editor.remove(KEY_BEST_TIME + i);
        }
        editor.apply();
        refreshBestStats();
    }

    /**
     * Forces a refresh of the best stats display.
     * Called after state restoration to ensure best stats are shown.
     */
    public void refreshBestStats() {
        refreshBestStatsTrigger.setValue(!Boolean.TRUE.equals(refreshBestStatsTrigger.getValue()));
    }

    // ========================================================================
    // State Management
    // ========================================================================

    /**
     * Saves the current game state to SharedPreferences.
     */
    private void saveState() {
        GameState state = createStateSnapshot();
        String json = gson.toJson(state);
        sharedPreferences.edit().putString(KEY_SAVE_STATE, json).apply();
    }

    /**
     * Creates a snapshot of the current game state.
     * Timer IS stored for app restart/save.
     * History is stored as Directions (delta-based).
     *
     * @return The current GameState
     */
    private GameState createStateSnapshot() {
        GameDisplayState disp = displayState.getValue();
        GameState state = new GameState();
        state.currentLevelIndex = currentLevelIndex.getValue();
        state.grid = disp != null ? GridUtils.copyGrid(disp.grid) : null;
        state.playerRow = disp != null ? disp.playerRow : 0;
        state.playerCol = disp != null ? disp.playerCol : 0;
        state.moveCount = moveCount.getValue();
        state.timerSeconds = timerSeconds.getValue() != null ? timerSeconds.getValue() : 0;
        state.solvedLevels = new HashSet<>(solvedLevels.getValue());
        state.history = moveHistory.getAllMoves();
        return state;
    }

    /**
     * Restores a previously saved game state after an app restart.
     *
     * <p>The overlay state is not part of the save, because it is a UI
     * concern. Instead, the save is classified by its content and the app
     * continues from where the player was headed:</p>
     *
     * <ul>
     *   <li><b>Solved board.</b> The app was killed in the window between
     *       solving a level and the auto-advance firing. The next level
     *       is loaded fresh, exactly as the auto-advance would have done.
     *       On the last level, the last level is reloaded so the player
     *       can replay it or navigate away.</li>
     *   <li><b>No moves, board not solved.</b> The player had opened a
     *       level but had not started playing. There is nothing to
     *       restore — the board is at its starting layout — so the level
     *       is loaded fresh with the {@link OverlayState#LEVEL_LOADED}
     *       overlay.</li>
     *   <li><b>Some moves, board not solved.</b> A game was genuinely in
     *       progress. The board is restored from the save and shown with
     *       the {@link OverlayState#LEVEL_PAUSED} overlay so the player
     *       resumes deliberately.</li>
     * </ul>
     *
     * @param state The state to restore
     */
    private void restoreState(GameState state) {
        if (state == null) return;

        // Carry the solved set forward in every branch so best stats and
        // the level display keep treating solved levels as solved.
        solvedLevels.setValue(state.solvedLevels);

        // Case 1 — solved board: advance past.
        // The app was killed between solving and the auto-advance firing.
        // The player was about to see the next level, so load it fresh.
        if (GridUtils.isLevelSolved(state.grid)) {
            int nextIndex = Math.min(state.currentLevelIndex + 1, totalLevels - 1);
            loadLevel(nextIndex, null);
            return;
        }

        // Case 2 — no moves: load fresh.
        // The player had opened the level but had not started. There is
        // nothing to restore; the level starts from the beginning.
        if (state.moveCount == 0) {
            loadLevel(state.currentLevelIndex, null);
            return;
        }

        // Case 3 — some moves: restore in progress.
        // The board is in a meaningful arrangement. Bring it back and
        // show LEVEL_PAUSED so the player resumes deliberately.
        currentLevelIndex.setValue(state.currentLevelIndex);
        moveCount.setValue(state.moveCount);
        timerSeconds.setValue(state.timerSeconds);

        displayState.setValue(new GameDisplayState(
                state.grid, state.playerRow, state.playerCol, false));

        moveHistory.clear();
        if (state.history != null) {
            moveHistory.restoreFrom(state.history);
        }

        baseState = buildBaseState(state.currentLevelIndex);

        overlayState.setValue(OverlayState.LEVEL_PAUSED);

        stopTimer();
        undoAvailable.setValue(moveHistory.hasMoves());
        updateNavigationAvailability();

        new Handler(Looper.getMainLooper()).postDelayed(this::refreshBestStats, 50);
    }

    /**
     * Builds a base state (original level before any moves) from the level data.
     *
     * @param levelIndex The index of the level
     * @return A GameState representing the original level state
     */
    private GameState buildBaseState(int levelIndex) {
        if (levelIndex < 0 || levelIndex >= totalLevels || levels.isEmpty()) {
            return new GameState();
        }

        Level level = levels.get(levelIndex);
        int[][] original = level.getGrid();
        int height = original.length;
        int width = original[0].length;
        int[][] newGrid = new int[height][width];
        int playerR = -1;
        int playerC = -1;

        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                int val = original[r][c];
                if (val == 4 || val == 6) {
                    playerR = r;
                    playerC = c;
                    newGrid[r][c] = (val == 6) ? 2 : 0;
                } else {
                    newGrid[r][c] = val;
                }
            }
        }

        if (playerR == -1) {
            for (int r = 0; r < height; r++) {
                for (int c = 0; c < width; c++) {
                    if (newGrid[r][c] == 0) {
                        playerR = r;
                        playerC = c;
                        break;
                    }
                }
                if (playerR != -1) break;
            }
        }

        if (playerR == -1) {
            playerR = 0;
            playerC = 0;
        }

        GameState base = new GameState();
        base.currentLevelIndex = levelIndex;
        base.grid = GridUtils.copyGrid(newGrid);
        base.playerRow = playerR;
        base.playerCol = playerC;
        base.moveCount = 0;
        base.timerSeconds = 0;
        base.solvedLevels = new HashSet<>(solvedLevels.getValue());
        return base;
    }

    /**
     * Updates the navigation button availability based on current level.
     */
    private void updateNavigationAvailability() {
        Integer index = currentLevelIndex.getValue();
        if (index != null && totalLevels > 0) {
            prevAvailable.setValue(index > 0);
            nextAvailable.setValue(index < totalLevels - 1);
        }
    }

    // ========================================================================
    // Getters
    // ========================================================================

    /** Returns the atomic display state as LiveData. */
    public LiveData<GameDisplayState> getDisplayState() {
        return displayState;
    }

    /** Returns the current level index as LiveData. */
    public LiveData<Integer> getCurrentLevelIndex() {
        return currentLevelIndex;
    }

    /** Returns the move count as LiveData. */
    public LiveData<Integer> getMoveCount() {
        return moveCount;
    }

    /** Returns the elapsed timer seconds as LiveData. */
    public LiveData<Integer> getTimerSeconds() {
        return timerSeconds;
    }

    /**
     * Returns the current overlay state as LiveData, or {@code null} when
     * the board is visible and playable.
     */
    @Nullable
    public LiveData<OverlayState> getOverlayState() {
        return overlayState;
    }

    /** Returns the set of solved levels as LiveData. */
    public LiveData<Set<Integer>> getSolvedLevels() {
        return solvedLevels;
    }

    /** Returns the refresh best stats trigger as LiveData. */
    public LiveData<Boolean> getRefreshBestStatsTrigger() {
        return refreshBestStatsTrigger;
    }

    /** Returns whether undo is available as LiveData. */
    public LiveData<Boolean> getUndoAvailable() {
        return undoAvailable;
    }

    /** Returns whether previous level is available as LiveData. */
    public LiveData<Boolean> getPrevAvailable() {
        return prevAvailable;
    }

    /** Returns whether next level is available as LiveData. */
    public LiveData<Boolean> getNextAvailable() {
        return nextAvailable;
    }

    /** Returns the total number of levels. */
    public int getTotalLevels() {
        return totalLevels;
    }

    /**
     * Returns the number of remaining goals in the current level.
     *
     * @return The number of remaining goals
     */
    public int getRemainingGoals() {
        GameDisplayState state = displayState.getValue();
        return state != null ? GridUtils.countRemainingGoals(state.grid) : 0;
    }

    // ========================================================================
    // Time Formatting
    // ========================================================================

    /**
     * Formats a duration in seconds as {@code MM:SS} or {@code HH:MM:SS}.
     *
     * <p>Durations under one hour use the compact {@code MM:SS} form so the
     * common case stays short. Durations of one hour or more switch to
     * {@code HH:MM:SS} so the minute field never overflows past 59 and the
     * best-stats row keeps a fixed width when long times are shown.</p>
     *
     * @param seconds The elapsed time in seconds. Must be non-negative.
     * @return The formatted time string (e.g., "01:30" or "01:05:20")
     */
    public static String formatTime(int seconds) {
        int hours = seconds / 3600;
        int minutes = (seconds % 3600) / 60;
        int secs = seconds % 60;
        if (hours > 0) {
            return String.format("%02d:%02d:%02d", hours, minutes, secs);
        }
        return String.format("%02d:%02d", minutes, secs);
    }

    // ========================================================================
    // Cleanup
    // ========================================================================

    @Override
    protected void onCleared() {
        super.onCleared();
        stopTimer();
        timerHandler.removeCallbacksAndMessages(null);
    }

    // ========================================================================
    // Inner Classes
    // ========================================================================

    /**
     * Immutable container for all data needed to render the board.
     *
     * <p>This class bundles the grid, player position, and solved status
     * into a single object. When any of these values change, a new instance
     * is created and emitted via LiveData, ensuring the UI always receives
     * a consistent snapshot of the game state.</p>
     *
     * <p>The {@code isSolved} flag is true ONLY when the level was just
     * solved in the current play session. If a level was solved before
     * (saved in solvedLevels) and is being replayed, this flag will be
     * false until the level is solved again in this session.</p>
     */
    public static class GameDisplayState {
        /** The current game grid. */
        public final int[][] grid;

        /** Player's row position. */
        public final int playerRow;

        /** Player's column position. */
        public final int playerCol;

        /**
         * True ONLY if the level was just solved in the current play session.
         * If a level was solved before and is being replayed, this is false.
         */
        public final boolean isSolved;

        /**
         * Constructs a new GameDisplayState.
         *
         * @param grid The game grid
         * @param playerRow The player's row
         * @param playerCol The player's column
         * @param isSolved Whether the level was just solved in this session
         */
        public GameDisplayState(int[][] grid, int playerRow, int playerCol, boolean isSolved) {
            this.grid = grid;
            this.playerRow = playerRow;
            this.playerCol = playerCol;
            this.isSolved = isSolved;
        }
    }

    /**
     * Immutable container for best stats.
     * Persisted across app restarts via SharedPreferences.
     */
    public static class BestStats {
        /** Best moves for the level. */
        public final int bestMoves;

        /** Best time for the level in seconds. */
        public final int bestTime;

        /**
         * Constructs a new BestStats.
         *
         * @param bestMoves The best moves
         * @param bestTime The best time in seconds
         */
        public BestStats(int bestMoves, int bestTime) {
            this.bestMoves = bestMoves;
            this.bestTime = bestTime;
        }
    }
}