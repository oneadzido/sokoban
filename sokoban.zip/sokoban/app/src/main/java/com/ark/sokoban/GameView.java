package com.ark.sokoban;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * Custom view for rendering the Sokoban game board.
 *
 * <p>This view renders the game grid with emoji-based graphics for
 * walls, goals, boxes, and the player. It supports:</p>
 * <ul>
 *   <li>Efficient grid rendering with emojis</li>
 *   <li>Player pop animation on movement</li>
 *   <li>Pause overlay when game is paused</li>
 *   <li>Completion overlay when level is finished</li>
 *   <li>Blur effect on overlays to prevent cheating</li>
 *   <li>Responsive sizing based on view dimensions</li>
 * </ul>
 *
 * <p>The overlays (pause and completion) are drawn <b>only over the grid area</b>
 * (the square board), not over the entire view. This ensures they are the same
 * size as the game canvas and do not extend into the empty space around it.</p>
 *
 * File Location: app/src/main/java/com/ark/sokoban/GameView.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameView extends View {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Emoji for wall. */
    private static final String WALL_EMOJI = "🧱";

    /** Emoji for goal. */
    private static final String GOAL_EMOJI = "🎯";

    /** Emoji for box. */
    private static final String BOX_EMOJI = "📦";

    /** Emoji for player. */
    private static final String PLAYER_EMOJI = "🧒🏾";

    /** Emoji for level completion. */
    private static final String COMPLETED_EMOJI = "⭐";

    /** Emoji for pause. */
    private static final String PAUSE_EMOJI = "⏸️";

    /** Blur radius for overlay effect. */
    private static final int BLUR_RADIUS = 10;

    /** Scale factor for fast blur (1/4 size). */
    private static final int BLUR_SCALE_FACTOR = 4;

    // ========================================================================
    // Game State
    // ========================================================================

    /** The current game grid. */
    private int[][] grid;

    /** Player's row position. */
    private int playerRow;

    /** Player's column position. */
    private int playerCol;

    /** Size of each cell in pixels. */
    private int cellSize;

    /** Grid width in cells. */
    private int gridWidth;

    /** Grid height in cells. */
    private int gridHeight;

    /** Whether the level is completed. */
    private boolean isCompleted;

    /** Whether the game is paused. */
    private boolean isPaused;

    /** Whether to show the completion overlay. */
    private boolean showCompletionOverlay = false;

    // ========================================================================
    // Drawing
    // ========================================================================

    /** Paint for drawing emojis. */
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Size of emoji icons in pixels. */
    private float iconSize;

    /** Vertical offset for emoji centering. */
    private final float yOffset = 0.1f;

    /** Rectangle for the board area (exactly the grid size). */
    private final RectF boardRect = new RectF();

    /** Paint for the board background. */
    private final Paint boardPaint = new Paint();

    /** Paint for overlay text. */
    private final Paint overlayTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ========================================================================
    // Animation
    // ========================================================================

    /** Current player scale for pop animation. */
    private float playerScale = 1.0f;

    /** Pop animation. */
    private ValueAnimator popAnimator;

    // ========================================================================
    // Blur
    // ========================================================================

    /** Bitmap for blurring the board. */
    private Bitmap blurBitmap;

    /** Canvas for drawing the board into the blur bitmap. */
    private Canvas blurCanvas;

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new GameView.
     *
     * @param context The context
     * @param attrs The attribute set
     */
    public GameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    // ========================================================================
    // Initialization
    // ========================================================================

    /**
     * Initializes the view.
     */
    private void init() {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(0xFF4D3E2B);

        // Light floor color for board background
        boardPaint.setColor(0xFFD9CFC0);
        boardPaint.setStyle(Paint.Style.FILL);

        // Overlay text paint
        overlayTextPaint.setTextAlign(Paint.Align.CENTER);
        overlayTextPaint.setColor(0xFFFFFFFF);
        overlayTextPaint.setFakeBoldText(true);
        overlayTextPaint.setShadowLayer(8f, 0f, 0f, 0xAA000000);

        initPopAnimation();
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    /**
     * Initializes the pop animation.
     */
    private void initPopAnimation() {
        popAnimator = ValueAnimator.ofFloat(1.05f, 1.0f);
        popAnimator.setDuration(150);
        popAnimator.addUpdateListener(animation -> {
            playerScale = (float) animation.getAnimatedValue();
            invalidate();
        });
        popAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                playerScale = 1.0f;
                invalidate();
            }
        });
    }

    // ========================================================================
    // Public Methods
    // ========================================================================

    /**
     * Updates the game state and triggers a redraw.
     *
     * @param grid The current game grid
     * @param playerRow The player's row position
     * @param playerCol The player's column position
     * @param completed Whether the level is completed
     */
    public void updateGameState(int[][] grid, int playerRow, int playerCol, boolean completed) {
        boolean playerMoved = (this.playerRow != playerRow || this.playerCol != playerCol)
                && this.grid != null;

        this.grid = grid;
        this.playerRow = playerRow;
        this.playerCol = playerCol;
        this.isCompleted = completed;
        this.showCompletionOverlay = completed;

        if (grid != null) {
            this.gridHeight = grid.length;
            this.gridWidth = grid[0].length;
        }

        if (playerMoved && !completed) {
            triggerPopAnimation();
        }

        requestLayout();
        invalidate();
    }

    /**
     * Sets the pause state and triggers a redraw.
     *
     * @param paused True if the game is paused
     */
    public void setPaused(boolean paused) {
        this.isPaused = paused;
        invalidate();
    }

    /**
     * Triggers the pop animation for the player.
     */
    public void triggerPopAnimation() {
        if (popAnimator != null) {
            popAnimator.cancel();
            popAnimator.start();
        }
    }

    // ========================================================================
    // View Lifecycle
    // ========================================================================

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int size = Math.min(MeasureSpec.getSize(widthMeasureSpec),
                MeasureSpec.getSize(heightMeasureSpec));
        setMeasuredDimension(size, size);

        if (gridWidth > 0 && gridHeight > 0) {
            cellSize = size / Math.max(gridWidth, gridHeight);
            if (cellSize < 10) cellSize = 10;
            iconSize = cellSize * 0.85f;
            paint.setTextSize(iconSize);
            overlayTextPaint.setTextSize(Math.min(cellSize * 0.7f, 32f));
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (grid == null) return;

        int viewSize = getWidth();
        int totalWidth = gridWidth * cellSize;
        int totalHeight = gridHeight * cellSize;
        float offsetX = (viewSize - totalWidth) / 2f;
        float offsetY = (viewSize - totalHeight) / 2f;

        // Draw board background (exactly the grid area)
        boardRect.set(offsetX, offsetY, offsetX + totalWidth, offsetY + totalHeight);
        canvas.drawRoundRect(boardRect, 8f, 8f, boardPaint);

        // Draw grid cells
        paint.setTextSize(iconSize);
        float textOffset = iconSize * yOffset;

        for (int row = 0; row < gridHeight; row++) {
            for (int col = 0; col < gridWidth; col++) {
                float centerX = offsetX + col * cellSize + cellSize / 2f;
                float centerY = offsetY + row * cellSize + cellSize / 2f;
                int value = grid[row][col];

                // Draw wall
                if (value == 1) {
                    canvas.drawText(WALL_EMOJI, centerX, centerY + textOffset, paint);
                    continue;
                }

                // Draw goal (behind box)
                if (value == 2 || value == 5) {
                    canvas.drawText(GOAL_EMOJI, centerX, centerY + textOffset, paint);
                }

                // Draw box (on top of goal)
                if (value == 3 || value == 5) {
                    canvas.drawText(BOX_EMOJI, centerX, centerY + textOffset, paint);
                }
            }
        }

        // Draw player (on top of everything)
        if (playerRow >= 0 && playerRow < gridHeight
                && playerCol >= 0 && playerCol < gridWidth) {
            float playerX = offsetX + playerCol * cellSize + cellSize / 2f;
            float playerY = offsetY + playerRow * cellSize + cellSize / 2f;

            if (playerScale != 1.0f) {
                canvas.save();
                canvas.translate(playerX, playerY);
                canvas.scale(playerScale, playerScale);
                canvas.translate(-playerX, -playerY);
                canvas.drawText(PLAYER_EMOJI, playerX, playerY + textOffset, paint);
                canvas.restore();
            } else {
                canvas.drawText(PLAYER_EMOJI, playerX, playerY + textOffset, paint);
            }
        }

        // Draw overlays (pause or completion) - exactly over the board area
        if (isPaused || showCompletionOverlay) {
            drawOverlay(canvas);
        }
    }

    // ========================================================================
    // Overlay Drawing
    // ========================================================================

    /**
     * Draws the overlay (pause or completion) over the board area.
     * The overlay is the exact same size as the boardRect.
     *
     * @param canvas The canvas to draw on
     */
    private void drawOverlay(Canvas canvas) {
        // 1. Capture the board content into a bitmap
        if (blurBitmap == null || blurBitmap.getWidth() != (int) boardRect.width() ||
                blurBitmap.getHeight() != (int) boardRect.height()) {
            blurBitmap = Bitmap.createBitmap((int) boardRect.width(),
                    (int) boardRect.height(), Bitmap.Config.ARGB_8888);
            blurCanvas = new Canvas(blurBitmap);
        }

        // Draw the board content onto the bitmap
        blurCanvas.save();
        blurCanvas.translate(-boardRect.left, -boardRect.top);
        super.onDraw(blurCanvas);
        blurCanvas.restore();

        // 2. Apply fast blur
        Bitmap blurred = fastBlur(blurBitmap, BLUR_RADIUS);

        // 3. Draw the blurred bitmap with a dark tint over the board area
        canvas.save();
        canvas.clipRect(boardRect);

        // Draw blurred board
        canvas.drawBitmap(blurred, boardRect.left, boardRect.top, null);

        // Add dark tint
        Paint tint = new Paint();
        tint.setColor(0xCC000000);
        canvas.drawRect(boardRect, tint);

        // 4. Draw overlay text centered on the board
        String message;
        if (isPaused) {
            message = PAUSE_EMOJI + " PAUSED";
        } else {
            message = COMPLETED_EMOJI + " LEVEL COMPLETE! " + COMPLETED_EMOJI;
        }

        float centerX = boardRect.centerX();
        float centerY = boardRect.centerY() - (isPaused ? 0 : 20f);

        // Draw main message
        overlayTextPaint.setTextSize(Math.min(cellSize * 0.7f, 32f));
        overlayTextPaint.setShadowLayer(8f, 0f, 0f, 0xAA000000);
        canvas.drawText(message, centerX, centerY, overlayTextPaint);

        // Draw sub-text for completion
        if (!isPaused) {
            overlayTextPaint.setTextSize(Math.min(cellSize * 0.45f, 18f));
            String subText = "Moving to the next level...";
            canvas.drawText(subText, centerX, centerY + overlayTextPaint.getTextSize() + 12f,
                    overlayTextPaint);
        }

        overlayTextPaint.setShadowLayer(0, 0, 0, 0);
        canvas.restore();
    }

    // ========================================================================
    // Blur Utilities
    // ========================================================================

    /**
     * Fast blur using a downscaled bitmap and box blur.
     *
     * @param source The source bitmap
     * @param radius The blur radius
     * @return The blurred bitmap
     */
    private Bitmap fastBlur(Bitmap source, int radius) {
        // Scale down to 1/4 size for speed
        int w = source.getWidth() / BLUR_SCALE_FACTOR;
        int h = source.getHeight() / BLUR_SCALE_FACTOR;
        if (w < 1) w = 1;
        if (h < 1) h = 1;

        Bitmap small = Bitmap.createScaledBitmap(source, w, h, true);

        // Apply box blur (2 passes)
        small = boxBlur(small, radius / 2);
        small = boxBlur(small, radius / 2);

        // Scale back up
        return Bitmap.createScaledBitmap(small, source.getWidth(), source.getHeight(), true);
    }

    /**
     * Applies a box blur to a bitmap.
     *
     * @param src The source bitmap
     * @param radius The blur radius
     * @return The blurred bitmap
     */
    private Bitmap boxBlur(Bitmap src, int radius) {
        if (radius < 1) return src;

        int w = src.getWidth();
        int h = src.getHeight();
        int[] pixels = new int[w * h];
        src.getPixels(pixels, 0, w, 0, 0, w, h);

        // Horizontal pass
        int[] tmp = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0, a = 0;
                int count = 0;
                for (int dx = -radius; dx <= radius; dx++) {
                    int nx = x + dx;
                    if (nx >= 0 && nx < w) {
                        int idx = y * w + nx;
                        r += (pixels[idx] >> 16) & 0xFF;
                        g += (pixels[idx] >> 8) & 0xFF;
                        b += pixels[idx] & 0xFF;
                        a += (pixels[idx] >> 24) & 0xFF;
                        count++;
                    }
                }
                int idx = y * w + x;
                tmp[idx] = (a / count) << 24 | (r / count) << 16 |
                        (g / count) << 8 | (b / count);
            }
        }

        // Vertical pass
        int[] out = new int[w * h];
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int r = 0, g = 0, b = 0, a = 0;
                int count = 0;
                for (int dy = -radius; dy <= radius; dy++) {
                    int ny = y + dy;
                    if (ny >= 0 && ny < h) {
                        int idx = ny * w + x;
                        r += (tmp[idx] >> 16) & 0xFF;
                        g += (tmp[idx] >> 8) & 0xFF;
                        b += tmp[idx] & 0xFF;
                        a += (tmp[idx] >> 24) & 0xFF;
                        count++;
                    }
                }
                int idx = y * w + x;
                out[idx] = (a / count) << 24 | (r / count) << 16 |
                        (g / count) << 8 | (b / count);
            }
        }

        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        result.setPixels(out, 0, w, 0, 0, w, h);
        return result;
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (popAnimator != null) {
            popAnimator.cancel();
            popAnimator = null;
        }
        if (blurBitmap != null) {
            blurBitmap.recycle();
            blurBitmap = null;
        }
    }
}