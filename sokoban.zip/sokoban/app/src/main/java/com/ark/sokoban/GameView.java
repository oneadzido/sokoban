package com.ark.sokoban;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * Custom view for rendering the Sokoban game board.
 *
 * <p>This view renders the game grid with emoji-based graphics for
 * walls, goals, boxes, and the player. It supports:</p>
 * <ul>
 *   <li>Efficient grid rendering with emojis</li>
 *   <li>Player pop animation on movement</li>
 *   <li>Completion overlay when level is finished</li>
 *   <li>Responsive sizing based on view dimensions</li>
 * </ul>
 *
 * File Location: app/src/main/java/com/ark/sokoban/GameView.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameView extends View {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Emoji for wall. */
    private static final String WALL_EMOJI = "🧱";

    /** Emoji for goal. */
    private static final String GOAL_EMOJI = "🎯";

    /** Emoji for box. */
    private static final String BOX_EMOJI = "📦";

    /** Emoji for player. */
    private static final String PLAYER_EMOJI = "🧒🏾";

    /** Emoji for level completion. */
    private static final String COMPLETED_EMOJI = "⭐";

    // ========================================================================
    // Game State
    // ========================================================================

    /** The current game grid. */
    private int[][] grid;

    /** Player's row position. */
    private int playerRow;

    /** Player's column position. */
    private int playerCol;

    /** Size of each cell in pixels. */
    private int cellSize;

    /** Grid width in cells. */
    private int gridWidth;

    /** Grid height in cells. */
    private int gridHeight;

    /** Whether the level is completed. */
    private boolean isCompleted;

    // ========================================================================
    // Drawing
    // ========================================================================

    /** Paint for drawing emojis. */
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Size of emoji icons in pixels. */
    private float iconSize;

    /** Vertical offset for emoji centering. */
    private final float yOffset = 0.1f;

    // ========================================================================
    // Animation
    // ========================================================================

    /** Current player scale for pop animation. */
    private float playerScale = 1.0f;

    /** Pop animation. */
    private ValueAnimator popAnimator;

    /** Whether to show the completion overlay. */
    private boolean showCompletionOverlay = false;

    // ========================================================================
    // Background
    // ========================================================================

    /** Rectangle for the board background. */
    private final RectF boardRect = new RectF();

    /** Paint for the board background. */
    private final Paint boardPaint = new Paint();

    /** Paint for the completion overlay. */
    private final Paint overlayPaint = new Paint();

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new GameView.
     *
     * @param context The context
     * @param attrs The attribute set
     */
    public GameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    // ========================================================================
    // Initialization
    // ========================================================================

    /**
     * Initializes the view.
     */
    private void init() {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(0xFF4D3E2B);

        boardPaint.setColor(0xFFD9CFC0);
        boardPaint.setStyle(Paint.Style.FILL);

        overlayPaint.setColor(0x80000000);

        initPopAnimation();
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    /**
     * Initializes the pop animation.
     */
    private void initPopAnimation() {
        popAnimator = ValueAnimator.ofFloat(1.05f, 1.0f);
        popAnimator.setDuration(150);
        popAnimator.addUpdateListener(animation -> {
            playerScale = (float) animation.getAnimatedValue();
            invalidate();
        });
        popAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                playerScale = 1.0f;
                invalidate();
            }
        });
    }

    // ========================================================================
    // Public Methods
    // ========================================================================

    /**
     * Updates the game state and triggers a redraw.
     *
     * @param grid The current game grid
     * @param playerRow The player's row position
     * @param playerCol The player's column position
     * @param completed Whether the level is completed
     */
    public void updateGameState(int[][] grid, int playerRow, int playerCol,
                                 boolean completed) {
        boolean playerMoved = (this.playerRow != playerRow || this.playerCol != playerCol)
                && this.grid != null;

        this.grid = grid;
        this.playerRow = playerRow;
        this.playerCol = playerCol;
        this.isCompleted = completed;
        this.showCompletionOverlay = completed;

        if (grid != null) {
            this.gridHeight = grid.length;
            this.gridWidth = grid[0].length;
        }

        if (playerMoved && !completed) {
            triggerPopAnimation();
        }

        requestLayout();
        invalidate();
    }

    /**
     * Triggers the pop animation for the player.
     */
    public void triggerPopAnimation() {
        if (popAnimator != null) {
            popAnimator.cancel();
            popAnimator.start();
        }
    }

    /**
     * Sets the completion state.
     *
     * @param completed Whether the level is completed
     */
    public void setCompleted(boolean completed) {
        this.isCompleted = completed;
        this.showCompletionOverlay = completed;
        invalidate();
    }

    /**
     * Hides the completion overlay.
     */
    public void hideCompletionOverlay() {
        showCompletionOverlay = false;
        invalidate();
    }

    // ========================================================================
    // View Lifecycle
    // ========================================================================

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int size = Math.min(MeasureSpec.getSize(widthMeasureSpec),
                MeasureSpec.getSize(heightMeasureSpec));
        setMeasuredDimension(size, size);

        if (gridWidth > 0 && gridHeight > 0) {
            cellSize = size / Math.max(gridWidth, gridHeight);
            if (cellSize < 10) cellSize = 10;
            iconSize = cellSize * 0.85f;
            paint.setTextSize(iconSize);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (grid == null) return;

        int viewSize = getWidth();
        int totalWidth = gridWidth * cellSize;
        int totalHeight = gridHeight * cellSize;
        float offsetX = (viewSize - totalWidth) / 2f;
        float offsetY = (viewSize - totalHeight) / 2f;

        // Draw board background
        boardRect.set(offsetX, offsetY, offsetX + totalWidth, offsetY + totalHeight);
        canvas.drawRoundRect(boardRect, 8f, 8f, boardPaint);

        // Draw grid cells
        paint.setTextSize(iconSize);
        float textOffset = iconSize * yOffset;

        for (int row = 0; row < gridHeight; row++) {
            for (int col = 0; col < gridWidth; col++) {
                float centerX = offsetX + col * cellSize + cellSize / 2f;
                float centerY = offsetY + row * cellSize + cellSize / 2f;
                int value = grid[row][col];

                // Draw wall
                if (value == 1) {
                    canvas.drawText(WALL_EMOJI, centerX, centerY + textOffset, paint);
                    continue;
                }

                // Draw goal (behind box)
                if (value == 2 || value == 5) {
                    canvas.drawText(GOAL_EMOJI, centerX, centerY + textOffset, paint);
                }

                // Draw box (on top of goal)
                if (value == 3 || value == 5) {
                    canvas.drawText(BOX_EMOJI, centerX, centerY + textOffset, paint);
                }
            }
        }

        // Draw player (on top of everything)
        if (playerRow >= 0 && playerRow < gridHeight
                && playerCol >= 0 && playerCol < gridWidth) {
            float playerX = offsetX + playerCol * cellSize + cellSize / 2f;
            float playerY = offsetY + playerRow * cellSize + cellSize / 2f;

            if (playerScale != 1.0f) {
                canvas.save();
                canvas.translate(playerX, playerY);
                canvas.scale(playerScale, playerScale);
                canvas.translate(-playerX, -playerY);
                canvas.drawText(PLAYER_EMOJI, playerX, playerY + textOffset, paint);
                canvas.restore();
            } else {
                canvas.drawText(PLAYER_EMOJI, playerX, playerY + textOffset, paint);
            }
        }

        // Draw completion overlay
        if (showCompletionOverlay) {
            canvas.drawRect(0, 0, getWidth(), getHeight(), overlayPaint);

            paint.setTextSize(Math.min(cellSize * 1.0f, 40f));
            paint.setFakeBoldText(true);
            String message = COMPLETED_EMOJI + " LEVEL COMPLETE! " + COMPLETED_EMOJI;
            canvas.drawText(message, getWidth() / 2f, getHeight() / 2f, paint);
            paint.setFakeBoldText(false);
            paint.setTextSize(iconSize);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (popAnimator != null) {
            popAnimator.cancel();
            popAnimator = null;
        }
    }
}