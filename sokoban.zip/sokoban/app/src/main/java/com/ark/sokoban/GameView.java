package com.ark.sokoban;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.ark.sokoban.GameViewModel.OverlayState;

/**
 * Custom view for rendering the Sokoban game board.
 *
 * <p>This view renders the game grid with emoji-based graphics for walls,
 * goals, boxes, and the player. It supports:</p>
 * <ul>
 *   <li>Emoji-only grid rendering — no board background is painted</li>
 *   <li>Player pop animation on movement</li>
 *   <li>An overlay that blurs the board behind a centered label</li>
 *   <li>Responsive sizing based on view dimensions</li>
 * </ul>
 *
 * <p>The board occupies the whole measured area. The cell size is derived
 * from the smaller of the horizontal and vertical slots so the grid stays
 * square inside the view, and any residual space left over by integer cell
 * division is split evenly around the grid.</p>
 *
 * <p>Emoji glyphs are centred using the paint's own ascent and descent so
 * the visual box of each glyph sits at the centre of its cell.</p>
 *
 * <h3>Overlay</h3>
 * <p>The overlay is driven by {@link OverlayState}. When the state is
 * {@code null} the sharp emojis are drawn directly. When the state is a
 * value of the enum, the sharp emojis are <b>not</b> drawn — the overlay
 * renders the blurred board behind a dark tint and a centered label, so
 * the only board content visible is the blurred copy.</p>
 *
 * <p>The overlay label depends on the state: a freshly loaded level shows
 * {@code "LEVEL " + levelNumber}, a paused level shows
 * {@code "LEVEL PAUSED"}, and a solved level shows
 * {@code "LEVEL SOLVED!"}. The solved overlay is delayed by
 * {@link #SOLVED_OVERLAY_DELAY_MS} so the final move remains visible
 * before the board blurs.</p>
 *
 * <p>The view paints no background. Gaps between emojis stay transparent
 * in every state, so the parent layout's colour shows through the
 * overlay's dark tint. This keeps the board visually emoji-only at all
 * times.</p>
 *
 * File Location: app/src/main/java/com/ark/sokoban/GameView.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameView extends View {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Downscale divisor for the fast blur pass. Blurs at 1/8 resolution. */
    private static final int BLUR_SCALE_FACTOR = 8;

    /** Blur radius, in downscaled pixels, applied twice in the fast blur. */
    private static final int BLUR_RADIUS = 5;

    /** Delay before the solved overlay appears, in milliseconds. */
    private static final int SOLVED_OVERLAY_DELAY_MS = 500;

    /** Dark tint drawn over the blurred board by the overlay. */
    private static final int OVERLAY_TINT_COLOR = 0xCC000000;

    /** Overlay label shown while the game is paused. */
    private static final String OVERLAY_TEXT_PAUSED = "LEVEL PAUSED";

    /** Overlay label shown when the level is solved. */
    private static final String OVERLAY_TEXT_SOLVED = "LEVEL SOLVED!";

    /** Prefix for the overlay label of a freshly loaded level. */
    private static final String OVERLAY_PREFIX_LEVEL = "LEVEL ";

    // ========================================================================
    // Game State
    // ========================================================================

    /** The current game grid. */
    private int[][] grid;

    /** Player's row position. */
    private int playerRow;

    /** Player's column position. */
    private int playerCol;

    /** Grid width in cells. */
    private int gridWidth;

    /** Grid height in cells. */
    private int gridHeight;

    /** Size of each cell in pixels. */
    private int cellSize;

    /**
     * Current overlay state, or {@code null} when the board is visible and
     * playable. The view mirrors the ViewModel's overlay state, with the
     * {@link OverlayState#LEVEL_SOLVED} value applied after the delay.
     */
    @Nullable
    private OverlayState overlayState;

    /** Level number shown on the overlay for a freshly loaded level. */
    private int levelNumber = 1;

    // ========================================================================
    // Drawing
    // ========================================================================

    /** Paint for the board emojis. */
    private final Paint emojiPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Paint for the overlay label. */
    private final Paint overlayTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Paint for the overlay dark tint. */
    private final Paint overlayTintPaint = new Paint();

    /** Emoji glyph size in pixels, derived from the cell size. */
    private float iconSize;

    /** Baseline offset that centres a glyph vertically inside its cell. */
    private float baselineOffset = 0f;

    // ========================================================================
    // Animation
    // ========================================================================

    /** Current player scale for the pop animation. */
    private float playerScale = 1.0f;

    /** Pop animation played when the player moves. */
    private ValueAnimator popAnimator;

    // ========================================================================
    // Blur
    // ========================================================================

    /** Offscreen bitmap that the emojis are rendered into for blurring. */
    private Bitmap blurBitmap;

    /** Canvas backed by {@link #blurBitmap}. */
    private Canvas blurCanvas;

    // ========================================================================
    // Handler
    // ========================================================================

    /** Handler used to delay the solved overlay. */
    private final Handler overlayHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new GameView.
     *
     * @param context The context
     * @param attrs The attribute set
     */
    public GameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    // ========================================================================
    // Initialization
    // ========================================================================

    /**
     * Initializes paints, animations, and focus behaviour.
     */
    private void init() {
        emojiPaint.setTextAlign(Paint.Align.CENTER);
        emojiPaint.setColor(0xFF4D3E2B);

        overlayTextPaint.setTextAlign(Paint.Align.CENTER);
        overlayTextPaint.setColor(0xFFFFFFFF);
        overlayTextPaint.setFakeBoldText(true);
        overlayTextPaint.setShadowLayer(8f, 0f, 0f, 0xAA000000);

        // Hoisted so the overlay does not allocate a Paint on every frame.
        overlayTintPaint.setColor(OVERLAY_TINT_COLOR);
        overlayTintPaint.setStyle(Paint.Style.FILL);

        initPopAnimation();

        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    /**
     * Builds the pop animation that briefly scales the player up when it
     * moves, then settles back to normal size.
     */
    private void initPopAnimation() {
        popAnimator = ValueAnimator.ofFloat(1.05f, 1.0f);
        popAnimator.setDuration(150);
        popAnimator.addUpdateListener(animation -> {
            playerScale = (float) animation.getAnimatedValue();
            invalidate();
        });
        popAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                playerScale = 1.0f;
                invalidate();
            }
        });
    }

    // ========================================================================
    // Public Methods
    // ========================================================================

    /**
     * Updates the game state and triggers a redraw.
     *
     * <p>When the player moves and the level is not solved, the pop
     * animation is played. The overlay is driven by
     * {@link #setOverlayState(OverlayState, int)} rather than this method,
     * so the two concerns stay separate.</p>
     *
     * @param grid The current game grid
     * @param playerRow The player's row position
     * @param playerCol The player's column position
     * @param solved Whether the level was just solved in this session
     */
    public void updateGameState(int[][] grid, int playerRow, int playerCol, boolean solved) {
        boolean playerMoved = (this.playerRow != playerRow || this.playerCol != playerCol)
                && this.grid != null;

        this.grid = grid;
        this.playerRow = playerRow;
        this.playerCol = playerCol;

        if (grid != null) {
            this.gridHeight = grid.length;
            this.gridWidth = grid[0].length;
        }

        if (playerMoved && !solved) {
            triggerPopAnimation();
        }

        requestLayout();
        invalidate();
    }

    /**
     * Sets the overlay state and triggers a redraw.
     *
     * <p>A {@code null} state means the board is visible and playable. Any
     * value of {@link OverlayState} means the board is covered by the
     * overlay, with the label chosen from the state. When the state is
     * {@link OverlayState#LEVEL_SOLVED}, the overlay is deferred by
     * {@link #SOLVED_OVERLAY_DELAY_MS} so the final move stays visible
     * before the board blurs.</p>
     *
     * @param state the overlay state, or {@code null} for no overlay
     * @param levelNumber the current level number shown on the
     *                    {@link OverlayState#LEVEL_LOADED} overlay
     */
    public void setOverlayState(@Nullable OverlayState state, int levelNumber) {
        this.levelNumber = levelNumber;

        overlayHandler.removeCallbacksAndMessages(null);

        if (state == OverlayState.LEVEL_SOLVED) {
            // Keep the board sharp briefly so the final move is visible.
            this.overlayState = null;
            invalidate();
            overlayHandler.postDelayed(() -> {
                this.overlayState = OverlayState.LEVEL_SOLVED;
                invalidate();
            }, SOLVED_OVERLAY_DELAY_MS);
            return;
        }

        this.overlayState = state;
        invalidate();
    }

    /**
     * Restarts the player pop animation from its first frame.
     */
    public void triggerPopAnimation() {
        if (popAnimator != null) {
            popAnimator.cancel();
            popAnimator.start();
        }
    }

    // ========================================================================
    // View Lifecycle
    // ========================================================================

    /**
     * Measures the view to fill the whole slot offered by the parent and
     * recomputes the cell size from the resulting dimensions.
     *
     * @param widthMeasureSpec The width measure spec
     * @param heightMeasureSpec The height measure spec
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);

        setMeasuredDimension(width, height);

        recalculateCellSize(width, height);
    }

    /**
     * Recomputes the cell size, emoji glyph size, baseline offset, and
     * overlay text size from the current view dimensions.
     *
     * <p>The cell size is the smaller of the horizontal and vertical slots
     * after dividing by the grid width and height, so the grid stays square
     * inside the view regardless of its aspect ratio. The baseline offset
     * is derived from the emoji paint's ascent and descent so the visual box
     * of each glyph sits at the centre of its cell.</p>
     *
     * @param width The view width in pixels
     * @param height The view height in pixels
     */
    private void recalculateCellSize(int width, int height) {
        if (gridWidth <= 0 || gridHeight <= 0) return;

        int cellByWidth = width / gridWidth;
        int cellByHeight = height / gridHeight;
        cellSize = Math.min(cellByWidth, cellByHeight);

        if (cellSize < 1) cellSize = 1;

        iconSize = cellSize * 0.85f;
        emojiPaint.setTextSize(iconSize);

        Paint.FontMetrics emojiMetrics = emojiPaint.getFontMetrics();
        baselineOffset = -(emojiMetrics.ascent + emojiMetrics.descent) / 2f;

        overlayTextPaint.setTextSize(Math.min(cellSize * 0.8f, 32f));
    }

    /**
     * Draws the board and, when active, the overlay.
     *
     * <p>When {@link #overlayState} is {@code null}, only the sharp emojis
     * are drawn. Otherwise the sharp emojis are <b>not</b> drawn — the
     * overlay replaces them with a blurred copy, so the board on screen is
     * entirely blurred.</p>
     *
     * @param canvas The canvas to draw on
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (grid == null) return;

        recalculateCellSize(getWidth(), getHeight());

        if (overlayState == null) {
            drawEmojis(canvas);
        } else {
            drawOverlay(canvas);
        }
    }

    // ========================================================================
    // Emoji Drawing
    // ========================================================================

    /**
     * Draws every board emoji — walls, goals, boxes, and the player — onto
     * the given canvas using the current cell size, grid, and player
     * position.
     *
     * <p>This method is the single source of emoji rendering. It is called
     * directly for normal play and again into the offscreen blur bitmap for
     * the overlay, so the blur sees exactly what the board looks like.</p>
     *
     * <p>No background is painted. The canvas is left transparent between
     * glyphs.</p>
     *
     * @param canvas The canvas to draw on
     */
    private void drawEmojis(Canvas canvas) {
        if (grid == null || cellSize <= 0) return;

        int totalWidth = gridWidth * cellSize;
        int totalHeight = gridHeight * cellSize;
        float offsetX = (getWidth() - totalWidth) / 2f;
        float offsetY = (getHeight() - totalHeight) / 2f;

        emojiPaint.setTextSize(iconSize);

        for (int row = 0; row < gridHeight; row++) {
            for (int col = 0; col < gridWidth; col++) {
                float centerX = offsetX + col * cellSize + cellSize / 2f;
                float centerY = offsetY + row * cellSize + cellSize / 2f;
                int value = grid[row][col];

                if (value == 1) {
                    canvas.drawText(EmojiConstants.WALL,
                            centerX, centerY + baselineOffset, emojiPaint);
                    continue;
                }

                if (value == 2 || value == 5) {
                    canvas.drawText(EmojiConstants.TARGET,
                            centerX, centerY + baselineOffset, emojiPaint);
                }

                if (value == 3 || value == 5) {
                    canvas.drawText(EmojiConstants.BOX,
                            centerX, centerY + baselineOffset, emojiPaint);
                }
            }
        }

        drawPlayer(canvas, offsetX, offsetY);
    }

    /**
     * Draws the player at its current grid position, applying the pop
     * animation scale when one is running.
     *
     * @param canvas The canvas to draw on
     * @param offsetX Horizontal offset of the grid inside the view
     * @param offsetY Vertical offset of the grid inside the view
     */
    private void drawPlayer(Canvas canvas, float offsetX, float offsetY) {
        if (playerRow < 0 || playerRow >= gridHeight
                || playerCol < 0 || playerCol >= gridWidth) {
            return;
        }

        float playerX = offsetX + playerCol * cellSize + cellSize / 2f;
        float playerY = offsetY + playerRow * cellSize + cellSize / 2f;

        if (playerScale == 1.0f) {
            canvas.drawText(EmojiConstants.PLAYER,
                    playerX, playerY + baselineOffset, emojiPaint);
            return;
        }

        canvas.save();
        canvas.translate(playerX, playerY);
        canvas.scale(playerScale, playerScale);
        canvas.translate(-playerX, -playerY);
        canvas.drawText(EmojiConstants.PLAYER,
                playerX, playerY + baselineOffset, emojiPaint);
        canvas.restore();
    }

    // ========================================================================
    // Overlay Drawing
    // ========================================================================

    /**
     * Draws the overlay.
     *
     * <p>The emojis are rendered into an offscreen bitmap via
     * {@link #drawEmojis(Canvas)}, blurred, and composited over the entire
     * view with a dark tint and centered label. Because the sharp emojis are
     * not drawn by {@link #onDraw(Canvas)} while the overlay is active, the
     * only board content visible is the blurred copy.</p>
     *
     * <p>The blur bitmap is transparent between glyphs, so the parent
     * layout's colour shows through the tint in those gaps.</p>
     *
     * @param canvas The canvas to draw on
     */
    private void drawOverlay(Canvas canvas) {
        int viewWidth = getWidth();
        int viewHeight = getHeight();

        if (viewWidth <= 0 || viewHeight <= 0 || grid == null) return;

        ensureBlurBitmap(viewWidth, viewHeight);

        blurCanvas.drawColor(0x00000000, PorterDuff.Mode.CLEAR);
        drawEmojis(blurCanvas);

        Bitmap blurred = fastBlur(blurBitmap, BLUR_RADIUS);

        canvas.save();
        canvas.drawBitmap(blurred, 0, 0, null);
        canvas.drawRect(0, 0, viewWidth, viewHeight, overlayTintPaint);
        drawOverlayLabel(canvas, viewWidth, viewHeight);
        canvas.restore();
    }

    /**
     * Ensures the offscreen blur bitmap and canvas match the current view
     * dimensions, reallocating them when the view size changes.
     *
     * @param viewWidth The current view width in pixels
     * @param viewHeight The current view height in pixels
     */
    private void ensureBlurBitmap(int viewWidth, int viewHeight) {
        if (blurBitmap != null
                && blurBitmap.getWidth() == viewWidth
                && blurBitmap.getHeight() == viewHeight) {
            return;
        }

        if (blurBitmap != null) {
            blurBitmap.recycle();
        }
        blurBitmap = Bitmap.createBitmap(viewWidth, viewHeight, Bitmap.Config.ARGB_8888);
        blurCanvas = new Canvas(blurBitmap);
    }

    /**
     * Draws the centered overlay label over the tinted, blurred board.
     *
     * @param canvas The canvas to draw on
     * @param viewWidth The current view width in pixels
     * @param viewHeight The current view height in pixels
     */
    private void drawOverlayLabel(Canvas canvas, int viewWidth, int viewHeight) {
        String message = overlayLabel();
        if (message.isEmpty()) return;

        float baseSize = Math.min(viewWidth, viewHeight) * 0.15f;
        float textSize = Math.max(Math.min(baseSize, 48f), 24f);
        overlayTextPaint.setTextSize(textSize);

        float centerX = viewWidth / 2f;
        float centerY = viewHeight / 2f;

        Paint.FontMetrics textMetrics = overlayTextPaint.getFontMetrics();
        float textY = centerY - (textMetrics.ascent + textMetrics.descent) / 2f;

        canvas.drawText(message, centerX, textY, overlayTextPaint);
    }

    /**
     * Returns the label to draw on the overlay for the current state.
     *
     * @return the overlay label
     */
    private String overlayLabel() {
        if (overlayState == null) return "";

        switch (overlayState) {
            case LEVEL_LOADED:
                return OVERLAY_PREFIX_LEVEL + levelNumber;
            case LEVEL_PAUSED:
                return OVERLAY_TEXT_PAUSED;
            case LEVEL_SOLVED:
                return OVERLAY_TEXT_SOLVED;
            default:
                return "";
        }
    }

    // ========================================================================
    // Blur Utilities
    // ========================================================================

    /**
     * Fast blur via downscale, two box-blur passes, and upscale.
     *
     * <p>The source is downscaled by {@link #BLUR_SCALE_FACTOR} before
     * blurring, so the convolution touches a fraction of the original
     * pixels. Because a blur is a low-pass filter, the visual result after
     * upscaling is close to a full-resolution blur at a fraction of the
     * cost.</p>
     *
     * @param source The source bitmap
     * @param radius The blur radius in downscaled pixels
     * @return The blurred bitmap, at the original dimensions
     */
    private Bitmap fastBlur(Bitmap source, int radius) {
        int w = Math.max(1, source.getWidth() / BLUR_SCALE_FACTOR);
        int h = Math.max(1, source.getHeight() / BLUR_SCALE_FACTOR);

        Bitmap small = Bitmap.createScaledBitmap(source, w, h, true);
        small = boxBlur(small, radius / 2);
        small = boxBlur(small, radius / 2);
        return Bitmap.createScaledBitmap(small, source.getWidth(), source.getHeight(), true);
    }

    /**
     * Applies a two-pass box blur to a bitmap, once horizontally and once
     * vertically.
     *
     * @param src The source bitmap
     * @param radius The blur radius
     * @return The blurred bitmap
     */
    private Bitmap boxBlur(Bitmap src, int radius) {
        if (radius < 1) return src;

        int w = src.getWidth();
        int h = src.getHeight();
        int[] pixels = new int[w * h];
        src.getPixels(pixels, 0, w, 0, 0, w, h);

        int[] horizontal = boxBlurHorizontal(pixels, w, h, radius);
        int[] vertical = boxBlurVertical(horizontal, w, h, radius);

        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        result.setPixels(vertical, 0, w, 0, 0, w, h);
        return result;
    }

    /**
     * Applies a horizontal box blur to a pixel buffer.
     *
     * @param pixels The source pixels
     * @param w The buffer width
     * @param h The buffer height
     * @param radius The blur radius
     * @return A new pixel buffer containing the horizontally blurred image
     */
    private int[] boxBlurHorizontal(int[] pixels, int w, int h, int radius) {
        int[] out = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0, a = 0, count = 0;
                for (int dx = -radius; dx <= radius; dx++) {
                    int nx = x + dx;
                    if (nx < 0 || nx >= w) continue;
                    int idx = y * w + nx;
                    r += (pixels[idx] >> 16) & 0xFF;
                    g += (pixels[idx] >> 8) & 0xFF;
                    b += pixels[idx] & 0xFF;
                    a += (pixels[idx] >> 24) & 0xFF;
                    count++;
                }
                out[y * w + x] = (a / count) << 24
                        | (r / count) << 16
                        | (g / count) << 8
                        | (b / count);
            }
        }
        return out;
    }

    /**
     * Applies a vertical box blur to a pixel buffer.
     *
     * @param pixels The source pixels
     * @param w The buffer width
     * @param h The buffer height
     * @param radius The blur radius
     * @return A new pixel buffer containing the vertically blurred image
     */
    private int[] boxBlurVertical(int[] pixels, int w, int h, int radius) {
        int[] out = new int[w * h];
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int r = 0, g = 0, b = 0, a = 0, count = 0;
                for (int dy = -radius; dy <= radius; dy++) {
                    int ny = y + dy;
                    if (ny < 0 || ny >= h) continue;
                    int idx = ny * w + x;
                    r += (pixels[idx] >> 16) & 0xFF;
                    g += (pixels[idx] >> 8) & 0xFF;
                    b += pixels[idx] & 0xFF;
                    a += (pixels[idx] >> 24) & 0xFF;
                    count++;
                }
                out[y * w + x] = (a / count) << 24
                        | (r / count) << 16
                        | (g / count) << 8
                        | (b / count);
            }
        }
        return out;
    }

    // ========================================================================
    // Cleanup
    // ========================================================================

    /**
     * Releases animations, handler callbacks, and bitmaps when the view is
     * detached from its window.
     */
    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        overlayHandler.removeCallbacksAndMessages(null);

        if (popAnimator != null) {
            popAnimator.cancel();
            popAnimator = null;
        }

        if (blurBitmap != null) {
            blurBitmap.recycle();
            blurBitmap = null;
        }
    }
}