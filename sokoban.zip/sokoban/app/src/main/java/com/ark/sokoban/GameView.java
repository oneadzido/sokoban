package com.ark.sokoban;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * Custom view for drawing the Sokoban game board.
 * 
 * <p>This view renders the grid using FontAwesome icons for walls, targets,
 * boxes, and the player. It scales the icons to fit the view size and
 * updates its state based on the ViewModel's LiveData.</p>
 * 
 * <p>The view uses a single Paint object with the FontAwesome typeface
 * set for consistent icon rendering. Each cell is drawn with the
 * appropriate icon and color.</p>
 * 
 * <p>Follows Google's recommendations for custom view implementation with
 * proper onMeasure and onDraw methods.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameView extends View {
    
    // ========================================================================
    // Constants - FontAwesome Icons
    // ========================================================================
    
    /** Wall icon. */
    private static final String ICON_WALL = FontAwesome.WALL;
    
    /** Target icon. */
    private static final String ICON_TARGET = FontAwesome.TARGET;
    
    /** Box icon. */
    private static final String ICON_BOX = FontAwesome.BOX;
    
    /** Player icon. */
    private static final String ICON_PLAYER = FontAwesome.PLAYER;
    
    /** Star icon (for completion overlay). */
    private static final String ICON_STAR = FontAwesome.STAR;
    
    // ========================================================================
    // State
    // ========================================================================
    
    /** The current grid to draw. */
    private int[][] grid;
    
    /** The player's row position. */
    private int playerRow;
    
    /** The player's column position. */
    private int playerCol;
    
    /** The size of each cell in pixels. */
    private int cellSize;
    
    /** The width of the grid in cells. */
    private int gridWidth;
    
    /** The height of the grid in cells. */
    private int gridHeight;
    
    /** Whether the level is completed. */
    private boolean isGameCompleted;
    
    /** The Paint object used for drawing. */
    private Paint paint;
    
    /** The size of the icons in pixels. */
    private float iconSize;
    
    // ========================================================================
    // Constructors
    // ========================================================================
    
    /**
     * Constructs a new GameView.
     *
     * @param context The context the view is running in.
     * @param attrs The attributes of the XML tag that is inflating the view.
     */
    public GameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initPaint();
    }
    
    // ========================================================================
    // Initialization
    // ========================================================================
    
    /**
     * Initializes the Paint object with the FontAwesome typeface.
     * 
     * <p>If the FontAwesome typeface is not yet loaded, the paint will use
     * the default typeface, and icons will not render. This is called
     * during construction.</p>
     */
    private void initPaint() {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextBaseline(Paint.Align.CENTER);
        if (FontAwesome.getTypeface() != null) {
            paint.setTypeface(FontAwesome.getTypeface());
        }
        // Default color (will be overridden per element)
        paint.setColor(0xFF4D3E2B);
    }
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Updates the game state and triggers a redraw.
     * 
     * <p>This method is called by the ViewModel when the grid changes.
     * It stores the new grid, player position, and completion flag,
     * then requests a redraw via invalidate().</p>
     *
     * @param newGrid The new grid state. May be null.
     * @param newPlayerRow The player's row position.
     * @param newPlayerCol The player's column position.
     * @param completed Whether the level is completed.
     */
    public void updateGameState(int[][] newGrid, int newPlayerRow, int newPlayerCol, boolean completed) {
        this.grid = newGrid;
        this.playerRow = newPlayerRow;
        this.playerCol = newPlayerCol;
        this.isGameCompleted = completed;
        if (newGrid != null) {
            this.gridHeight = newGrid.length;
            this.gridWidth = newGrid[0].length;
        }
        invalidate();
    }
    
    // ========================================================================
    // View Overrides
    // ========================================================================
    
    /**
     * Measures the view and calculates the cell size.
     * 
     * <p>The view is made square, and the cell size is derived from
     * the largest dimension (grid width or height). The icon size is
     * then set to 82% of the cell size for optimal spacing.</p>
     *
     * @param widthMeasureSpec The width measure spec.
     * @param heightMeasureSpec The height measure spec.
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int size = Math.min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec));
        setMeasuredDimension(size, size);
        if (gridWidth > 0 && gridHeight > 0) {
            cellSize = size / Math.max(gridWidth, gridHeight);
            if (cellSize < 10) cellSize = 10;
            iconSize = cellSize * 0.82f;
            paint.setTextSize(iconSize);
        }
    }
    
    /**
     * Draws the game board.
     * 
     * <p>This method iterates over the grid and draws the appropriate
     * FontAwesome icon at each cell. The player is drawn on top of
     * everything else. If the level is completed, a semi-transparent
     * overlay with a star is drawn.</p>
     * 
     * <p>Cell values:</p>
     * <ul>
     *   <li>1: Wall</li>
     *   <li>2: Goal</li>
     *   <li>3: Box</li>
     *   <li>4: Player (not used in grid)</li>
     *   <li>5: Box on goal</li>
     *   <li>6: Player on goal (not used)</li>
     * </ul>
     *
     * @param canvas The canvas to draw on.
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (grid == null) return;
        
        int viewSize = getWidth();
        int totalGridWidth = gridWidth * cellSize;
        int totalGridHeight = gridHeight * cellSize;
        int offsetX = (viewSize - totalGridWidth) / 2;
        int offsetY = (viewSize - totalGridHeight) / 2;
        
        for (int row = 0; row < gridHeight; row++) {
            for (int col = 0; col < gridWidth; col++) {
                float centerX = offsetX + col * cellSize + cellSize / 2f;
                float centerY = offsetY + row * cellSize + cellSize / 2f;
                int cellValue = grid[row][col];
                
                // Wall
                if (cellValue == 1) {
                    paint.setColor(0xFF5A4A3A); // dark brown
                    canvas.drawText(ICON_WALL, centerX, centerY, paint);
                    continue;
                }
                
                // Target (goal)
                if (cellValue == 2 || cellValue == 5) {
                    paint.setColor(0xFFC4A050); // golden
                    canvas.drawText(ICON_TARGET, centerX, centerY, paint);
                }
                
                // Box
                if (cellValue == 3 || cellValue == 5) {
                    paint.setColor(0xFF8A6A30); // wooden brown
                    canvas.drawText(ICON_BOX, centerX, centerY, paint);
                }
            }
        }
        
        // Player (on top)
        if (playerRow >= 0 && playerCol >= 0) {
            float playerX = offsetX + playerCol * cellSize + cellSize / 2f;
            float playerY = offsetY + playerRow * cellSize + cellSize / 2f;
            paint.setColor(0xFF3366AA); // blue
            canvas.drawText(ICON_PLAYER, playerX, playerY, paint);
        }
        
        // Completion overlay
        if (isGameCompleted) {
            canvas.drawColor(0x80000000); // semi-transparent black
            paint.setColor(0xFFC9A84C); // gold
            float textSize = Math.min(cellSize * 1.2f, 48f);
            paint.setTextSize(textSize);
            paint.setFakeBoldText(true);
            String completeText = ICON_STAR + " COMPLETE! " + ICON_STAR;
            canvas.drawText(completeText, getWidth() / 2f, getHeight() / 2f, paint);
            paint.setFakeBoldText(false);
            paint.setTextSize(iconSize);
        }
    }
}