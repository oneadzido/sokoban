package com.ark.sokoban;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * Custom view for drawing the Sokoban game board using emojis.
 * 
 * <p>This view renders the grid using emojis for walls, targets, boxes,
 * and the player. It scales the emojis to fit the view size and updates
 * its state based on the ViewModel's LiveData.</p>
 * 
 * <p>The view uses a single Paint object with emoji-compatible rendering.
 * Each cell is drawn with the appropriate emoji and color.</p>
 * 
 * <p>Features:</p>
 * <ul>
 *   <li><b>Emoji-based rendering:</b> Uses emojis instead of FontAwesome</li>
 *   <li><b>Pop animation:</b> Player scales from 105% to 100% when moving</li>
 *   <li><b>Completion overlay:</b> Shows "⭐ LEVEL COMPLETE! ⭐" on level completion</li>
 * </ul>
 * 
 * <p>Cell values:</p>
 * <ul>
 *   <li>0: Floor</li>
 *   <li>1: Wall</li>
 *   <li>2: Goal (target)</li>
 *   <li>3: Box</li>
 *   <li>4: Player (not used in grid)</li>
 *   <li>5: Box on goal</li>
 *   <li>6: Player on goal (not used)</li>
 * </ul>
 * 
 * <p>Follows Google's recommendations for custom view implementation with
 * proper onMeasure and onDraw methods.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameView extends View {
    
    // ========================================================================
    // Emoji Constants - Using centralized definitions
    // ========================================================================
    
    /** Wall emoji from EmojiConstants. */
    private static final String ICON_WALL = EmojiConstants.WALL;
    
    /** Target emoji from EmojiConstants. */
    private static final String ICON_TARGET = EmojiConstants.GOAL;
    
    /** Box emoji from EmojiConstants. */
    private static final String ICON_BOX = EmojiConstants.BOX;
    
    /** Player emoji from EmojiConstants. */
    private static final String ICON_PLAYER = EmojiConstants.PLAYER;
    
    /** Completion message with star emojis. */
    private static final String MESSAGE_OVERLAY = EmojiConstants.STAR + " LEVEL COMPLETE! " + EmojiConstants.STAR;
    
    // ========================================================================
    // Game State
    // ========================================================================
    
    /** The current grid to draw. */
    private int[][] grid;
    
    /** The player's row position. */
    private int playerRow;
    
    /** The player's column position. */
    private int playerCol;
    
    /** The size of each cell in pixels. */
    private int cellSize;
    
    /** The width of the grid in cells. */
    private int gridWidth;
    
    /** The height of the grid in cells. */
    private int gridHeight;
    
    /** Whether the level is completed. */
    private boolean isGameCompleted;
    
    /** The Paint object used for drawing. */
    private Paint paint;
    
    /** The size of the emojis in pixels. */
    private float iconSize;
    
    // ========================================================================
    // Animation - Simple Pop Effect (105% → 100%)
    // ========================================================================
    
    /** Current scale of the player emoji (1.0 = normal size). */
    private float playerScale = 1.0f;
    
    /** Animator for the pop effect. */
    private ValueAnimator popAnimator;
    
    // ========================================================================
    // Constructors
    // ========================================================================
    
    /**
     * Constructs a new GameView.
     *
     * @param context The context the view is running in.
     * @param attrs The attributes of the XML tag that is inflating the view.
     */
    public GameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initPaint();
        initPopAnimator();
    }
    
    // ========================================================================
    // Initialization
    // ========================================================================
    
    /**
     * Initializes the Paint object for emoji rendering.
     */
    private void initPaint() {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(0xFF4D3E2B);
    }
    
    /**
     * Initializes the pop animation for player movement.
     * The animation scales the player from 105% to 100% in 150ms.
     */
    private void initPopAnimator() {
        popAnimator = new ValueAnimator();
        popAnimator.setDuration(150);
        popAnimator.addUpdateListener(animation -> {
            playerScale = (float) animation.getAnimatedValue();
            invalidate();
        });
        popAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                playerScale = 1.0f;
                invalidate();
            }
        });
    }
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Updates the game state and triggers a redraw.
     * 
     * <p>This method is called by the ViewModel when the grid changes.
     * It stores the new grid, player position, and completion flag,
     * then triggers the pop animation if the player moved.</p>
     *
     * @param newGrid The new grid state. May be null.
     * @param newPlayerRow The player's row position.
     * @param newPlayerCol The player's column position.
     * @param completed Whether the level is completed.
     */
    public void updateGameState(int[][] newGrid, int newPlayerRow, int newPlayerCol, boolean completed) {
        boolean playerMoved = (this.playerRow != newPlayerRow || this.playerCol != newPlayerCol) 
                              && this.grid != null;
        
        this.grid = newGrid;
        this.playerRow = newPlayerRow;
        this.playerCol = newPlayerCol;
        this.isGameCompleted = completed;
        
        if (newGrid != null) {
            this.gridHeight = newGrid.length;
            this.gridWidth = newGrid[0].length;
        }
        
        if (playerMoved && !isGameCompleted) {
            startPopAnimation();
        }
        
        invalidate();
    }
    
    /**
     * Starts the pop animation for the player.
     * The player scales from 105% to 100% in 150ms.
     */
    public void startPopAnimation() {
        if (popAnimator != null) {
            popAnimator.cancel();
            popAnimator.setFloatValues(1.05f, 1.0f);
            popAnimator.start();
        }
    }
    
    // ========================================================================
    // View Overrides
    // ========================================================================
    
    /**
     * Measures the view and calculates the cell size.
     * 
     * <p>The view is made square, and the cell size is derived from
     * the largest dimension (grid width or height). The icon size is
     * then set to 82% of the cell size for optimal spacing.</p>
     *
     * @param widthMeasureSpec The width measure spec.
     * @param heightMeasureSpec The height measure spec.
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int size = Math.min(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec));
        setMeasuredDimension(size, size);
        if (gridWidth > 0 && gridHeight > 0) {
            cellSize = size / Math.max(gridWidth, gridHeight);
            if (cellSize < 10) cellSize = 10;
            iconSize = cellSize * 0.82f;
            paint.setTextSize(iconSize);
        }
    }
    
    /**
     * Draws the game board using emojis.
     * 
     * <p>This method iterates over the grid and draws the appropriate
     * emoji at each cell. The player is drawn on top of everything else.
     * If the level is completed, a semi-transparent overlay with a star
     * is drawn.</p>
     * 
     * <p>Cell values:</p>
     * <ul>
     *   <li>1: Wall</li>
     *   <li>2: Goal</li>
     *   <li>3: Box</li>
     *   <li>4: Player (not used in grid)</li>
     *   <li>5: Box on goal</li>
     *   <li>6: Player on goal (not used)</li>
     * </ul>
     *
     * @param canvas The canvas to draw on.
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (grid == null) return;
        
        int viewSize = getWidth();
        int totalGridWidth = gridWidth * cellSize;
        int totalGridHeight = gridHeight * cellSize;
        int offsetX = (viewSize - totalGridWidth) / 2;
        int offsetY = (viewSize - totalGridHeight) / 2;
        
        paint.setTypeface(null);
        paint.setTextSize(iconSize);
        
        // ─── Draw grid ──────────────────────────────────────────────────────
        for (int row = 0; row < gridHeight; row++) {
            for (int col = 0; col < gridWidth; col++) {
                float centerX = offsetX + col * cellSize + cellSize / 2f;
                float centerY = offsetY + row * cellSize + cellSize / 2f;
                int cellValue = grid[row][col];
                
                // Wall
                if (cellValue == 1) {
                    canvas.drawText(ICON_WALL, centerX, centerY, paint);
                    continue;
                }
                
                // Target (goal)
                if (cellValue == 2 || cellValue == 5) {
                    canvas.drawText(ICON_TARGET, centerX, centerY, paint);
                }
                
                // Box
                if (cellValue == 3 || cellValue == 5) {
                    canvas.drawText(ICON_BOX, centerX, centerY, paint);
                }
            }
        }
        
        // ─── Draw player with pop effect ──────────────────────────────────
        if (playerRow >= 0 && playerCol >= 0) {
            float playerX = offsetX + playerCol * cellSize + cellSize / 2f;
            float playerY = offsetY + playerRow * cellSize + cellSize / 2f;
            
            if (playerScale != 1.0f) {
                canvas.save();
                canvas.translate(playerX, playerY);
                canvas.scale(playerScale, playerScale);
                canvas.translate(-playerX, -playerY);
                canvas.drawText(ICON_PLAYER, playerX, playerY, paint);
                canvas.restore();
            } else {
                canvas.drawText(ICON_PLAYER, playerX, playerY, paint);
            }
        }
        
        // ─── Completion overlay ────────────────────────────────────────────
        if (isGameCompleted) {
            canvas.drawColor(0x80000000);
            float textSize = Math.min(cellSize * 1.2f, 48f);
            paint.setTextSize(textSize);
            paint.setFakeBoldText(true);
            canvas.drawText(MESSAGE_OVERLAY, getWidth() / 2f, getHeight() / 2f, paint);
            paint.setFakeBoldText(false);
            paint.setTextSize(iconSize);
        }
    }
}