package com.ark.sokoban;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * Custom view for rendering the Sokoban game board.
 *
 * <p>This view renders the game grid with emoji-based graphics for
 * walls, goals, boxes, and the player. It supports:</p>
 * <ul>
 *   <li>Efficient grid rendering with emojis</li>
 *   <li>Player pop animation on movement</li>
 *   <li>Paused overlay when game is paused</li>
 *   <li>Solved overlay when level is solved (with 500ms delay)</li>
 *   <li>Blur effect on overlays to prevent cheating</li>
 *   <li>Responsive sizing based on view dimensions</li>
 * </ul>
 *
 * <p>The board occupies the whole measured area. The cell size is derived
 * from the smaller of the horizontal and vertical slots so the grid stays
 * square on the inside of the view, and any residual space left over by
 * integer cell division is split evenly around the grid.</p>
 *
 * <p>Emoji glyphs are centred using the paint's own ascent and descent so
 * the visual box of each glyph sits at the centre of its cell.</p>
 *
 * <p>The overlays (paused and solved) are drawn <b>over the entire view area</b>
 * with text only (no icons).</p>
 *
 * File Location: app/src/main/java/com/ark/sokoban/GameView.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameView extends View {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Blur radius for overlay effect. */
    private static final int BLUR_RADIUS = 10;

    /** Scale factor for fast blur (1/2 size). */
    private static final int BLUR_SCALE_FACTOR = 8;

    /** Delay before showing solved overlay in milliseconds. */
    private static final int SOLVED_OVERLAY_DELAY_MS = 500;

    /** Overlay text for paused state. */
    private static final String OVERLAY_TEXT_PAUSED = "LEVEL PAUSED";

    /** Overlay text for solved state. */
    private static final String OVERLAY_TEXT_SOLVED = "LEVEL SOLVED!";

    // ========================================================================
    // Game State
    // ========================================================================

    /** The current game grid. */
    private int[][] grid;

    /** Player's row position. */
    private int playerRow;

    /** Player's column position. */
    private int playerCol;

    /** Size of each cell in pixels. */
    private int cellSize;

    /** Grid width in cells. */
    private int gridWidth;

    /** Grid height in cells. */
    private int gridHeight;

    /** Whether the level is solved. */
    private boolean isSolved;

    /** Whether the game is paused. */
    private boolean isPaused;

    /** Whether the solved overlay is visible (delayed). */
    private boolean overlayVisible = false;

    // ========================================================================
    // Drawing
    // ========================================================================

    /** Paint for drawing emojis. */
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    /** Size of emoji icons in pixels. */
    private float iconSize;

    /** Baseline offset from the cell centre, computed from the font metrics. */
    private float baselineOffset = 0f;

    /** Rectangle for the board area (exactly the grid size). */
    private final RectF boardRect = new RectF();

    /** Paint for the board background. */
    private final Paint boardPaint = new Paint();

    /** Paint for overlay text. */
    private final Paint overlayTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ========================================================================
    // Animation
    // ========================================================================

    /** Current player scale for pop animation. */
    private float playerScale = 1.0f;

    /** Pop animation. */
    private ValueAnimator popAnimator;

    // ========================================================================
    // Blur
    // ========================================================================

    /** Bitmap for blurring the board. */
    private Bitmap blurBitmap;

    /** Canvas for drawing the board into the blur bitmap. */
    private Canvas blurCanvas;

    // ========================================================================
    // Handler
    // ========================================================================

    /** Handler for delayed overlay display. */
    private final Handler overlayHandler = new Handler(Looper.getMainLooper());

    // ========================================================================
    // Constructor
    // ========================================================================

    /**
     * Constructs a new GameView.
     *
     * @param context The context
     * @param attrs The attribute set
     */
    public GameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    // ========================================================================
    // Initialization
    // ========================================================================

    /**
     * Initializes the view by setting up paints and animations.
     */
    private void init() {
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(0xFF4D3E2B);

        boardPaint.setColor(0xFFD9CFC0);
        boardPaint.setStyle(Paint.Style.FILL);

        overlayTextPaint.setTextAlign(Paint.Align.CENTER);
        overlayTextPaint.setColor(0xFFFFFFFF);
        overlayTextPaint.setFakeBoldText(true);
        overlayTextPaint.setShadowLayer(8f, 0f, 0f, 0xAA000000);

        initPopAnimation();
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    /**
     * Initializes the player pop animation that triggers on movement.
     */
    private void initPopAnimation() {
        popAnimator = ValueAnimator.ofFloat(1.05f, 1.0f);
        popAnimator.setDuration(150);
        popAnimator.addUpdateListener(animation -> {
            playerScale = (float) animation.getAnimatedValue();
            invalidate();
        });
        popAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                playerScale = 1.0f;
                invalidate();
            }
        });
    }

    // ========================================================================
    // Public Methods
    // ========================================================================

    /**
     * Updates the game state and triggers a redraw.
     *
     * @param grid The current game grid
     * @param playerRow The player's row position
     * @param playerCol The player's column position
     * @param solved Whether the level was just solved in this session
     */
    public void updateGameState(int[][] grid, int playerRow, int playerCol, boolean solved) {
        boolean playerMoved = (this.playerRow != playerRow || this.playerCol != playerCol)
                && this.grid != null;

        this.grid = grid;
        this.playerRow = playerRow;
        this.playerCol = playerCol;
        this.isSolved = solved;

        if (grid != null) {
            this.gridHeight = grid.length;
            this.gridWidth = grid[0].length;
        }

        if (playerMoved && !solved) {
            triggerPopAnimation();
        }

        overlayHandler.removeCallbacksAndMessages(null);
        if (solved) {
            overlayVisible = false;
            overlayHandler.postDelayed(() -> {
                overlayVisible = true;
                invalidate();
            }, SOLVED_OVERLAY_DELAY_MS);
        } else {
            overlayVisible = false;
        }

        requestLayout();
        invalidate();
    }

    /**
     * Sets the paused state and triggers a redraw.
     *
     * @param paused True if the game is paused
     */
    public void setPaused(boolean paused) {
        this.isPaused = paused;
        if (paused) {
            overlayHandler.removeCallbacksAndMessages(null);
            overlayVisible = false;
        }
        invalidate();
    }

    /**
     * Triggers the pop animation for the player.
     */
    public void triggerPopAnimation() {
        if (popAnimator != null) {
            popAnimator.cancel();
            popAnimator.start();
        }
    }

    // ========================================================================
    // View Lifecycle
    // ========================================================================

    /**
     * Measures the view to fill the whole slot offered by the parent.
     *
     * <p>This view consumes the entire area its parent gives it. The grid
     * inside is drawn square, using the smaller of the two dimensions to
     * compute the cell size, and the residual space left over by integer
     * cell division is split evenly around the grid.</p>
     *
     * @param widthMeasureSpec The width measure spec
     * @param heightMeasureSpec The height measure spec
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);

        setMeasuredDimension(width, height);

        recalculateCellSize(width, height);
    }

    /**
     * Recomputes the cell size and the baseline offset from the current
     * view dimensions.
     *
     * <p>The cell size is the smaller of the horizontal and vertical slots
     * after dividing by the grid width and height, so the grid stays square
     * inside the view regardless of its aspect ratio. The baseline offset
     * is derived from the paint's ascent and descent so the visual box of
     * each emoji glyph sits at the centre of its cell.</p>
     *
     * @param width The view width in pixels
     * @param height The view height in pixels
     */
    private void recalculateCellSize(int width, int height) {
        if (gridWidth <= 0 || gridHeight <= 0) return;

        int cellByWidth = width / gridWidth;
        int cellByHeight = height / gridHeight;
        cellSize = Math.min(cellByWidth, cellByHeight);

        if (cellSize < 1) cellSize = 1;

        iconSize = cellSize * 0.85f;
        paint.setTextSize(iconSize);

        Paint.FontMetrics fm = paint.getFontMetrics();
        baselineOffset = -(fm.ascent + fm.descent) / 2f;

        overlayTextPaint.setTextSize(Math.min(cellSize * 0.8f, 32f));
    }

    /**
     * Draws the game board including grid cells, player, and overlays.
     *
     * <p>The grid is centred horizontally and vertically inside the view.
     * Each glyph is drawn with its baseline offset by the paint's font
     * metrics so the visual box of the glyph sits at the centre of the
     * cell.</p>
     *
     * @param canvas The canvas to draw on
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (grid == null) return;

        recalculateCellSize(getWidth(), getHeight());

        int totalWidth = gridWidth * cellSize;
        int totalHeight = gridHeight * cellSize;
        float offsetX = (getWidth() - totalWidth) / 2f;
        float offsetY = (getHeight() - totalHeight) / 2f;

        boardRect.set(offsetX, offsetY, offsetX + totalWidth, offsetY + totalHeight);
        canvas.drawRoundRect(boardRect, 8f, 8f, boardPaint);

        paint.setTextSize(iconSize);

        for (int row = 0; row < gridHeight; row++) {
            for (int col = 0; col < gridWidth; col++) {
                float centerX = offsetX + col * cellSize + cellSize / 2f;
                float centerY = offsetY + row * cellSize + cellSize / 2f;
                int value = grid[row][col];

                if (value == 1) {
                    canvas.drawText(EmojiConstants.WALL,
                            centerX, centerY + baselineOffset, paint);
                    continue;
                }

                if (value == 2 || value == 5) {
                    canvas.drawText(EmojiConstants.TARGET,
                            centerX, centerY + baselineOffset, paint);
                }

                if (value == 3 || value == 5) {
                    canvas.drawText(EmojiConstants.BOX,
                            centerX, centerY + baselineOffset, paint);
                }
            }
        }

        if (playerRow >= 0 && playerRow < gridHeight
                && playerCol >= 0 && playerCol < gridWidth) {
            float playerX = offsetX + playerCol * cellSize + cellSize / 2f;
            float playerY = offsetY + playerRow * cellSize + cellSize / 2f;

            if (playerScale != 1.0f) {
                canvas.save();
                canvas.translate(playerX, playerY);
                canvas.scale(playerScale, playerScale);
                canvas.translate(-playerX, -playerY);
                canvas.drawText(EmojiConstants.PLAYER,
                        playerX, playerY + baselineOffset, paint);
                canvas.restore();
            } else {
                canvas.drawText(EmojiConstants.PLAYER,
                        playerX, playerY + baselineOffset, paint);
            }
        }

        if (isPaused || overlayVisible) {
            drawOverlay(canvas);
        }
    }

    // ========================================================================
    // Overlay Drawing
    // ========================================================================

    /**
     * Draws the overlay (paused or solved) over the entire view area.
     * Applies a blur effect with dark tint and centered text.
     *
     * @param canvas The canvas to draw on
     */
    private void drawOverlay(Canvas canvas) {
        int viewWidth = getWidth();
        int viewHeight = getHeight();

        if (viewWidth <= 0 || viewHeight <= 0 || grid == null) return;

        if (blurBitmap == null || blurBitmap.getWidth() != viewWidth ||
                blurBitmap.getHeight() != viewHeight) {
            if (blurBitmap != null) {
                blurBitmap.recycle();
            }
            blurBitmap = Bitmap.createBitmap(viewWidth, viewHeight, Bitmap.Config.ARGB_8888);
            blurCanvas = new Canvas(blurBitmap);
        }

        blurCanvas.drawColor(0x00000000, android.graphics.PorterDuff.Mode.CLEAR);
        super.onDraw(blurCanvas);

        Bitmap blurred = fastBlur(blurBitmap, BLUR_RADIUS);

        canvas.save();
        canvas.drawBitmap(blurred, 0, 0, null);

        Paint tint = new Paint();
        tint.setColor(0xCC000000);
        canvas.drawRect(0, 0, viewWidth, viewHeight, tint);

        String message = isPaused ? OVERLAY_TEXT_PAUSED : OVERLAY_TEXT_SOLVED;

        float baseSize = Math.min(viewWidth, viewHeight) * 0.15f;
        float textSize = Math.max(Math.min(baseSize, 48f), 24f);

        overlayTextPaint.setTextSize(textSize);
        overlayTextPaint.setShadowLayer(8f, 0f, 0f, 0xAA000000);

        float centerX = viewWidth / 2f;
        float centerY = viewHeight / 2f;

        Paint.FontMetrics fm = overlayTextPaint.getFontMetrics();
        float textY = centerY - (fm.ascent + fm.descent) / 2f;

        canvas.drawText(message, centerX, textY, overlayTextPaint);

        overlayTextPaint.setShadowLayer(0, 0, 0, 0);
        canvas.restore();
    }

    // ========================================================================
    // Blur Utilities
    // ========================================================================

    /**
     * Fast blur using a downscaled bitmap and box blur.
     *
     * @param source The source bitmap
     * @param radius The blur radius
     * @return The blurred bitmap
     */
    private Bitmap fastBlur(Bitmap source, int radius) {
        int w = source.getWidth() / BLUR_SCALE_FACTOR;
        int h = source.getHeight() / BLUR_SCALE_FACTOR;
        if (w < 1) w = 1;
        if (h < 1) h = 1;

        Bitmap small = Bitmap.createScaledBitmap(source, w, h, true);
        small = boxBlur(small, radius / 2);
        small = boxBlur(small, radius / 2);
        return Bitmap.createScaledBitmap(small, source.getWidth(), source.getHeight(), true);
    }

    /**
     * Applies a box blur to a bitmap.
     *
     * @param src The source bitmap
     * @param radius The blur radius
     * @return The blurred bitmap
     */
    private Bitmap boxBlur(Bitmap src, int radius) {
        if (radius < 1) return src;

        int w = src.getWidth();
        int h = src.getHeight();
        int[] pixels = new int[w * h];
        src.getPixels(pixels, 0, w, 0, 0, w, h);

        int[] tmp = new int[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int r = 0, g = 0, b = 0, a = 0;
                int count = 0;
                for (int dx = -radius; dx <= radius; dx++) {
                    int nx = x + dx;
                    if (nx >= 0 && nx < w) {
                        int idx = y * w + nx;
                        r += (pixels[idx] >> 16) & 0xFF;
                        g += (pixels[idx] >> 8) & 0xFF;
                        b += pixels[idx] & 0xFF;
                        a += (pixels[idx] >> 24) & 0xFF;
                        count++;
                    }
                }
                int idx = y * w + x;
                tmp[idx] = (a / count) << 24 | (r / count) << 16 |
                        (g / count) << 8 | (b / count);
            }
        }

        int[] out = new int[w * h];
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                int r = 0, g = 0, b = 0, a = 0;
                int count = 0;
                for (int dy = -radius; dy <= radius; dy++) {
                    int ny = y + dy;
                    if (ny >= 0 && ny < h) {
                        int idx = ny * w + x;
                        r += (tmp[idx] >> 16) & 0xFF;
                        g += (tmp[idx] >> 8) & 0xFF;
                        b += tmp[idx] & 0xFF;
                        a += (tmp[idx] >> 24) & 0xFF;
                        count++;
                    }
                }
                int idx = y * w + x;
                out[idx] = (a / count) << 24 | (r / count) << 16 |
                        (g / count) << 8 | (b / count);
            }
        }

        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        result.setPixels(out, 0, w, 0, 0, w, h);
        return result;
    }

    /**
     * Cleans up resources when the view is detached from the window.
     * Cancels animations and recycles bitmaps to prevent memory leaks.
     */
    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (popAnimator != null) {
            popAnimator.cancel();
            popAnimator = null;
        }
        if (blurBitmap != null) {
            blurBitmap.recycle();
            blurBitmap = null;
        }
        overlayHandler.removeCallbacksAndMessages(null);
    }
}