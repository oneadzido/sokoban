package com.ark.sokoban;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

import com.ark.llama.FontAwesome;

/**
 * Custom TextView that uses Font Awesome font for icons.
 * 
 * <p>This view automatically applies the Font Awesome typeface
 * to display icons correctly with proper centering.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class FontAwesomeTextView extends AppCompatTextView {
    
    /**
     * Constructs a new FontAwesomeTextView.
     *
     * @param context The context
     */
    public FontAwesomeTextView(Context context) {
        super(context);
        init();
    }
    
    /**
     * Constructs a new FontAwesomeTextView with attributes.
     *
     * @param context The context
     * @param attrs The attribute set
     */
    public FontAwesomeTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    
    /**
     * Constructs a new FontAwesomeTextView with attributes and style.
     *
     * @param context The context
     * @param attrs The attribute set
     * @param defStyleAttr The default style attribute
     */
    public FontAwesomeTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }
    
    /**
     * Initializes the view by applying the Font Awesome typeface
     * and centering the text.
     */
    private void init() {
        Typeface typeface = FontAwesome.getTypeface();
        if (typeface != null) {
            setTypeface(typeface);
        }
        setGravity(android.view.Gravity.CENTER);
    }
}