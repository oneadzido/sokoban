package com.ark.sokoban.repository;

import android.content.res.AssetManager;

import com.ark.sokoban.models.Level;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Repository for loading and managing Sokoban levels.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 */
public class LevelRepository {
    
    private final List<Level> levels = new ArrayList<>();
    private boolean isLoaded = false;
    
    /**
     * Loads levels from an asset file.
     * 
     * @param assetManager The AssetManager
     * @param fileName The file name in the assets folder
     * @throws Exception If loading fails
     */
    public void loadLevels(AssetManager assetManager, String fileName) throws Exception {
        levels.clear();
        
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(assetManager.open(fileName)))) {
            
            List<String> levelRows = new ArrayList<>();
            String line;
            int levelNumber = 1;
            
            while ((line = reader.readLine()) != null) {
                // Remove trailing whitespace but keep leading spaces
                line = line.replaceFirst("\\s+$", "");
                
                // Comment line indicates start of new level
                if (line.startsWith(";")) {
                    if (!levelRows.isEmpty()) {
                        addLevel(levelRows, levelNumber++);
                        levelRows.clear();
                    }
                    continue;
                }
                
                // Skip completely empty lines
                if (line.trim().isEmpty()) {
                    continue;
                }
                
                // Valid level row - contains Sokoban characters or spaces
                // This matches rows that start with #, space, @, $, ., *, +
                if (line.matches("^[# @$.*+].*") || line.startsWith(" ")) {
                    levelRows.add(line);
                }
            }
            
            // Add the last level if any
            if (!levelRows.isEmpty()) {
                addLevel(levelRows, levelNumber);
            }
        }
        
        isLoaded = true;
    }
    
    /**
     * Adds a level to the repository.
     * 
     * @param rows The rows of the level as strings
     * @param levelNumber The level number
     */
    private void addLevel(List<String> rows, int levelNumber) {
        if (rows.isEmpty()) return;
        
        int height = rows.size();
        int width = 0;
        
        // Find the maximum row width
        for (String row : rows) {
            width = Math.max(width, row.length());
        }
        
        int[][] grid = new int[height][width];
        
        for (int r = 0; r < height; r++) {
            String row = rows.get(r);
            for (int c = 0; c < width; c++) {
                char symbol = c < row.length() ? row.charAt(c) : ' ';
                grid[r][c] = charToCellValue(symbol);
            }
        }
        
        Level level = new Level(grid);
        level.setName("Level " + levelNumber);
        levels.add(level);
    }
    
    /**
     * Converts a character to a cell value.
     * 
     * @param c The character
     * @return The cell value
     */
    private int charToCellValue(char c) {
        switch (c) {
            case '#': return 1;  // Wall
            case '.': return 2;  // Goal
            case '$': return 3;  // Box
            case '@': return 4;  // Player
            case '*': return 5;  // Box on goal
            case '+': return 6;  // Player on goal
            default:  return 0;  // Floor
        }
    }
    
    /**
     * Gets all levels.
     * 
     * @return List of levels
     */
    public List<Level> getAllLevels() {
        return new ArrayList<>(levels);
    }
    
    /**
     * Gets a specific level by index.
     * 
     * @param index The level index (0-based)
     * @return The Level, or null if not found
     */
    public Level getLevel(int index) {
        if (index < 0 || index >= levels.size()) {
            return null;
        }
        return levels.get(index);
    }
    
    /**
     * Gets the number of levels.
     * 
     * @return The total number of levels
     */
    public int getLevelCount() {
        return levels.size();
    }
    
    /**
     * Checks if levels are loaded.
     * 
     * @return True if levels are loaded
     */
    public boolean isLoaded() {
        return isLoaded;
    }
}