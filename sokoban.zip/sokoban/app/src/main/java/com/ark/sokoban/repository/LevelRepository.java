package com.ark.sokoban.repository;

import android.content.res.AssetManager;

import com.ark.sokoban.models.Level;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Repository for loading and managing Sokoban levels.
 * 
 * <p>This class is responsible for loading level data from asset files,
 * parsing the raw level data into {@link Level} objects, and providing
 * access to the loaded levels. It follows the Repository pattern to
 * abstract the data source from the rest of the application.</p>
 * 
 * <p>The expected file format is the standard Sokoban .sbl format where:
 * <ul>
 *   <li>Lines starting with ';' are comments and mark level separators</li>
 *   <li>Empty lines are ignored</li>
 *   <li>Level rows contain Sokoban characters: #, ., $, @, *, +</li>
 * </ul>
 * </p>
 * 
 * File Location: app/src/main/java/com/ark/sokoban/repository/LevelRepository.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class LevelRepository {
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** List of all loaded levels. */
    private final List<Level> levels = new ArrayList<>();
    
    /** Flag indicating whether levels have been successfully loaded. */
    private boolean isLoaded = false;
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Loads levels from an asset file.
     * 
     * <p>This method reads the specified file from the assets folder,
     * parses it line by line, and converts each level into a {@link Level}
     * object. The file is expected to be in the standard Sokoban .sbl format.</p>
     * 
     * <p>If an error occurs during loading, the exception is thrown to the
     * caller for handling. Previously loaded levels are cleared before
     * loading new ones.</p>
     * 
     * @param assetManager The AssetManager used to open the file
     * @param fileName The name of the file in the assets folder
     * @throws Exception If the file cannot be read or parsing fails
     */
    public void loadLevels(AssetManager assetManager, String fileName) throws Exception {
        levels.clear();
        
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(assetManager.open(fileName)))) {
            
            List<String> levelRows = new ArrayList<>();
            String line;
            int levelNumber = 1;
            
            while ((line = reader.readLine()) != null) {
                // Remove trailing whitespace but keep leading spaces
                line = line.replaceFirst("\\s+$", "");
                
                // Comment line indicates start of new level
                if (line.startsWith(";")) {
                    if (!levelRows.isEmpty()) {
                        addLevel(levelRows, levelNumber++);
                        levelRows.clear();
                    }
                    continue;
                }
                
                // Skip completely empty lines
                if (line.trim().isEmpty()) {
                    continue;
                }
                
                // Valid level row - contains Sokoban characters or spaces
                // This matches rows that start with #, space, @, $, ., *, +
                if (line.matches("^[# @$.*+].*")) {
                    levelRows.add(line);
                }
            }
            
            // Add the last level if any
            if (!levelRows.isEmpty()) {
                addLevel(levelRows, levelNumber);
            }
        }
        
        isLoaded = true;
    }
    
    /**
     * Gets all levels that have been loaded.
     * 
     * <p>Returns a copy of the internal list to prevent modification
     * of the repository's internal state.</p>
     * 
     * @return A list of all loaded levels, or an empty list if none loaded
     */
    public List<Level> getAllLevels() {
        return new ArrayList<>(levels);
    }
    
    /**
     * Gets a specific level by its index.
     * 
     * @param index The level index (0-based)
     * @return The Level at the specified index, or null if not found
     */
    public Level getLevel(int index) {
        if (index < 0 || index >= levels.size()) {
            return null;
        }
        return levels.get(index);
    }
    
    /**
     * Gets the total number of loaded levels.
     * 
     * @return The total number of levels, or 0 if none loaded
     */
    public int getLevelCount() {
        return levels.size();
    }
    
    /**
     * Checks if levels have been successfully loaded.
     * 
     * @return True if levels are loaded, false otherwise
     */
    public boolean isLoaded() {
        return isLoaded;
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Adds a level to the repository.
     * 
     * <p>This method converts a list of string rows into a {@link Level}
     * object and adds it to the internal collection. Each row is padded
     * to the maximum width using spaces.</p>
     * 
     * @param rows The rows of the level as strings
     * @param levelNumber The level number (1-based) for naming
     */
    private void addLevel(List<String> rows, int levelNumber) {
        if (rows.isEmpty()) return;
        
        int height = rows.size();
        int width = 0;
        
        // Find the maximum row width
        for (String row : rows) {
            width = Math.max(width, row.length());
        }
        
        int[][] grid = new int[height][width];
        
        for (int r = 0; r < height; r++) {
            String row = rows.get(r);
            for (int c = 0; c < width; c++) {
                char symbol = c < row.length() ? row.charAt(c) : ' ';
                grid[r][c] = charToCellValue(symbol);
            }
        }
        
        Level level = new Level(grid);
        level.setName("Level " + levelNumber);
        levels.add(level);
    }
    
    /**
     * Converts a character to a cell value.
     * 
     * <p>Maps standard Sokoban symbols to integer values:
     * <ul>
     *   <li>'#' -> 1 (Wall)</li>
     *   <li>'.' -> 2 (Goal)</li>
     *   <li>'$' -> 3 (Box)</li>
     *   <li>'@' -> 4 (Player)</li>
     *   <li>'*' -> 5 (Box on Goal)</li>
     *   <li>'+' -> 6 (Player on Goal)</li>
     *   <li>Any other character -> 0 (Floor)</li>
     * </ul>
     * </p>
     * 
     * @param c The character to convert
     * @return The corresponding cell value
     */
    private int charToCellValue(char c) {
        switch (c) {
            case '#': return 1;  // Wall
            case '.': return 2;  // Goal
            case '$': return 3;  // Box
            case '@': return 4;  // Player
            case '*': return 5;  // Box on goal
            case '+': return 6;  // Player on goal
            default:  return 0;  // Floor
        }
    }
}