package com.ark.sokoban;

import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ark.sokoban.models.Direction;

import java.util.HashMap;
import java.util.Map;

/**
 * Main Activity for the Sokoban puzzle game.
 *
 * <p>This activity is the primary user interface for the game. It manages
 * the game board rendering, user input handling, and interaction with the
 * {@link GameViewModel}.</p>
 *
 * <h3>Responsibilities</h3>
 * <ul>
 *   <li>Bind and drive the main game UI from LiveData</li>
 *   <li>Handle input from the D-pad, the action row, and the keyboard</li>
 *   <li>Debounce movement and click input at two different windows</li>
 *   <li>Auto-advance to the next level two seconds after a solve</li>
 *   <li>Persist and display best stats per level</li>
 *   <li>Present the About and Rules sheets on demand</li>
 * </ul>
 *
 * <h3>Input</h3>
 * <p>Input falls into two classes. Movement — the D-pad and Undo — uses a
 * short debounce so moves and undos can be chained fluidly. Every other
 * clickable element — the title, the action row, and all dialog buttons —
 * uses a longer debounce so a deliberate action is never fired twice by a
 * stray second tap.</p>
 *
 * <h3>Touch feedback</h3>
 * <p>Every button in the app shares one touch response: the state-list
 * drawable darkens its fill, and {@link #addScaleTouchFeedback(View)}
 * scales the view to {@link #PRESSED_SCALE} and back over
 * {@link #PRESS_SCALE_DURATION_MS}. The same treatment is attached to the
 * main UI controls and to the dialog header buttons, so the surface
 * behaves identically everywhere.</p>
 *
 * <h3>Colour mode and system bars</h3>
 * <p>The activity follows the system light/dark setting. Palette colors
 * come from the resource system, which resolves them against the active
 * mode. Every window — the activity and both sheets — is configured
 * through {@link #applySystemBarsTo(Window)}, which sets the bar colours
 * to the resolved card surface and asks for the icon colour that matches
 * the active surface through {@link #systemBarsUiFlags()}. The result is
 * one continuous surface from edge to edge in both modes.</p>
 *
 * <h3>Dialogs</h3>
 * <p>About and Rules are full-screen, edge-to-edge sheets on
 * {@link R.style#Theme_Sokoban_Dialog}, which disables the platform's
 * floating-dialog chrome so a sheet window fills the screen and draws
 * behind the bars exactly like the activity. Neither sheet uses a
 * backdrop dim: the sheet already covers the surface behind it, so a
 * scrim would only darken pixels the sheet is hiding and would tint the
 * system bars away from the card tone. Each sheet is single-instance and
 * dismissed independently of the other. About enters from the top; Rules
 * enters from the bottom.</p>
 *
 * <h3>Level navigation</h3>
 * <p>Prev and Next move away from the current level to a neighbouring
 * one. Each button is enabled only when the neighbour exists and the game
 * is not paused. A paused game disables both so a paused session cannot
 * navigate away by accident. Tooltips describe the current reason a
 * button is or is not usable, including the paused case.</p>
 *
 * <p>Architecture: MVVM with {@link GameViewModel}, LiveData for reactive
 * updates, and a clean separation between game logic and UI.</p>
 *
 * File Location: app/src/main/java/com/ark/sokoban/MainActivity.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class MainActivity extends AppCompatActivity {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Debounce window for D-pad moves and undo, in milliseconds. */
    private static final long MOVE_DEBOUNCE_DELAY_MS = 100L;

    /** Debounce window for clickable controls and dialog buttons, in ms. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 250L;

    /** Auto-advance delay after a level is solved, in milliseconds. */
    private static final long AUTO_ADVANCE_DELAY_MS = 2000L;

    /** License viewer crossfade duration, in milliseconds. */
    private static final int LICENSE_FADE_DURATION_MS = 200;

    /** Number of taps that trigger the About easter egg. */
    private static final int ABOUT_EASTER_EGG_TAPS = 5;

    /** Time window for the About easter egg taps, in milliseconds. */
    private static final long ABOUT_EASTER_EGG_TIMEOUT_MS = 5000L;

    /** Scale applied to a view while it is pressed. */
    private static final float PRESSED_SCALE = 0.97f;

    /** Duration of each half of the press scale bounce, in milliseconds. */
    private static final int PRESS_SCALE_DURATION_MS = 80;

    // ========================================================================
    // UI Components
    // ========================================================================

    /** Title text view — tapping opens the About sheet. */
    private TextView titleDisplay;

    /** Custom view that renders the game board. */
    private GameView gameView;

    /** Text view showing the current level number and total. */
    private TextView levelDisplay;

    /** Text view showing the move count. */
    private TextView moveDisplay;

    /** Text view showing the remaining goals. */
    private TextView goalDisplay;

    /** Text view showing the elapsed time. */
    private TextView timerDisplay;

    /** Row that holds the best stats. */
    private View bestStatsRow;

    /** Text view showing the best move count for the current level. */
    private TextView textViewBestMoveCount;

    /** Text view showing the best-stats label. */
    private TextView textViewBestGoals;

    /** Text view showing the best time for the current level. */
    private TextView textViewBestTimer;

    /** Button that navigates to the previous level. */
    private TextView prevButton;

    /** Button that resets the current level. */
    private TextView resetButton;

    /** Button that pauses or resumes the game. */
    private TextView pauseButton;

    /** Button that navigates to the next level. */
    private TextView nextButton;

    /** Button that resets the entire game. */
    private TextView resetGameButton;

    /** Button that undoes the last move. */
    private TextView undoButton;

    /** D-pad up button. */
    private TextView dpadUp;

    /** D-pad down button. */
    private TextView dpadDown;

    /** D-pad left button. */
    private TextView dpadLeft;

    /** D-pad right button. */
    private TextView dpadRight;

    // ========================================================================
    // Level Navigation
    // ========================================================================

    /** Whether a previous level exists to navigate to. */
    private boolean prevAvailable = false;

    /** Whether a next level exists to navigate to. */
    private boolean nextAvailable = false;

    // ========================================================================
    // ViewModel, Handlers, and Dialog References
    // ========================================================================

    /** The {@link GameViewModel} that owns the game state. */
    private GameViewModel viewModel;

    /** Handler that schedules the post-solve auto-advance. */
    private final Handler autoAdvanceHandler = new Handler();

    /** True when the activity auto-paused the game on the way to the background. */
    private boolean wasAutoPaused = false;

    /** Last accepted move-press timestamp per view id. */
    private final Map<Integer, Long> lastMovePressTimes = new HashMap<>();

    /** Last accepted click timestamp per view id or dialog hash. */
    private final Map<Integer, Long> lastClickTimes = new HashMap<>();

    /** The visible About sheet, or null when none is showing. */
    private AlertDialog aboutDialog;

    /** The visible Rules sheet, or null when none is showing. */
    private AlertDialog rulesDialog;

    // ========================================================================
    // Lifecycle
    // ========================================================================

    /**
     * Called when the activity is created.
     *
     * <p>Configures the window, initializes Font Awesome, binds the UI,
     * wires the ViewModel and its observers, sets up listeners, and loads
     * levels from assets.</p>
     *
     * @param savedInstanceState the saved instance state bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        applySystemBarsTo(getWindow());

        FontAwesome.init(this);
        setContentView(R.layout.activity_main);

        initViews();
        setupViewModel();
        setupObservers();
        setupListeners();

        try {
            viewModel.loadLevels("original.sbl");
        } catch (Exception e) {
            e.printStackTrace();
            showErrorDialog("Failed to load levels: " + e.getMessage());
        }
    }

    /**
     * Called when the activity moves to the background.
     *
     * <p>If a game is in progress and not paused, the game is auto-paused
     * so the player resumes deliberately on return. The timer is always
     * stopped.</p>
     */
    @Override
    protected void onPause() {
        super.onPause();

        GameViewModel.GameDisplayState state = viewModel.getDisplayState().getValue();
        Boolean isPaused = viewModel.getIsPaused().getValue();

        if (state != null && !state.isSolved
                && isPaused != null && !isPaused) {
            viewModel.togglePause();
            wasAutoPaused = true;
        }

        viewModel.stopTimer();
    }

    /**
     * Called when the activity returns to the foreground.
     *
     * <p>Auto-resume is deliberately not applied: a game that was
     * auto-paused on the way out stays paused until the player resumes it
     * with the pause button.</p>
     */
    @Override
    protected void onResume() {
        super.onResume();
        wasAutoPaused = false;
    }

    /**
     * Called when the activity is destroyed.
     *
     * <p>All pending callbacks and dialog references are released so
     * nothing outlives the activity.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        autoAdvanceHandler.removeCallbacksAndMessages(null);
        aboutDialog = null;
        rulesDialog = null;
    }

    /**
     * Handles the back button.
     *
     * <p>If Rules is showing on top of About, BACK dismisses only Rules.
     * Otherwise, if the game is paused, BACK resumes it. Otherwise it
     * delegates to the system.</p>
     */
    @Override
    public void onBackPressed() {
        if (rulesDialog != null && rulesDialog.isShowing()) {
            super.onBackPressed();
            return;
        }
        if (Boolean.TRUE.equals(viewModel.getIsPaused().getValue())) {
            viewModel.togglePause();
        } else {
            super.onBackPressed();
        }
    }

    // ========================================================================
    // System Bars
    // ========================================================================

    /**
     * Configures a window's system bars to match the card surface.
     *
     * <p>This is the single source of truth for bar styling. The activity
     * window and each dialog window are configured through it, so the
     * status bar and navigation bar read identically on every surface and
     * every API level.</p>
     *
     * <p>Below API 35 the bar colours are set explicitly to the resolved
     * card surface tone. From API 35 the platform draws the bars
     * transparent over the layout, so the layout root's card surface tone
     * shows through; every root layout in the app carries that tone for
     * this reason. The card surface itself resolves through the palette,
     * so both bars follow the active colour mode without any further
     * configuration.</p>
     *
     * <p>Bar icon colours are set through {@link #systemBarsUiFlags()} and
     * follow the same mode: dark icons on the light surface, light icons
     * on the dark surface.</p>
     *
     * @param window the window to configure; ignored when null
     */
    private void applySystemBarsTo(Window window) {
        if (window == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.VANILLA_ICE_CREAM) {
                int barColor = getResources().getColor(R.color.surfaceLight, getTheme());
                window.setStatusBarColor(barColor);
                window.setNavigationBarColor(barColor);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.getDecorView().setSystemUiVisibility(systemBarsUiFlags());
        }
    }

    /**
     * Builds the system UI visibility flags for the current colour mode:
     * layout stable, full-screen layout, and the light or dark status and
     * navigation bar icon flags depending on whether the app is currently
     * showing its light or dark surface.
     *
     * <p>On a light surface, the platform is asked for dark icons. On a
     * dark surface, the light-icon flags are omitted so the platform draws
     * light icons. Both behaviours follow the palette the resource system
     * resolved for the active mode.</p>
     *
     * @return the combined system UI visibility flags
     */
    private int systemBarsUiFlags() {
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;

        boolean nightMode = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;

        if (!nightMode) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
        }

        return flags;
    }

    // ========================================================================
    // Debounce
    // ========================================================================

    /**
     * Returns whether a movement press with the given key should be
     * dropped because another press with the same key occurred within
     * {@link #MOVE_DEBOUNCE_DELAY_MS} milliseconds.
     *
     * @param key the debounce key (view id)
     * @return true to drop the press, false to accept it
     */
    private boolean debounceMove(int key) {
        long now = SystemClock.elapsedRealtime();
        Long last = lastMovePressTimes.get(key);
        if (last != null && now - last < MOVE_DEBOUNCE_DELAY_MS) {
            return true;
        }
        lastMovePressTimes.put(key, now);
        return false;
    }

    /**
     * Movement view-listener overload.
     *
     * @param v the pressed view
     * @return true to drop the press, false to accept it
     */
    private boolean debounceMove(View v) {
        return debounceMove(v.getId());
    }

    /**
     * Returns whether a click with the given key should be dropped because
     * another click with the same key occurred within
     * {@link #CLICK_DEBOUNCE_DELAY_MS} milliseconds.
     *
     * @param key the debounce key (view id or dialog hash code)
     * @return true to drop the click, false to accept it
     */
    private boolean debounceClick(int key) {
        long now = SystemClock.elapsedRealtime();
        Long last = lastClickTimes.get(key);
        if (last != null && now - last < CLICK_DEBOUNCE_DELAY_MS) {
            return true;
        }
        lastClickTimes.put(key, now);
        return false;
    }

    /**
     * Click view-listener overload.
     *
     * @param v the clicked view
     * @return true to drop the click, false to accept it
     */
    private boolean debounceClick(View v) {
        return debounceClick(v.getId());
    }

    // ========================================================================
    // Initialization
    // ========================================================================

    /**
     * Binds every UI component from the layout and sets the button glyphs
     * from the Font Awesome constants.
     */
    private void initViews() {
        titleDisplay = findViewById(R.id.textViewTitle);
        gameView = findViewById(R.id.gameView);
        levelDisplay = findViewById(R.id.textViewLevelDisplay);
        moveDisplay = findViewById(R.id.textViewMoveCount);
        goalDisplay = findViewById(R.id.textViewRemainingGoals);
        timerDisplay = findViewById(R.id.textViewTimer);

        bestStatsRow = findViewById(R.id.bestStatsRow);
        textViewBestMoveCount = findViewById(R.id.textViewBestMoveCount);
        textViewBestGoals = findViewById(R.id.textViewBestGoals);
        textViewBestTimer = findViewById(R.id.textViewBestTimer);

        prevButton = findViewById(R.id.buttonPreviousLevel);
        resetButton = findViewById(R.id.buttonResetLevel);
        pauseButton = findViewById(R.id.buttonPause);
        nextButton = findViewById(R.id.buttonNextLevel);
        resetGameButton = findViewById(R.id.buttonResetGame);
        undoButton = findViewById(R.id.buttonUndo);

        dpadUp = findViewById(R.id.buttonDpadUp);
        dpadDown = findViewById(R.id.buttonDpadDown);
        dpadLeft = findViewById(R.id.buttonDpadLeft);
        dpadRight = findViewById(R.id.buttonDpadRight);

        resetGameButton.setText(FontAwesome.RESET_GAME);
        prevButton.setText(FontAwesome.PREVIOUS_LEVEL);
        pauseButton.setText(FontAwesome.PAUSE);
        nextButton.setText(FontAwesome.NEXT_LEVEL);
        resetButton.setText(FontAwesome.RESET_LEVEL);
        undoButton.setText(FontAwesome.UNDO);
        dpadUp.setText(FontAwesome.DPAD_UP);
        dpadDown.setText(FontAwesome.DPAD_DOWN);
        dpadLeft.setText(FontAwesome.DPAD_LEFT);
        dpadRight.setText(FontAwesome.DPAD_RIGHT);

        prevButton.setEnabled(false);
        nextButton.setEnabled(false);
        undoButton.setEnabled(false);
    }

    /**
     * Obtains the {@link GameViewModel} through the ViewModel provider.
     */
    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(GameViewModel.class);
    }

    // ========================================================================
    // Observers
    // ========================================================================

    /**
     * Subscribes to every LiveData stream the UI depends on.
     */
    private void setupObservers() {
        viewModel.getDisplayState().observe(this, state -> {
            if (state == null) return;
            gameView.updateGameState(state.grid, state.playerRow, state.playerCol,
                    state.isSolved);
            updateGoalDisplay();

            if (state.isSolved) {
                int moves = viewModel.getMoveCount().getValue() != null
                        ? viewModel.getMoveCount().getValue() : 0;
                int seconds = viewModel.getTimerSeconds().getValue() != null
                        ? viewModel.getTimerSeconds().getValue() : 0;
                Integer levelIndex = viewModel.getCurrentLevelIndex().getValue();
                if (levelIndex != null) {
                    viewModel.saveBestStats(levelIndex, moves, seconds);
                }

                autoAdvanceHandler.removeCallbacksAndMessages(null);
                autoAdvanceHandler.postDelayed(() -> viewModel.goToNextLevel(),
                        AUTO_ADVANCE_DELAY_MS);
            }
        });

        viewModel.getCurrentLevelIndex().observe(this, index -> {
            if (index != null) {
                updateLevelDisplay();
                updateBestStats(index);
            }
        });

        viewModel.getMoveCount().observe(this, moves ->
                moveDisplay.setText(EmojiConstants.FOOTSTEPS + " " + moves));

        viewModel.getTimerSeconds().observe(this, seconds ->
                timerDisplay.setText(EmojiConstants.CLOCK + " "
                        + GameViewModel.formatTime(seconds)));

        viewModel.getIsPaused().observe(this, paused -> {
            boolean isPaused = paused != null && paused;
            gameView.setPaused(isPaused);
            if (isPaused) {
                pauseButton.setText(FontAwesome.RESUME);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    pauseButton.setTooltipText(getString(R.string.hint_resume));
                }
            } else {
                pauseButton.setText(FontAwesome.PAUSE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    pauseButton.setTooltipText(getString(R.string.hint_pause));
                }
            }
            updateNavigationButtonsEnabled();
        });

        viewModel.getSolvedLevels().observe(this, set -> updateLevelDisplay());

        viewModel.getRefreshBestStatsTrigger().observe(this, trigger -> {
            Integer index = viewModel.getCurrentLevelIndex().getValue();
            if (index != null) {
                updateBestStats(index);
            }
        });

        viewModel.getUndoAvailable().observe(this, available -> {
            undoButton.setEnabled(available != null && available);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                undoButton.setTooltipText(available != null && available
                        ? getString(R.string.hint_undo)
                        : "No moves to undo");
            }
        });

        viewModel.getPrevAvailable().observe(this, available -> {
            prevAvailable = available != null && available;
            updateNavigationButtonsEnabled();
        });

        viewModel.getNextAvailable().observe(this, available -> {
            nextAvailable = available != null && available;
            updateNavigationButtonsEnabled();
        });
    }

    /**
     * Applies the combined effect of neighbour availability and pause state
     * to the Prev and Next buttons and refreshes their tooltips.
     *
     * <p>While paused, both buttons are disabled and their tooltips say so,
     * regardless of whether a neighbour exists. While playing, each button
     * reflects whether the neighbour it points at exists: enabled with the
     * navigation hint, or disabled because the current level is the first
     * or last in the game.</p>
     */
    private void updateNavigationButtonsEnabled() {
        boolean paused = Boolean.TRUE.equals(viewModel.getIsPaused().getValue());

        prevButton.setEnabled(prevAvailable && !paused);
        nextButton.setEnabled(nextAvailable && !paused);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            prevButton.setTooltipText(prevTooltip(paused));
            nextButton.setTooltipText(nextTooltip(paused));
        }
    }

    /**
     * Returns the tooltip for the Prev button for the current pause state.
     *
     * @param paused true when the game is paused
     * @return the tooltip string
     */
    private String prevTooltip(boolean paused) {
        if (paused) return "Disabled while the level is paused";
        if (!prevAvailable) return "First level";
        return getString(R.string.hint_previous_level);
    }

    /**
     * Returns the tooltip for the Next button for the current pause state.
     *
     * @param paused true when the game is paused
     * @return the tooltip string
     */
    private String nextTooltip(boolean paused) {
        if (paused) return "Disabled while the level is paused";
        if (!nextAvailable) return "Last level";
        return getString(R.string.hint_next_level);
    }

    // ========================================================================
    // Listeners
    // ========================================================================

    /**
     * Wires click listeners on every button and the key listener on the
     * board, and attaches the shared scale-bounce touch feedback to every
     * clickable control.
     *
     * <p>The D-pad and Undo form the movement cluster and use
     * {@link #debounceMove(View)}. Every other button uses
     * {@link #debounceClick(View)}.</p>
     */
    private void setupListeners() {
        View.OnClickListener moveListener = v -> {
            if (debounceMove(v)) return;
            handleMovePress(v);
        };

        dpadUp.setOnClickListener(moveListener);
        dpadDown.setOnClickListener(moveListener);
        dpadLeft.setOnClickListener(moveListener);
        dpadRight.setOnClickListener(moveListener);
        undoButton.setOnClickListener(moveListener);

        View.OnClickListener clickListener = v -> {
            if (debounceClick(v)) return;
            handleButtonClick(v);
        };

        titleDisplay.setOnClickListener(clickListener);
        prevButton.setOnClickListener(clickListener);
        nextButton.setOnClickListener(clickListener);
        resetButton.setOnClickListener(clickListener);
        resetGameButton.setOnClickListener(clickListener);
        pauseButton.setOnClickListener(clickListener);

        addScaleTouchFeedback(dpadUp);
        addScaleTouchFeedback(dpadDown);
        addScaleTouchFeedback(dpadLeft);
        addScaleTouchFeedback(dpadRight);
        addScaleTouchFeedback(undoButton);
        addScaleTouchFeedback(titleDisplay);
        addScaleTouchFeedback(prevButton);
        addScaleTouchFeedback(nextButton);
        addScaleTouchFeedback(resetButton);
        addScaleTouchFeedback(resetGameButton);
        addScaleTouchFeedback(pauseButton);

        gameView.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
                Direction dir = null;
                switch (keyCode) {
                    case android.view.KeyEvent.KEYCODE_DPAD_UP:
                    case android.view.KeyEvent.KEYCODE_W:
                        dir = Direction.UP;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_DOWN:
                    case android.view.KeyEvent.KEYCODE_S:
                        dir = Direction.DOWN;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_LEFT:
                    case android.view.KeyEvent.KEYCODE_A:
                        dir = Direction.LEFT;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_RIGHT:
                    case android.view.KeyEvent.KEYCODE_D:
                        dir = Direction.RIGHT;
                        break;
                    case android.view.KeyEvent.KEYCODE_U:
                        viewModel.undoMove();
                        return true;
                }
                if (dir != null) {
                    viewModel.attemptMove(dir);
                    return true;
                }
            }
            return false;
        });

        gameView.requestFocus();
    }

    /**
     * Dispatches a movement press to the ViewModel.
     *
     * @param v the pressed view
     */
    private void handleMovePress(View v) {
        int id = v.getId();

        if (id == R.id.buttonDpadUp) {
            viewModel.attemptMove(Direction.UP);
        } else if (id == R.id.buttonDpadDown) {
            viewModel.attemptMove(Direction.DOWN);
        } else if (id == R.id.buttonDpadLeft) {
            viewModel.attemptMove(Direction.LEFT);
        } else if (id == R.id.buttonDpadRight) {
            viewModel.attemptMove(Direction.RIGHT);
        } else if (id == R.id.buttonUndo) {
            viewModel.undoMove();
        }
    }

    /**
     * Dispatches a click on one of the non-movement controls.
     *
     * @param v the clicked view
     */
    private void handleButtonClick(View v) {
        int id = v.getId();

        if (id == R.id.textViewTitle) {
            showAboutDialog();
        } else if (id == R.id.buttonPreviousLevel) {
            Integer levelIndex = viewModel.getCurrentLevelIndex().getValue();
            if (levelIndex != null && levelIndex == 0) {
                return;
            }
            showLevelNavigationDialog(
                    "Previous Level",
                    "You are currently playing Level "
                            + (levelIndex != null ? levelIndex + 1 : "") + ".",
                    () -> viewModel.goToPreviousLevel()
            );
        } else if (id == R.id.buttonNextLevel) {
            Integer levelIndex = viewModel.getCurrentLevelIndex().getValue();
            Integer total = viewModel.getTotalLevels();
            if (levelIndex != null && total != null && levelIndex == total - 1) {
                return;
            }
            showLevelNavigationDialog(
                    "Next Level",
                    "You are currently playing Level "
                            + (levelIndex != null ? levelIndex + 1 : "") + ".",
                    () -> viewModel.goToNextLevel()
            );
        } else if (id == R.id.buttonResetLevel) {
            showResetLevelDialog();
        } else if (id == R.id.buttonResetGame) {
            showResetGameDialog();
        } else if (id == R.id.buttonPause) {
            viewModel.togglePause();
        }
    }

    // ========================================================================
    // UI Updates
    // ========================================================================

    /**
     * Refreshes the level display with the current level number and total.
     */
    private void updateLevelDisplay() {
        Integer index = viewModel.getCurrentLevelIndex().getValue();
        Integer total = viewModel.getTotalLevels();
        if (index != null && total != null && total > 0) {
            String text = EmojiConstants.LEVEL + " " + (index + 1) + " / " + total;
            levelDisplay.setText(text);
        }
    }

    /**
     * Refreshes the remaining-goals display.
     */
    private void updateGoalDisplay() {
        int remaining = viewModel.getRemainingGoals();
        goalDisplay.setText(EmojiConstants.TARGET + " " + remaining);
    }

    /**
     * Refreshes the best-stats row for a level. When no best exists, the
     * row is shown with placeholder values.
     *
     * @param levelIndex the level whose best stats to display
     */
    private void updateBestStats(int levelIndex) {
        GameViewModel.BestStats stats = viewModel.getBestStats(levelIndex);

        bestStatsRow.setVisibility(View.VISIBLE);

        if (stats != null) {
            textViewBestMoveCount.setText(EmojiConstants.FOOTSTEPS + " " + stats.bestMoves);
            textViewBestGoals.setText(EmojiConstants.BEST);
            textViewBestTimer.setText(EmojiConstants.CLOCK + " "
                    + GameViewModel.formatTime(stats.bestTime));
        } else {
            textViewBestMoveCount.setText(EmojiConstants.FOOTSTEPS + " 0");
            textViewBestGoals.setText(EmojiConstants.BEST);
            textViewBestTimer.setText(EmojiConstants.CLOCK + " 00:00");
        }

        textViewBestMoveCount.setVisibility(View.VISIBLE);
        textViewBestGoals.setVisibility(View.VISIBLE);
        textViewBestTimer.setVisibility(View.VISIBLE);
    }

    // ========================================================================
    // Confirmation Dialogs
    // ========================================================================

    /**
     * Shows a confirmation before navigating away from an in-progress
     * level. When there is nothing to lose — the level has no moves or is
     * already solved — the action runs immediately.
     *
     * @param title     the dialog title
     * @param message   the dialog message
     * @param onConfirm the action to run on confirmation
     */
    private void showLevelNavigationDialog(String title, String message, Runnable onConfirm) {
        Integer moveCount = viewModel.getMoveCount().getValue();

        if (moveCount == null || moveCount == 0) {
            onConfirm.run();
            return;
        }

        GameViewModel.GameDisplayState state = viewModel.getDisplayState().getValue();
        if (state != null && state.isSolved) {
            onConfirm.run();
            return;
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message + "\n\nCurrent progress will be lost. Continue?")
                .setPositiveButton("Yes", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    onConfirm.run();
                })
                .setNegativeButton("No", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    d.dismiss();
                })
                .create();

        tintDialogButtons(dialog);
        dialog.show();
    }

    /**
     * Shows a confirmation before resetting the current level. Best scores
     * are preserved by this action.
     */
    private void showResetLevelDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Reset Level")
                .setMessage("Reset this level? Your best scores will be kept.")
                .setPositiveButton("Yes", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    viewModel.resetCurrentLevel();
                })
                .setNegativeButton("No", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    d.dismiss();
                })
                .create();

        tintDialogButtons(dialog);
        dialog.show();
    }

    /**
     * Shows a confirmation before resetting the entire game. Best scores
     * are cleared by this action.
     */
    private void showResetGameDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Reset Game")
                .setMessage("Reset entire game? This will clear your best scores.")
                .setPositiveButton("Yes", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    viewModel.resetEntireGame();
                    viewModel.clearBestStats();
                    Integer index = viewModel.getCurrentLevelIndex().getValue();
                    if (index != null) {
                        updateBestStats(index);
                    }
                })
                .setNegativeButton("No", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    d.dismiss();
                })
                .create();

        tintDialogButtons(dialog);
        dialog.show();
    }

    /**
     * Shows an error dialog with the given message.
     *
     * @param message the error text to display
     */
    private void showErrorDialog(String message) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .create();

        tintDialogButtons(dialog);
        dialog.show();
    }

    /**
     * Applies the shared button text colour to a dialog's positive and
     * negative buttons once the dialog is shown.
     *
     * @param dialog the dialog whose buttons to tint
     */
    private void tintDialogButtons(AlertDialog dialog) {
        dialog.setOnShowListener(d -> {
            int color = getResources().getColor(R.color.dialogButton, getTheme());
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(color);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(color);
        });
    }

    // ========================================================================
    // About Sheet
    // ========================================================================

    /**
     * Shows the About sheet.
     *
     * <p>The sheet is presented on {@link R.style#Theme_Sokoban_Dialog}, so
     * it fills the screen and draws behind the system bars exactly like the
     * activity. No backdrop dim is used. The sheet is single-instance: a
     * second call while it is already showing is ignored.</p>
     *
     * <p>Features: slide-down entry and slide-up exit; CLOSE and RULES
     * buttons matching the main UI button design with scale-on-touch
     * feedback; clickable app name and library names that crossfade the
     * license viewer; a five-tap easter egg on the app icon; and Rules
     * opening on top without dismissing About.</p>
     */
    private void showAboutDialog() {
        if (aboutDialog != null && aboutDialog.isShowing()) return;

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_about, null);

        AlertDialog dialog = new AlertDialog.Builder(this, R.style.Theme_Sokoban_Dialog)
                .setView(dialogView)
                .create();

        TextView closeButton = dialogView.findViewById(R.id.buttonAboutClose);
        closeButton.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            dialog.dismiss();
        });
        addScaleTouchFeedback(closeButton);

        TextView rulesButton = dialogView.findViewById(R.id.buttonAboutRules);
        rulesButton.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            showRulesDialog();
        });
        addScaleTouchFeedback(rulesButton);

        TextView licenseView = dialogView.findViewById(R.id.textViewAboutLicense);

        TextView appName = dialogView.findViewById(R.id.textViewAboutAppName);
        appName.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            updateAboutLicense(licenseView, getString(R.string.license_sokoban));
        });
        addScaleTouchFeedback(appName);

        TextView gson = dialogView.findViewById(R.id.textViewAboutGson);
        gson.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            updateAboutLicense(licenseView, getString(R.string.license_gson));
        });
        addScaleTouchFeedback(gson);

        TextView fontAwesome = dialogView.findViewById(R.id.textViewAboutFontAwesome);
        fontAwesome.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            updateAboutLicense(licenseView, getString(R.string.license_fontawesome));
        });
        addScaleTouchFeedback(fontAwesome);

        setupAboutEasterEgg(dialogView.findViewById(R.id.imageViewAboutIcon));

        configureFullScreenDialog(dialog, R.style.AboutDialogAnimation);

        dialog.setOnDismissListener(d -> aboutDialog = null);
        aboutDialog = dialog;
        dialog.show();
    }

    // ========================================================================
    // Rules Sheet
    // ========================================================================

    /**
     * Shows the Rules sheet.
     *
     * <p>Presented on {@link R.style#Theme_Sokoban_Dialog}, so it fills the
     * screen and draws behind the system bars exactly like the About sheet
     * and the activity. No backdrop dim is used. The sheet carries its own
     * {@link AlertDialog} instance and its own debounce timeline, and is
     * dismissed without affecting the About sheet. It is single-instance
     * and cannot be opened twice.</p>
     *
     * <p>The animation mirrors the About sheet: it enters upward from the
     * bottom and exits downward. The CLOSE button matches the main UI
     * button design and carries the shared scale-on-touch feedback.</p>
     */
    private void showRulesDialog() {
        if (rulesDialog != null && rulesDialog.isShowing()) return;

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_rules, null);

        AlertDialog dialog = new AlertDialog.Builder(this, R.style.Theme_Sokoban_Dialog)
                .setView(dialogView)
                .create();

        TextView closeButton = dialogView.findViewById(R.id.buttonRulesClose);
        closeButton.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            dialog.dismiss();
        });
        addScaleTouchFeedback(closeButton);

        configureFullScreenDialog(dialog, R.style.RulesDialogAnimation);

        dialog.setOnDismissListener(d -> rulesDialog = null);
        rulesDialog = dialog;
        dialog.show();
    }

    // ========================================================================
    // Full-Screen Dialog Configuration
    // ========================================================================

    /**
     * Configures a dialog window for full-screen, edge-to-edge display
     * behind the system bars.
     *
     * <p>Must be called before {@link AlertDialog#show()} so the window
     * animations and layout parameters take effect.</p>
     *
     * <p>The window's floating chrome is already disabled by
     * {@link R.style#Theme_Sokoban_Dialog}, so the window occupies the
     * whole screen. This method sizes the window explicitly, applies the
     * enter and exit animations, clears any backdrop dim, and routes bar
     * styling through {@link #applySystemBarsTo(Window)} — the same method
     * the activity uses. The dialog's status bar and navigation bar
     * therefore read identically to the main UI on every API level and in
     * both colour modes.</p>
     *
     * <p>No dim is applied because the sheet covers the entire screen. A
     * scrim would darken only pixels the sheet is already hiding and would
     * tint the system bars away from the card tone.</p>
     *
     * @param dialog       the dialog whose window to configure
     * @param animStyleRes style resource with the window enter/exit animations
     */
    private void configureFullScreenDialog(AlertDialog dialog, int animStyleRes) {
        Window window = dialog.getWindow();
        if (window == null) return;

        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT);
        window.setGravity(Gravity.TOP);
        window.setWindowAnimations(animStyleRes);

        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        applySystemBarsTo(window);
    }

    // ========================================================================
    // Touch Feedback
    // ========================================================================

    /**
     * Adds a subtle scale-down / scale-up bounce to a view while it is
     * pressed, complementing the state-list fill change that the button's
     * drawable already provides. Attached to every clickable control in
     * the app so the whole surface responds identically under the finger.
     *
     * <p>The listener returns false so it does not consume the touch and
     * the view's click handling continues to fire normally.</p>
     *
     * @param view the view to attach the feedback to
     */
    private void addScaleTouchFeedback(View view) {
        if (view == null) return;
        view.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate()
                            .scaleX(PRESSED_SCALE)
                            .scaleY(PRESSED_SCALE)
                            .setDuration(PRESS_SCALE_DURATION_MS)
                            .start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(PRESS_SCALE_DURATION_MS)
                            .start();
                    break;
            }
            return false;
        });
    }

    // ========================================================================
    // About Sheet Helpers
    // ========================================================================

    /**
     * Crossfades the About license viewer to a new body of text.
     *
     * @param licenseView the TextView that displays the license
     * @param newText     the license text to display
     */
    private void updateAboutLicense(TextView licenseView, String newText) {
        if (licenseView == null) return;
        licenseView.animate()
                .alpha(0f)
                .setDuration(LICENSE_FADE_DURATION_MS)
                .withEndAction(() -> licenseView.animate()
                        .alpha(1f)
                        .setDuration(LICENSE_FADE_DURATION_MS)
                        .withStartAction(() -> licenseView.setText(newText))
                        .start())
                .start();
    }

    /**
     * Wires up the About sheet's hidden easter egg.
     *
     * <p>Tapping the app icon {@link #ABOUT_EASTER_EGG_TAPS} times within
     * {@link #ABOUT_EASTER_EGG_TIMEOUT_MS} triggers a small bounce and
     * shows a secret message.</p>
     *
     * @param icon the ImageView that acts as the trigger
     */
    private void setupAboutEasterEgg(ImageView icon) {
        if (icon == null) return;

        final int[] tapCount = {0};
        final long[] lastTapTime = {0L};

        icon.setOnClickListener(v -> {
            long now = SystemClock.elapsedRealtime();
            if (now - lastTapTime[0] > ABOUT_EASTER_EGG_TIMEOUT_MS) {
                tapCount[0] = 0;
            }
            lastTapTime[0] = now;
            tapCount[0]++;

            v.animate()
                    .scaleX(0.95f)
                    .scaleY(0.95f)
                    .setDuration(PRESS_SCALE_DURATION_MS)
                    .withEndAction(() -> v.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(PRESS_SCALE_DURATION_MS)
                            .start())
                    .start();

            if (tapCount[0] >= ABOUT_EASTER_EGG_TAPS) {
                tapCount[0] = 0;
                Toast.makeText(this, getString(R.string.about_easter_egg),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}