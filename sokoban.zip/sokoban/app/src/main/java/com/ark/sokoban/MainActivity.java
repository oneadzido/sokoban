package com.ark.sokoban;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ark.sokoban.models.Direction;

import java.util.Set;

/**
 * Main Activity for the Sokoban puzzle game.
 *
 * <p>This activity serves as the primary user interface for the game.
 * It manages the game board rendering, user input handling, and
 * interaction with the GameViewModel.</p>
 *
 * <h3>Key Responsibilities:</h3>
 * <ul>
 *   <li>Initialize and bind UI components</li>
 *   <li>Observe and react to game state changes via LiveData</li>
 *   <li>Handle user input from buttons and keyboard</li>
 *   <li>Manage button debouncing (250ms)</li>
 *   <li>Handle auto-advance on level completion (3 seconds)</li>
 * </ul>
 *
 * <p>Architecture:</p>
 * <ul>
 *   <li>Uses MVVM pattern with GameViewModel</li>
 *   <li>LiveData for reactive UI updates</li>
 *   <li>Separates game logic from UI concerns</li>
 * </ul>
 *
 * File Location: app/src/main/java/com/ark/sokoban/MainActivity.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class MainActivity extends AppCompatActivity {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Debounce delay in milliseconds to prevent rapid tapping. */
    private static final long DEBOUNCE_DELAY = 250L;

    /** Auto-advance delay in milliseconds after level completion. */
    private static final long AUTO_ADVANCE_DELAY = 3000L;

    // ========================================================================
    // UI Components
    // ========================================================================

    /** Custom view for rendering the game board. */
    private GameView gameView;

    /** Text view displaying the current level. */
    private TextView levelDisplay;

    /** Text view displaying the move count. */
    private TextView moveDisplay;

    /** Text view displaying remaining goals. */
    private TextView goalDisplay;

    /** Text view displaying the timer. */
    private TextView timerDisplay;

    /** Text view for pause label overlay. */
    private TextView pauseLabel;

    /** View for pause overlay. */
    private View pauseOverlay;

    /** Previous level button. */
    private TextView prevButton;

    /** Reset level button. */
    private TextView resetButton;

    /** Pause button. */
    private TextView pauseButton;

    /** Next level button. */
    private TextView nextButton;

    /** Reset game button. */
    private TextView resetGameButton;

    /** Undo button. */
    private TextView undoButton;

    /** D-Pad up button. */
    private TextView dpadUp;

    /** D-Pad down button. */
    private TextView dpadDown;

    /** D-Pad left button. */
    private TextView dpadLeft;

    /** D-Pad right button. */
    private TextView dpadRight;

    // ========================================================================
    // ViewModel & Utilities
    // ========================================================================

    /** The GameViewModel instance. */
    private GameViewModel viewModel;

    /** Handler for auto-advance after level completion. */
    private final Handler autoAdvanceHandler = new Handler();

    /** Last click time for debouncing. */
    private long lastClickTime = 0;

    // ========================================================================
    // Lifecycle Methods
    // ========================================================================

    /**
     * Called when the activity is created.
     *
     * <p>Initializes UI components, sets up the ViewModel, and loads levels.</p>
     *
     * @param savedInstanceState The saved instance state bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupViewModel();
        setupObservers();
        setupListeners();

        // Load levels from assets
        try {
            viewModel.loadLevels("original.sbl");
        } catch (Exception e) {
            e.printStackTrace();
            showErrorDialog("Failed to load levels: " + e.getMessage());
        }
    }

    /**
     * Called when the activity is paused.
     *
     * <p>Stops the game timer to save resources.</p>
     */
    @Override
    protected void onPause() {
        super.onPause();
        viewModel.stopTimer();
    }

    /**
     * Called when the activity is resumed.
     *
     * <p>Restarts the timer if the game is not paused and not completed.</p>
     */
    @Override
    protected void onResume() {
        super.onResume();
        Boolean paused = viewModel.getIsPaused().getValue();
        Boolean completed = viewModel.getIsCompleted().getValue();
        Integer moves = viewModel.getMoveCount().getValue();

        if (paused != null && !paused
                && completed != null && !completed
                && moves != null && moves > 0) {
            viewModel.startTimer();
        }
    }

    /**
     * Called when the activity is destroyed.
     *
     * <p>Removes all pending callbacks to prevent memory leaks.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        autoAdvanceHandler.removeCallbacksAndMessages(null);
    }

    /**
     * Handles the back button press.
     *
     * <p>If the game is paused, it toggles pause state; otherwise, it
     * delegates to the superclass.</p>
     */
    @Override
    public void onBackPressed() {
        if (pauseOverlay.getVisibility() == View.VISIBLE) {
            viewModel.togglePause();
        } else {
            super.onBackPressed();
        }
    }

    // ========================================================================
    // Initialization Methods
    // ========================================================================

    /**
     * Initializes all UI components by finding them from the layout.
     */
    private void initViews() {
        gameView = findViewById(R.id.gameView);
        levelDisplay = findViewById(R.id.textViewLevelDisplay);
        moveDisplay = findViewById(R.id.textViewMoveCount);
        goalDisplay = findViewById(R.id.textViewRemainingGoals);
        timerDisplay = findViewById(R.id.textViewTimer);
        pauseLabel = findViewById(R.id.textViewPauseLabel);
        pauseOverlay = findViewById(R.id.pauseOverlayView);

        prevButton = findViewById(R.id.buttonPreviousLevel);
        resetButton = findViewById(R.id.buttonResetLevel);
        pauseButton = findViewById(R.id.buttonPause);
        nextButton = findViewById(R.id.buttonNextLevel);
        resetGameButton = findViewById(R.id.buttonResetGame);
        undoButton = findViewById(R.id.buttonUndo);

        dpadUp = findViewById(R.id.buttonDpadUp);
        dpadDown = findViewById(R.id.buttonDpadDown);
        dpadLeft = findViewById(R.id.buttonDpadLeft);
        dpadRight = findViewById(R.id.buttonDpadRight);

        // Set initial button texts
        prevButton.setText(EmojiConstants.PREVIOUS);
        resetButton.setText(EmojiConstants.RESET_LEVEL);
        pauseButton.setText(EmojiConstants.PAUSE);
        nextButton.setText(EmojiConstants.NEXT);
        resetGameButton.setText(EmojiConstants.RESET_GAME);
        undoButton.setText(EmojiConstants.UNDO);
        dpadUp.setText(EmojiConstants.DPAD_UP);
        dpadDown.setText(EmojiConstants.DPAD_DOWN);
        dpadLeft.setText(EmojiConstants.DPAD_LEFT);
        dpadRight.setText(EmojiConstants.DPAD_RIGHT);

        pauseLabel.setText("PAUSED");
    }

    /**
     * Sets up the ViewModel instance.
     */
    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(GameViewModel.class);
    }

    // ========================================================================
    // Observer Setup
    // ========================================================================

    /**
     * Sets up LiveData observers to react to game state changes.
     */
    private void setupObservers() {
        // Level index observer
        viewModel.getCurrentLevelIndex().observe(this, index -> {
            updateLevelDisplay();
        });

        // Grid observer
        viewModel.getGrid().observe(this, grid -> {
            if (grid == null) return;
            Integer row = viewModel.getPlayerRow().getValue();
            Integer col = viewModel.getPlayerCol().getValue();
            Boolean completed = viewModel.getIsCompleted().getValue();

            if (row == null) row = 0;
            if (col == null) col = 0;
            if (completed == null) completed = false;

            gameView.updateGameState(grid, row, col, completed);
            updateGoalDisplay();
        });

        // Moves observer
        viewModel.getMoveCount().observe(this, moves -> {
            moveDisplay.setText(EmojiConstants.FOOTSTEPS + " " + moves);
        });

        // Timer observer
        viewModel.getTimerSeconds().observe(this, seconds -> {
            int minutes = seconds / 60;
            int secs = seconds % 60;
            timerDisplay.setText(EmojiConstants.CLOCK + " "
                    + String.format("%02d:%02d", minutes, secs));
        });

        // Pause observer
        viewModel.getIsPaused().observe(this, paused -> {
            if (paused != null && paused) {
                pauseOverlay.setVisibility(View.VISIBLE);
                pauseLabel.setVisibility(View.VISIBLE);
                pauseButton.setText(EmojiConstants.RESUME);
            } else {
                pauseOverlay.setVisibility(View.GONE);
                pauseLabel.setVisibility(View.GONE);
                pauseButton.setText(EmojiConstants.PAUSE);
            }
        });

        // Completion observer - auto-advance after 3 seconds
        viewModel.getIsCompleted().observe(this, completed -> {
            if (completed != null && completed) {
                autoAdvanceHandler.removeCallbacksAndMessages(null);
                autoAdvanceHandler.postDelayed(() -> {
                    viewModel.goToNextLevel();
                }, AUTO_ADVANCE_DELAY);
            }
        });
    }

    // ========================================================================
    // Listener Setup
    // ========================================================================

    /**
     * Sets up click listeners for all buttons with debouncing.
     */
    private void setupListeners() {
        // Debounced click listener
        View.OnClickListener debouncedClickListener = v -> {
            long now = System.currentTimeMillis();
            if (now - lastClickTime < DEBOUNCE_DELAY) {
                return;
            }
            lastClickTime = now;
            animateButton(v);
            handleButtonClick(v);
        };

        // Apply to all buttons
        prevButton.setOnClickListener(debouncedClickListener);
        nextButton.setOnClickListener(debouncedClickListener);
        resetButton.setOnClickListener(debouncedClickListener);
        resetGameButton.setOnClickListener(debouncedClickListener);
        pauseButton.setOnClickListener(debouncedClickListener);
        undoButton.setOnClickListener(debouncedClickListener);
        dpadUp.setOnClickListener(debouncedClickListener);
        dpadDown.setOnClickListener(debouncedClickListener);
        dpadLeft.setOnClickListener(debouncedClickListener);
        dpadRight.setOnClickListener(debouncedClickListener);

        // Keyboard support
        gameView.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
                Direction dir = null;
                switch (keyCode) {
                    case android.view.KeyEvent.KEYCODE_DPAD_UP:
                    case android.view.KeyEvent.KEYCODE_W:
                        dir = Direction.UP;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_DOWN:
                    case android.view.KeyEvent.KEYCODE_S:
                        dir = Direction.DOWN;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_LEFT:
                    case android.view.KeyEvent.KEYCODE_A:
                        dir = Direction.LEFT;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_RIGHT:
                    case android.view.KeyEvent.KEYCODE_D:
                        dir = Direction.RIGHT;
                        break;
                    case android.view.KeyEvent.KEYCODE_U:
                        viewModel.undoMove();
                        return true;
                }
                if (dir != null) {
                    viewModel.attemptMove(dir);
                    return true;
                }
            }
            return false;
        });

        gameView.requestFocus();
    }

    /**
     * Handles button click actions based on which button was clicked.
     *
     * @param v The clicked view
     */
    private void handleButtonClick(View v) {
        int id = v.getId();

        if (id == R.id.buttonPreviousLevel) {
            viewModel.goToPreviousLevel();
        } else if (id == R.id.buttonNextLevel) {
            viewModel.goToNextLevel();
        } else if (id == R.id.buttonResetLevel) {
            viewModel.resetCurrentLevel();
        } else if (id == R.id.buttonResetGame) {
            showResetConfirmation();
        } else if (id == R.id.buttonPause) {
            viewModel.togglePause();
        } else if (id == R.id.buttonUndo) {
            viewModel.undoMove();
        } else if (id == R.id.buttonDpadUp) {
            viewModel.attemptMove(Direction.UP);
        } else if (id == R.id.buttonDpadDown) {
            viewModel.attemptMove(Direction.DOWN);
        } else if (id == R.id.buttonDpadLeft) {
            viewModel.attemptMove(Direction.LEFT);
        } else if (id == R.id.buttonDpadRight) {
            viewModel.attemptMove(Direction.RIGHT);
        }
    }

    // ========================================================================
    // UI Update Methods
    // ========================================================================

    /**
     * Updates the level display with current level and completion status.
     */
    private void updateLevelDisplay() {
        Integer index = viewModel.getCurrentLevelIndex().getValue();
        Integer total = viewModel.getTotalLevels();
        if (index != null && total != null && total > 0) {
            String text = "🪧 " + (index + 1) + " / " + total;
            Set<Integer> completed = viewModel.getCompletedLevels().getValue();
            if (completed != null && completed.contains(index)) {
                text += " " + EmojiConstants.STAR;
            }
            levelDisplay.setText(text);
        }
    }

    /**
     * Updates the remaining goals display.
     */
    private void updateGoalDisplay() {
        int remaining = viewModel.getRemainingGoals();
        goalDisplay.setText(EmojiConstants.TARGET + " " + remaining);
    }

    /**
     * Animates a button with a quick fade animation.
     *
     * @param view The button to animate
     */
    private void animateButton(View view) {
        Animation anim = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        anim.setDuration(50);
        view.startAnimation(anim);
    }

    // ========================================================================
    // Dialog Methods
    // ========================================================================

    /**
     * Shows a confirmation dialog before resetting the game.
     */
    private void showResetConfirmation() {
        new AlertDialog.Builder(this)
                .setTitle("Reset Game")
                .setMessage("Delete all progress and start from level 1?")
                .setPositiveButton("Reset", (dialog, which) -> viewModel.resetEntireGame())
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Shows an error dialog with the given message.
     *
     * @param message The error message to display
     */
    private void showErrorDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }
}