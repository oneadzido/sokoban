package com.ark.sokoban;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ark.sokoban.models.Direction;

import java.util.HashMap;
import java.util.Map;

/**
 * Main Activity for the Sokoban puzzle game.
 *
 * <p>This activity is the primary user interface for the game. It manages
 * the game board rendering, user input handling, and interaction with the
 * {@link GameViewModel}.</p>
 *
 * <h3>Key Responsibilities:</h3>
 * <ul>
 *   <li>Initialize and bind UI components</li>
 *   <li>Observe and react to game state changes via LiveData</li>
 *   <li>Handle user input from the D-pad, buttons, and keyboard</li>
 *   <li>Debounce movement and click input</li>
 *   <li>Handle auto-advance after a level is solved (2 seconds)</li>
 *   <li>Display best stats when a level has been solved</li>
 *   <li>Present the About and Rules dialogs when the title is tapped</li>
 * </ul>
 *
 * <h3>Input model:</h3>
 * <p>User input falls into two classes. Movement input — the D-pad and the
 * Undo button — uses a short debounce window so the player can chain moves
 * and undos. Every other clickable element — the title, the action row,
 * and all dialog buttons — uses a longer window that prevents accidental
 * double activation of a decision.</p>
 *
 * <h3>Touch feedback model:</h3>
 * <p>Every button in the app shares a single touch response. The pressed
 * fill change is delivered by the button's state-list drawable; the scale
 * bounce is attached by {@link #addScaleTouchFeedback(View)}. Both are
 * applied uniformly to the main UI controls and to the dialog header
 * buttons, so the whole surface behaves the same way under the finger.</p>
 *
 * <h3>Window model:</h3>
 * <p>The activity draws edge-to-edge behind the system bars. The activity
 * root and the dialog roots carry the card surface tone, so the status bar
 * and navigation bar read the same colour as the card on every API level.
 * On API levels below 35 the bars are also coloured explicitly; on API 35
 * the platform bars are transparent and the layout background shows
 * through.</p>
 *
 * <h3>Dialog model:</h3>
 * <p>About and Rules are independent full-screen, top-anchored sheets.
 * Each is single-instance, carries its own debounce timeline, and is
 * dismissed without affecting the other. About uses a 0.5 dim and enters
 * from the top; Rules uses no dim and enters from the bottom.</p>
 *
 * <h3>Navigation button model:</h3>
 * <p>The Prev and Next buttons are enabled only when their level is
 * available <b>and</b> the game is not paused. Pausing suppresses both
 * buttons so a paused session cannot navigate away by accident; resuming
 * restores them to reflect the current level's position in the game.</p>
 *
 * <p>Architecture:</p>
 * <ul>
 *   <li>MVVM pattern with {@link GameViewModel}</li>
 *   <li>LiveData for reactive UI updates</li>
 *   <li>Separation of game logic from UI concerns</li>
 * </ul>
 *
 * File Location: app/src/main/java/com/ark/sokoban/MainActivity.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class MainActivity extends AppCompatActivity {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Debounce window for D-pad moves and undo, in milliseconds. */
    private static final long MOVE_DEBOUNCE_DELAY_MS = 100L;

    /** Debounce window for clickable controls and dialog buttons, in ms. */
    private static final long CLICK_DEBOUNCE_DELAY_MS = 250L;

    /** Auto-advance delay in milliseconds after a level is solved. */
    private static final long AUTO_ADVANCE_DELAY_MS = 2000L;

    /** Duration of the license crossfade animation in milliseconds. */
    private static final int LICENSE_FADE_DURATION_MS = 200;

    /** Number of taps required to trigger the About easter egg. */
    private static final int ABOUT_EASTER_EGG_TAPS = 5;

    /** Time window in milliseconds for the About easter egg taps. */
    private static final long ABOUT_EASTER_EGG_TIMEOUT_MS = 5000L;

    /** Backdrop dim applied to the About dialog. */
    private static final float ABOUT_DIM = 0.5f;

    /** Backdrop dim applied to the Rules dialog. */
    private static final float RULES_DIM = 0.0f;

    /** Scale applied to a view while it is pressed. */
    private static final float PRESSED_SCALE = 0.97f;

    /** Duration of each half of the press scale bounce, in milliseconds. */
    private static final int PRESS_SCALE_DURATION_MS = 80;

    // ========================================================================
    // UI Components
    // ========================================================================

    /** Title text view — tapping opens the About dialog. */
    private TextView titleDisplay;

    /** Custom view for rendering the game board. */
    private GameView gameView;

    /** Text view displaying the current level. */
    private TextView levelDisplay;

    /** Text view displaying the move count. */
    private TextView moveDisplay;

    /** Text view displaying remaining goals. */
    private TextView goalDisplay;

    /** Text view displaying the timer. */
    private TextView timerDisplay;

    /** Best stats row. */
    private View bestStatsRow;

    /** Text view displaying best move count. */
    private TextView textViewBestMoveCount;

    /** Text view displaying best goals. */
    private TextView textViewBestGoals;

    /** Text view displaying best timer. */
    private TextView textViewBestTimer;

    /** Previous level button. */
    private TextView prevButton;

    /** Reset level button. */
    private TextView resetButton;

    /** Pause button. */
    private TextView pauseButton;

    /** Next level button. */
    private TextView nextButton;

    /** Reset game button. */
    private TextView resetGameButton;

    /** Undo button (part of the movement cluster). */
    private TextView undoButton;

    /** D-Pad up button. */
    private TextView dpadUp;

    /** D-Pad down button. */
    private TextView dpadDown;

    /** D-Pad left button. */
    private TextView dpadLeft;

    /** D-Pad right button. */
    private TextView dpadRight;

    // ========================================================================
    // Navigation State
    // ========================================================================

    /** Whether the previous level is available from the ViewModel. */
    private boolean prevAvailable = false;

    /** Whether the next level is available from the ViewModel. */
    private boolean nextAvailable = false;

    // ========================================================================
    // ViewModel & Utilities
    // ========================================================================

    /** The {@link GameViewModel} instance. */
    private GameViewModel viewModel;

    /** Handler for auto-advance after a level is solved. */
    private final Handler autoAdvanceHandler = new Handler();

    /** Flag tracking whether the game was auto-paused when the app backgrounded. */
    private boolean wasAutoPaused = false;

    /** Timestamp of the last accepted move press, keyed by view id. */
    private final Map<Integer, Long> lastMovePressTimes = new HashMap<>();

    /** Timestamp of the last accepted click, keyed by view id or dialog hash. */
    private final Map<Integer, Long> lastClickTimes = new HashMap<>();

    /** Currently visible About dialog, or null when none is showing. */
    private AlertDialog aboutDialog;

    /** Currently visible Rules dialog, or null when none is showing. */
    private AlertDialog rulesDialog;

    // ========================================================================
    // Lifecycle Methods
    // ========================================================================

    /**
     * Called when the activity is created.
     *
     * <p>Configures the window, initializes Font Awesome, binds UI
     * components, sets up the ViewModel, and loads levels from assets.</p>
     *
     * @param savedInstanceState The saved instance state bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setUpWindow();

        FontAwesome.init(this);
        setContentView(R.layout.activity_main);

        initViews();
        setupViewModel();
        setupObservers();
        setupListeners();

        try {
            viewModel.loadLevels("original.sbl");
        } catch (Exception e) {
            e.printStackTrace();
            showErrorDialog("Failed to load levels: " + e.getMessage());
        }
    }

    /**
     * Called when the activity is paused.
     *
     * <p>Stops the game timer and auto-pauses if the game is active.</p>
     */
    @Override
    protected void onPause() {
        super.onPause();

        GameViewModel.GameDisplayState state = viewModel.getDisplayState().getValue();
        Boolean isPaused = viewModel.getIsPaused().getValue();

        if (state != null && !state.isSolved &&
                isPaused != null && !isPaused) {
            viewModel.togglePause();
            wasAutoPaused = true;
        }

        viewModel.stopTimer();
    }

    /**
     * Called when the activity is resumed.
     *
     * <p>No auto-resume. The user resumes manually with the pause button.</p>
     */
    @Override
    protected void onResume() {
        super.onResume();
        wasAutoPaused = false;
    }

    /**
     * Called when the activity is destroyed.
     *
     * <p>Removes all pending callbacks and releases dialog references to
     * prevent memory leaks.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        autoAdvanceHandler.removeCallbacksAndMessages(null);
        aboutDialog = null;
        rulesDialog = null;
    }

    /**
     * Handles the back button press.
     *
     * <p>If the Rules dialog is on top of About, BACK dismisses Rules only.
     * Otherwise, if the game is paused, it toggles the pause state;
     * otherwise, it delegates to the superclass.</p>
     */
    @Override
    public void onBackPressed() {
        if (rulesDialog != null && rulesDialog.isShowing()) {
            super.onBackPressed();
            return;
        }
        if (Boolean.TRUE.equals(viewModel.getIsPaused().getValue())) {
            viewModel.togglePause();
        } else {
            super.onBackPressed();
        }
    }

    // ========================================================================
    // Window Configuration
    // ========================================================================

    /**
     * Configures the activity window for edge-to-edge display.
     *
     * <p>The layout draws behind the system bars and the status bar and
     * navigation bar take the card surface colour, so the bars read as a
     * continuation of the card rather than the screen surround. On API
     * levels below 35 the bar colours are set explicitly; on API 35 the
     * platform bars are transparent for apps targeting SDK 35 and the
     * layout background shows through.</p>
     */
    private void setUpWindow() {
        Window window = getWindow();
        if (window == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.VANILLA_ICE_CREAM) {
                int barColor = getResources().getColor(R.color.surfaceLight, getTheme());
                window.setStatusBarColor(barColor);
                window.setNavigationBarColor(barColor);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                          | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
    }

    // ========================================================================
    // Debounce
    // ========================================================================

    /**
     * Returns whether a movement press with the given key should be ignored
     * because another press with the same key occurred within
     * {@link #MOVE_DEBOUNCE_DELAY_MS} milliseconds.
     *
     * @param key the debounce key (view id)
     * @return true to drop the press, false to accept it
     */
    private boolean debounceMove(int key) {
        long now = SystemClock.elapsedRealtime();
        Long last = lastMovePressTimes.get(key);
        if (last != null && now - last < MOVE_DEBOUNCE_DELAY_MS) {
            return true;
        }
        lastMovePressTimes.put(key, now);
        return false;
    }

    /**
     * Convenience overload for movement view listeners.
     *
     * @param v the pressed view
     * @return true to drop the press, false to accept it
     */
    private boolean debounceMove(View v) {
        return debounceMove(v.getId());
    }

    /**
     * Returns whether a click with the given key should be ignored because
     * another click with the same key occurred within
     * {@link #CLICK_DEBOUNCE_DELAY_MS} milliseconds.
     *
     * @param key the debounce key (view id or dialog hash code)
     * @return true to drop the click, false to accept it
     */
    private boolean debounceClick(int key) {
        long now = SystemClock.elapsedRealtime();
        Long last = lastClickTimes.get(key);
        if (last != null && now - last < CLICK_DEBOUNCE_DELAY_MS) {
            return true;
        }
        lastClickTimes.put(key, now);
        return false;
    }

    /**
     * Convenience overload for click listeners.
     *
     * @param v the clicked view
     * @return true to drop the click, false to accept it
     */
    private boolean debounceClick(View v) {
        return debounceClick(v.getId());
    }

    // ========================================================================
    // Initialization Methods
    // ========================================================================

    /**
     * Initializes all UI components by finding them from the layout.
     * Sets button texts using Font Awesome constants.
     */
    private void initViews() {
        titleDisplay = findViewById(R.id.textViewTitle);
        gameView = findViewById(R.id.gameView);
        levelDisplay = findViewById(R.id.textViewLevelDisplay);
        moveDisplay = findViewById(R.id.textViewMoveCount);
        goalDisplay = findViewById(R.id.textViewRemainingGoals);
        timerDisplay = findViewById(R.id.textViewTimer);

        bestStatsRow = findViewById(R.id.bestStatsRow);
        textViewBestMoveCount = findViewById(R.id.textViewBestMoveCount);
        textViewBestGoals = findViewById(R.id.textViewBestGoals);
        textViewBestTimer = findViewById(R.id.textViewBestTimer);

        prevButton = findViewById(R.id.buttonPreviousLevel);
        resetButton = findViewById(R.id.buttonResetLevel);
        pauseButton = findViewById(R.id.buttonPause);
        nextButton = findViewById(R.id.buttonNextLevel);
        resetGameButton = findViewById(R.id.buttonResetGame);
        undoButton = findViewById(R.id.buttonUndo);

        dpadUp = findViewById(R.id.buttonDpadUp);
        dpadDown = findViewById(R.id.buttonDpadDown);
        dpadLeft = findViewById(R.id.buttonDpadLeft);
        dpadRight = findViewById(R.id.buttonDpadRight);

        resetGameButton.setText(FontAwesome.RESET_GAME);
        prevButton.setText(FontAwesome.PREVIOUS_LEVEL);
        pauseButton.setText(FontAwesome.PAUSE);
        nextButton.setText(FontAwesome.NEXT_LEVEL);
        resetButton.setText(FontAwesome.RESET_LEVEL);
        undoButton.setText(FontAwesome.UNDO);
        dpadUp.setText(FontAwesome.DPAD_UP);
        dpadDown.setText(FontAwesome.DPAD_DOWN);
        dpadLeft.setText(FontAwesome.DPAD_LEFT);
        dpadRight.setText(FontAwesome.DPAD_RIGHT);

        prevButton.setEnabled(false);
        nextButton.setEnabled(false);
        undoButton.setEnabled(false);
    }

    /**
     * Sets up the ViewModel instance using ViewModelProvider.
     */
    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(GameViewModel.class);
    }

    // ========================================================================
    // Observer Setup
    // ========================================================================

    /**
     * Sets up LiveData observers to react to game state changes.
     */
    private void setupObservers() {
        viewModel.getDisplayState().observe(this, state -> {
            if (state == null) return;
            gameView.updateGameState(state.grid, state.playerRow, state.playerCol,
                    state.isSolved);
            updateGoalDisplay();

            if (state.isSolved) {
                int moves = viewModel.getMoveCount().getValue() != null ?
                        viewModel.getMoveCount().getValue() : 0;
                int seconds = viewModel.getTimerSeconds().getValue() != null ?
                        viewModel.getTimerSeconds().getValue() : 0;
                Integer levelIndex = viewModel.getCurrentLevelIndex().getValue();
                if (levelIndex != null) {
                    viewModel.saveBestStats(levelIndex, moves, seconds);
                }

                autoAdvanceHandler.removeCallbacksAndMessages(null);
                autoAdvanceHandler.postDelayed(() -> viewModel.goToNextLevel(),
                        AUTO_ADVANCE_DELAY_MS);
            }
        });

        viewModel.getCurrentLevelIndex().observe(this, index -> {
            if (index != null) {
                updateLevelDisplay();
                updateBestStats(index);
            }
        });

        viewModel.getMoveCount().observe(this, moves ->
                moveDisplay.setText(EmojiConstants.FOOTSTEPS + " " + moves));

        viewModel.getTimerSeconds().observe(this, seconds ->
                timerDisplay.setText(EmojiConstants.CLOCK + " " +
                        GameViewModel.formatTime(seconds)));

        viewModel.getIsPaused().observe(this, paused -> {
            boolean isPaused = paused != null && paused;
            gameView.setPaused(isPaused);
            if (isPaused) {
                pauseButton.setText(FontAwesome.RESUME);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    pauseButton.setTooltipText(getString(R.string.hint_resume));
                }
            } else {
                pauseButton.setText(FontAwesome.PAUSE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    pauseButton.setTooltipText(getString(R.string.hint_pause));
                }
            }
            updateNavigationButtonsEnabled();
        });

        viewModel.getSolvedLevels().observe(this, set -> updateLevelDisplay());

        viewModel.getRefreshBestStatsTrigger().observe(this, trigger -> {
            Integer index = viewModel.getCurrentLevelIndex().getValue();
            if (index != null) {
                updateBestStats(index);
            }
        });

        viewModel.getUndoAvailable().observe(this, available -> {
            undoButton.setEnabled(available != null && available);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                undoButton.setTooltipText(available != null && available ?
                        getString(R.string.hint_undo) : "No moves to undo");
            }
        });

        viewModel.getPrevAvailable().observe(this, available -> {
            prevAvailable = available != null && available;
            updateNavigationButtonsEnabled();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                prevButton.setTooltipText(prevAvailable ?
                        getString(R.string.hint_previous_level) : "First level");
            }
        });

        viewModel.getNextAvailable().observe(this, available -> {
            nextAvailable = available != null && available;
            updateNavigationButtonsEnabled();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                nextButton.setTooltipText(nextAvailable ?
                        getString(R.string.hint_next_level) : "Last level");
            }
        });
    }

    /**
     * Applies the combined effect of level availability and pause state to
     * the Prev and Next buttons.
     *
     * <p>Both buttons are disabled while the game is paused, regardless of
     * whether the neighbouring level exists, so a paused session cannot
     * navigate away by accident. When the game is not paused, each button
     * reflects its own availability.</p>
     */
    private void updateNavigationButtonsEnabled() {
        boolean paused = Boolean.TRUE.equals(viewModel.getIsPaused().getValue());
        prevButton.setEnabled(prevAvailable && !paused);
        nextButton.setEnabled(nextAvailable && !paused);
    }

    // ========================================================================
    // Listener Setup
    // ========================================================================

    /**
     * Sets up click listeners for all buttons with debouncing.
     *
     * <p>The D-pad and the Undo button form the movement cluster and use
     * {@link #debounceMove(View)}. Every other button on the activity uses
     * {@link #debounceClick(View)}. The same scale-bounce touch feedback
     * is attached to every clickable control, so the whole surface
     * responds identically under the finger.</p>
     */
    private void setupListeners() {
        View.OnClickListener moveListener = v -> {
            if (debounceMove(v)) return;
            handleMovePress(v);
        };

        dpadUp.setOnClickListener(moveListener);
        dpadDown.setOnClickListener(moveListener);
        dpadLeft.setOnClickListener(moveListener);
        dpadRight.setOnClickListener(moveListener);
        undoButton.setOnClickListener(moveListener);

        View.OnClickListener clickListener = v -> {
            if (debounceClick(v)) return;
            handleButtonClick(v);
        };

        titleDisplay.setOnClickListener(clickListener);
        prevButton.setOnClickListener(clickListener);
        nextButton.setOnClickListener(clickListener);
        resetButton.setOnClickListener(clickListener);
        resetGameButton.setOnClickListener(clickListener);
        pauseButton.setOnClickListener(clickListener);

        addScaleTouchFeedback(dpadUp);
        addScaleTouchFeedback(dpadDown);
        addScaleTouchFeedback(dpadLeft);
        addScaleTouchFeedback(dpadRight);
        addScaleTouchFeedback(undoButton);
        addScaleTouchFeedback(titleDisplay);
        addScaleTouchFeedback(prevButton);
        addScaleTouchFeedback(nextButton);
        addScaleTouchFeedback(resetButton);
        addScaleTouchFeedback(resetGameButton);
        addScaleTouchFeedback(pauseButton);

        gameView.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
                Direction dir = null;
                switch (keyCode) {
                    case android.view.KeyEvent.KEYCODE_DPAD_UP:
                    case android.view.KeyEvent.KEYCODE_W:
                        dir = Direction.UP;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_DOWN:
                    case android.view.KeyEvent.KEYCODE_S:
                        dir = Direction.DOWN;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_LEFT:
                    case android.view.KeyEvent.KEYCODE_A:
                        dir = Direction.LEFT;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_RIGHT:
                    case android.view.KeyEvent.KEYCODE_D:
                        dir = Direction.RIGHT;
                        break;
                    case android.view.KeyEvent.KEYCODE_U:
                        viewModel.undoMove();
                        return true;
                }
                if (dir != null) {
                    viewModel.attemptMove(dir);
                    return true;
                }
            }
            return false;
        });

        gameView.requestFocus();
    }

    /**
     * Handles a press on the movement cluster (D-pad and Undo).
     *
     * @param v The pressed view
     */
    private void handleMovePress(View v) {
        int id = v.getId();

        if (id == R.id.buttonDpadUp) {
            viewModel.attemptMove(Direction.UP);
        } else if (id == R.id.buttonDpadDown) {
            viewModel.attemptMove(Direction.DOWN);
        } else if (id == R.id.buttonDpadLeft) {
            viewModel.attemptMove(Direction.LEFT);
        } else if (id == R.id.buttonDpadRight) {
            viewModel.attemptMove(Direction.RIGHT);
        } else if (id == R.id.buttonUndo) {
            viewModel.undoMove();
        }
    }

    /**
     * Handles a click on the activity's non-movement controls.
     *
     * @param v The clicked view
     */
    private void handleButtonClick(View v) {
        int id = v.getId();

        if (id == R.id.textViewTitle) {
            showAboutDialog();
        } else if (id == R.id.buttonPreviousLevel) {
            Integer levelIndex = viewModel.getCurrentLevelIndex().getValue();
            if (levelIndex != null && levelIndex == 0) {
                return;
            }
            showLevelNavigationDialog(
                    "Previous Level",
                    "You are currently playing Level " + (levelIndex != null ? levelIndex + 1 : "") + ".",
                    () -> viewModel.goToPreviousLevel()
            );
        } else if (id == R.id.buttonNextLevel) {
            Integer levelIndex = viewModel.getCurrentLevelIndex().getValue();
            Integer total = viewModel.getTotalLevels();
            if (levelIndex != null && total != null && levelIndex == total - 1) {
                return;
            }
            showLevelNavigationDialog(
                    "Next Level",
                    "You are currently playing Level " + (levelIndex != null ? levelIndex + 1 : "") + ".",
                    () -> viewModel.goToNextLevel()
            );
        } else if (id == R.id.buttonResetLevel) {
            showResetLevelDialog();
        } else if (id == R.id.buttonResetGame) {
            showResetGameDialog();
        } else if (id == R.id.buttonPause) {
            viewModel.togglePause();
        }
    }

    // ========================================================================
    // UI Update Methods
    // ========================================================================

    /**
     * Updates the level display with the current level number and total.
     */
    private void updateLevelDisplay() {
        Integer index = viewModel.getCurrentLevelIndex().getValue();
        Integer total = viewModel.getTotalLevels();
        if (index != null && total != null && total > 0) {
            String text = EmojiConstants.LEVEL + " " + (index + 1) + " / " + total;
            levelDisplay.setText(text);
        }
    }

    /**
     * Updates the remaining goals display.
     */
    private void updateGoalDisplay() {
        int remaining = viewModel.getRemainingGoals();
        goalDisplay.setText(EmojiConstants.TARGET + " " + remaining);
    }

    /**
     * Updates the best stats display for a level.
     * Placeholders are shown when no best exists.
     *
     * @param levelIndex The level index to display stats for
     */
    private void updateBestStats(int levelIndex) {
        GameViewModel.BestStats stats = viewModel.getBestStats(levelIndex);

        bestStatsRow.setVisibility(View.VISIBLE);

        if (stats != null) {
            textViewBestMoveCount.setText(EmojiConstants.FOOTSTEPS + " " + stats.bestMoves);
            textViewBestGoals.setText(EmojiConstants.BEST);
            textViewBestTimer.setText(EmojiConstants.CLOCK + " " +
                    GameViewModel.formatTime(stats.bestTime));
        } else {
            textViewBestMoveCount.setText(EmojiConstants.FOOTSTEPS + " 0");
            textViewBestGoals.setText(EmojiConstants.BEST);
            textViewBestTimer.setText(EmojiConstants.CLOCK + " 00:00");
        }

        textViewBestMoveCount.setVisibility(View.VISIBLE);
        textViewBestGoals.setVisibility(View.VISIBLE);
        textViewBestTimer.setVisibility(View.VISIBLE);
    }

    // ========================================================================
    // Confirmation Dialogs
    // ========================================================================

    /**
     * Shows a confirmation dialog when navigating away from an in-progress
     * level.
     *
     * @param title The dialog title
     * @param message The dialog message
     * @param onConfirm The action to execute if confirmed
     */
    private void showLevelNavigationDialog(String title, String message, Runnable onConfirm) {
        Integer moveCount = viewModel.getMoveCount().getValue();

        if (moveCount == null || moveCount == 0) {
            onConfirm.run();
            return;
        }

        GameViewModel.GameDisplayState state = viewModel.getDisplayState().getValue();
        if (state != null && state.isSolved) {
            onConfirm.run();
            return;
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message + "\n\nCurrent progress will be lost. Continue?")
                .setPositiveButton("Yes", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    onConfirm.run();
                })
                .setNegativeButton("No", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    d.dismiss();
                })
                .create();

        tintDialogButtons(dialog);
        dialog.show();
    }

    /**
     * Shows a confirmation dialog before resetting the level.
     * Warns that best scores will be kept.
     */
    private void showResetLevelDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Reset Level")
                .setMessage("Reset this level? Your best scores will be kept.")
                .setPositiveButton("Yes", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    viewModel.resetCurrentLevel();
                })
                .setNegativeButton("No", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    d.dismiss();
                })
                .create();

        tintDialogButtons(dialog);
        dialog.show();
    }

    /**
     * Shows a confirmation dialog before resetting the game.
     * Warns that best scores will be cleared.
     */
    private void showResetGameDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Reset Game")
                .setMessage("Reset entire game? This will clear your best scores.")
                .setPositiveButton("Yes", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    viewModel.resetEntireGame();
                    viewModel.clearBestStats();
                    Integer index = viewModel.getCurrentLevelIndex().getValue();
                    if (index != null) {
                        updateBestStats(index);
                    }
                })
                .setNegativeButton("No", (d, w) -> {
                    if (debounceClick(d.hashCode())) return;
                    d.dismiss();
                })
                .create();

        tintDialogButtons(dialog);
        dialog.show();
    }

    /**
     * Shows an error dialog with the given message.
     *
     * @param message The error message to display
     */
    private void showErrorDialog(String message) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .create();

        tintDialogButtons(dialog);
        dialog.show();
    }

    /**
     * Applies the shared button text colour to a dialog's positive and
     * negative buttons once the dialog is shown.
     *
     * @param dialog The dialog whose buttons should be tinted
     */
    private void tintDialogButtons(AlertDialog dialog) {
        dialog.setOnShowListener(d -> {
            int color = getResources().getColor(R.color.dialogButton, getTheme());
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(color);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(color);
        });
    }

    // ========================================================================
    // About Dialog
    // ========================================================================

    /**
     * Shows the About dialog as a full-screen, top-anchored sheet.
     *
     * <p>Features:</p>
     * <ul>
     *   <li>Single-instance — a second tap on the title while About is
     *       already showing is ignored</li>
     *   <li>Slide-down entry and slide-up exit animations</li>
     *   <li>CLOSE and RULES buttons matching the main UI button design,
     *       with scale-on-touch feedback</li>
     *   <li>Clickable app name and library names that crossfade the license
     *       viewer</li>
     *   <li>Five-tap easter egg on the app icon</li>
     *   <li>Rules opens on top without dismissing About</li>
     * </ul>
     */
    private void showAboutDialog() {
        if (aboutDialog != null && aboutDialog.isShowing()) return;

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_about, null);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        TextView closeButton = dialogView.findViewById(R.id.buttonAboutClose);
        closeButton.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            dialog.dismiss();
        });
        addScaleTouchFeedback(closeButton);

        TextView rulesButton = dialogView.findViewById(R.id.buttonAboutRules);
        rulesButton.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            showRulesDialog();
        });
        addScaleTouchFeedback(rulesButton);

        TextView licenseView = dialogView.findViewById(R.id.textViewAboutLicense);

        TextView appName = dialogView.findViewById(R.id.textViewAboutAppName);
        appName.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            updateAboutLicense(licenseView, getString(R.string.license_sokoban));
        });
        addScaleTouchFeedback(appName);

        TextView gson = dialogView.findViewById(R.id.textViewAboutGson);
        gson.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            updateAboutLicense(licenseView, getString(R.string.license_gson));
        });
        addScaleTouchFeedback(gson);

        TextView fontAwesome = dialogView.findViewById(R.id.textViewAboutFontAwesome);
        fontAwesome.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            updateAboutLicense(licenseView, getString(R.string.license_fontawesome));
        });
        addScaleTouchFeedback(fontAwesome);

        setupAboutEasterEgg(dialogView.findViewById(R.id.imageViewAboutIcon));

        configureFullScreenDialog(dialog, R.style.AboutDialogAnimation, ABOUT_DIM);

        dialog.setOnDismissListener(d -> aboutDialog = null);
        aboutDialog = dialog;
        dialog.show();
    }

    // ========================================================================
    // Rules Dialog
    // ========================================================================

    /**
     * Shows the Rules dialog as a full-screen, top-anchored sheet.
     *
     * <p>Independent of About: it carries its own {@link AlertDialog}
     * instance, its own debounce timeline, and a zero dim so a Rules sheet
     * stacked on top of About does not compound the backdrop darkening.
     * The dialog is single-instance and cannot be opened twice.</p>
     *
     * <p>The animation mirrors the About dialog: it enters upward from the
     * bottom and exits downward. The CLOSE button matches the main UI
     * button design and carries the shared scale-on-touch feedback.</p>
     */
    private void showRulesDialog() {
        if (rulesDialog != null && rulesDialog.isShowing()) return;

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_rules, null);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        TextView closeButton = dialogView.findViewById(R.id.buttonRulesClose);
        closeButton.setOnClickListener(v -> {
            if (debounceClick(v)) return;
            dialog.dismiss();
        });
        addScaleTouchFeedback(closeButton);

        configureFullScreenDialog(dialog, R.style.RulesDialogAnimation, RULES_DIM);

        dialog.setOnDismissListener(d -> rulesDialog = null);
        rulesDialog = dialog;
        dialog.show();
    }

    // ========================================================================
    // Full-Screen Dialog Configuration
    // ========================================================================

    /**
     * Configures a dialog window for full-screen, top-anchored display
     * that draws edge-to-edge behind the system bars.
     *
     * <p>This method must be called before {@link AlertDialog#show()} so
     * that the window animations and layout parameters take effect.</p>
     *
     * <p>The dialog root carries the card surface tone and fits the system
     * insets, so the bars read the same colour as the sheet on every API
     * level. On API levels below 35 the bar colours are set explicitly;
     * on API 35 the platform bars are transparent and the dialog root
     * background shows through.</p>
     *
     * @param dialog       the dialog whose window to configure
     * @param animStyleRes style resource with the window enter/exit animations
     * @param dimAmount    the backdrop dim amount; 0f disables dimming
     */
    private void configureFullScreenDialog(AlertDialog dialog, int animStyleRes,
                                           float dimAmount) {
        Window window = dialog.getWindow();
        if (window == null) return;

        window.setBackgroundDrawableResource(android.R.color.transparent);
        window.setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT);
        window.setGravity(Gravity.TOP);
        window.setWindowAnimations(animStyleRes);

        window.setDimAmount(dimAmount);
        if (dimAmount > 0f) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.VANILLA_ICE_CREAM) {
                int barColor = getResources().getColor(R.color.surfaceLight, getTheme());
                window.setStatusBarColor(barColor);
                window.setNavigationBarColor(barColor);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                          | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }
    }

    // ========================================================================
    // Touch Feedback and Easter Egg
    // ========================================================================

    /**
     * Adds a subtle scale-down / scale-up bounce to a view while it is
     * pressed, giving tactile feedback that matches the button's state-list
     * fill change. Attached to every clickable control in the app so the
     * whole surface responds identically under the finger.
     *
     * <p>The listener returns false so it does not consume the touch and
     * the view's click handling continues to fire normally.</p>
     *
     * @param view The view to attach the feedback to
     */
    private void addScaleTouchFeedback(View view) {
        if (view == null) return;
        view.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate()
                            .scaleX(PRESSED_SCALE)
                            .scaleY(PRESSED_SCALE)
                            .setDuration(PRESS_SCALE_DURATION_MS)
                            .start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(PRESS_SCALE_DURATION_MS)
                            .start();
                    break;
            }
            return false;
        });
    }

    /**
     * Updates the About dialog's license viewer with a crossfade animation.
     *
     * @param licenseView The TextView displaying the license
     * @param newText The new license text to display
     */
    private void updateAboutLicense(TextView licenseView, String newText) {
        if (licenseView == null) return;
        licenseView.animate()
                .alpha(0f)
                .setDuration(LICENSE_FADE_DURATION_MS)
                .withEndAction(() -> licenseView.animate()
                        .alpha(1f)
                        .setDuration(LICENSE_FADE_DURATION_MS)
                        .withStartAction(() -> licenseView.setText(newText))
                        .start())
                .start();
    }

    /**
     * Wires up the About dialog's hidden easter egg.
     *
     * <p>Tapping the app icon five times within five seconds triggers a
     * subtle bounce animation and shows a secret message.</p>
     *
     * @param icon The ImageView acting as the easter egg trigger
     */
    private void setupAboutEasterEgg(ImageView icon) {
        if (icon == null) return;

        final int[] tapCount = {0};
        final long[] lastTapTime = {0L};

        icon.setOnClickListener(v -> {
            long now = SystemClock.elapsedRealtime();
            if (now - lastTapTime[0] > ABOUT_EASTER_EGG_TIMEOUT_MS) {
                tapCount[0] = 0;
            }
            lastTapTime[0] = now;
            tapCount[0]++;

            v.animate()
                    .scaleX(0.95f)
                    .scaleY(0.95f)
                    .setDuration(PRESS_SCALE_DURATION_MS)
                    .withEndAction(() -> v.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(PRESS_SCALE_DURATION_MS)
                            .start())
                    .start();

            if (tapCount[0] >= ABOUT_EASTER_EGG_TAPS) {
                tapCount[0] = 0;
                Toast.makeText(this, getString(R.string.about_easter_egg),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}