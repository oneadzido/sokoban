package com.ark.sokoban;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import java.util.List;
import java.util.Set;

/**
 * Main Activity for the Sokoban game.
 * 
 * <p>This activity hosts the game UI, observes the ViewModel's LiveData,
 * and handles user input from buttons and the D-pad. It also manages
 * the application lifecycle, pausing and resuming the timer as needed.</p>
 * 
 * <p>The activity follows Google's recommended architecture with
 * ViewModel and LiveData, ensuring separation of concerns and
 * lifecycle awareness.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class MainActivity extends AppCompatActivity {
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    private GameView gameView;
    private TextView textViewLevelDisplay;
    private TextView textViewMoveCount;
    private TextView textViewRemainingGoals;
    private TextView textViewTimer;
    private TextView textViewHeaderIcon;
    private TextView textViewPauseLabel;
    private TextView textViewFootstepsIcon;
    private TextView textViewBullseyeIcon;
    private TextView textViewClockIcon;
    private Button buttonPreviousLevel;
    private Button buttonResetLevel;
    private Button buttonResetGame;
    private Button buttonPause;
    private Button buttonNextLevel;
    private Button buttonDpadUp;
    private Button buttonDpadDown;
    private Button buttonDpadLeft;
    private Button buttonDpadRight;
    private Button buttonUndo;
    private View pauseOverlayView;
    
    // ========================================================================
    // ViewModel and Helpers
    // ========================================================================
    
    private GameViewModel viewModel;
    private Handler autoAdvanceHandler = new Handler();
    
    // ========================================================================
    // Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * 
     * <p>Initializes the UI, sets up the ViewModel, loads levels,
     * and observes LiveData. Also applies the FontAwesome typeface
     * to all UI components.</p>
     *
     * @param savedInstanceState The saved instance state (if any).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        FontAwesome.init(getApplicationContext());
        
        // Initialize views
        gameView = findViewById(R.id.gameView);
        textViewLevelDisplay = findViewById(R.id.textViewLevelDisplay);
        textViewMoveCount = findViewById(R.id.textViewMoveCount);
        textViewRemainingGoals = findViewById(R.id.textViewRemainingGoals);
        textViewTimer = findViewById(R.id.textViewTimer);
        textViewHeaderIcon = findViewById(R.id.textViewHeaderIcon);
        textViewPauseLabel = findViewById(R.id.textViewPauseLabel);
        textViewFootstepsIcon = findViewById(R.id.textViewFootstepsIcon);
        textViewBullseyeIcon = findViewById(R.id.textViewBullseyeIcon);
        textViewClockIcon = findViewById(R.id.textViewClockIcon);
        buttonPreviousLevel = findViewById(R.id.buttonPreviousLevel);
        buttonResetLevel = findViewById(R.id.buttonResetLevel);
        buttonResetGame = findViewById(R.id.buttonResetGame);
        buttonPause = findViewById(R.id.buttonPause);
        buttonNextLevel = findViewById(R.id.buttonNextLevel);
        buttonDpadUp = findViewById(R.id.buttonDpadUp);
        buttonDpadDown = findViewById(R.id.buttonDpadDown);
        buttonDpadLeft = findViewById(R.id.buttonDpadLeft);
        buttonDpadRight = findViewById(R.id.buttonDpadRight);
        buttonUndo = findViewById(R.id.buttonUndo);
        pauseOverlayView = findViewById(R.id.pauseOverlayView);
        
        applyFontAwesomeToUI();
        
        viewModel = new ViewModelProvider(this).get(GameViewModel.class);
        
        try {
            List<int[][]> levels = LevelParser.loadLevelsFromAsset(getAssets(), "levels/original.sbl");
            viewModel.setLevels(levels);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to load levels", Toast.LENGTH_LONG).show();
        }
        
        // ─── Observe LiveData ──────────────────────────────────────────────
        
        viewModel.getCurrentLevelIndex().observe(this, index -> updateLevelDisplay());
        
        viewModel.getGrid().observe(this, grid -> {
            Integer playerRow = viewModel.getPlayerRow().getValue();
            Integer playerCol = viewModel.getPlayerCol().getValue();
            Boolean completed = viewModel.getIsGameCompleted().getValue();
            if (grid != null && playerRow != null && playerCol != null) {
                gameView.updateGameState(grid, playerRow, playerCol, completed != null && completed);
                int remaining = viewModel.countRemainingGoals(grid);
                textViewRemainingGoals.setText(String.valueOf(remaining));
            }
        });
        
        viewModel.getMoveCount().observe(this, moves -> textViewMoveCount.setText(String.valueOf(moves)));
        
        viewModel.getTimerSeconds().observe(this, seconds -> {
            int minutes = seconds / 60;
            int secs = seconds % 60;
            textViewTimer.setText(String.format("%02d:%02d", minutes, secs));
        });
        
        viewModel.getIsPaused().observe(this, paused -> {
            if (paused != null && paused) {
                pauseOverlayView.setVisibility(View.VISIBLE);
                textViewPauseLabel.setVisibility(View.VISIBLE);
                buttonPause.setText(FontAwesome.PLAY + " Resume");
            } else {
                pauseOverlayView.setVisibility(View.GONE);
                textViewPauseLabel.setVisibility(View.GONE);
                buttonPause.setText(FontAwesome.PAUSE + " Pause");
            }
        });
        
        viewModel.getIsGameCompleted().observe(this, completed -> {
            if (completed != null && completed) {
                Toast.makeText(this, "Level Complete!", Toast.LENGTH_SHORT).show();
                autoAdvanceHandler.postDelayed(() -> viewModel.goToNextLevel(), 1500);
            }
        });
        
        // ─── Button Listeners ──────────────────────────────────────────────
        
        buttonPreviousLevel.setOnClickListener(v -> viewModel.goToPreviousLevel());
        buttonResetLevel.setOnClickListener(v -> viewModel.resetCurrentLevel());
        buttonResetGame.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Reset Game")
                    .setMessage("Delete all progress and start from level 1?")
                    .setPositiveButton("Reset", (dialog, which) -> viewModel.resetEntireGame())
                    .setNegativeButton("Cancel", null)
                    .show();
        });
        buttonPause.setOnClickListener(v -> viewModel.togglePause());
        buttonNextLevel.setOnClickListener(v -> viewModel.goToNextLevel());
        
        buttonDpadUp.setOnClickListener(v -> viewModel.attemptMove(-1, 0));
        buttonDpadDown.setOnClickListener(v -> viewModel.attemptMove(1, 0));
        buttonDpadLeft.setOnClickListener(v -> viewModel.attemptMove(0, -1));
        buttonDpadRight.setOnClickListener(v -> viewModel.attemptMove(0, 1));
        buttonUndo.setOnClickListener(v -> viewModel.undoMove());
        
        gameView.setFocusable(true);
        gameView.requestFocus();
    }
    
    // ========================================================================
    // UI Helpers
    // ========================================================================
    
    /**
     * Applies FontAwesome typeface to all UI components and sets
     * their text using the FontAwesome constants.
     * 
     * <p>This method is called after the views are inflated. If the
     * FontAwesome typeface is not loaded, the icons will not render,
     * but the app will not crash.</p>
     */
    private void applyFontAwesomeToUI() {
        if (FontAwesome.getTypeface() != null) {
            // Header icon
            textViewHeaderIcon.setTypeface(FontAwesome.getTypeface());
            textViewHeaderIcon.setText(FontAwesome.CUBE);
            
            // Pause label
            textViewPauseLabel.setTypeface(FontAwesome.getTypeface());
            textViewPauseLabel.setText(FontAwesome.PAUSE + " PAUSED");
            
            // Stats icons
            textViewFootstepsIcon.setTypeface(FontAwesome.getTypeface());
            textViewFootstepsIcon.setText(FontAwesome.FOOTSTEPS);
            
            textViewBullseyeIcon.setTypeface(FontAwesome.getTypeface());
            textViewBullseyeIcon.setText(FontAwesome.TARGET);
            
            textViewClockIcon.setTypeface(FontAwesome.getTypeface());
            textViewClockIcon.setText(FontAwesome.CLOCK);
            
            // Buttons
            setButtonTextAndTypeface(buttonPreviousLevel, FontAwesome.BACKWARD + " Prev");
            setButtonTextAndTypeface(buttonResetLevel, FontAwesome.REDO + " Reset");
            setButtonTextAndTypeface(buttonResetGame, FontAwesome.TRASH + " Reset All");
            setButtonTextAndTypeface(buttonPause, FontAwesome.PAUSE + " Pause");
            setButtonTextAndTypeface(buttonNextLevel, "Next " + FontAwesome.FORWARD);
            setButtonTextAndTypeface(buttonDpadUp, FontAwesome.ARROW_UP);
            setButtonTextAndTypeface(buttonDpadDown, FontAwesome.ARROW_DOWN);
            setButtonTextAndTypeface(buttonDpadLeft, FontAwesome.ARROW_LEFT);
            setButtonTextAndTypeface(buttonDpadRight, FontAwesome.ARROW_RIGHT);
            setButtonTextAndTypeface(buttonUndo, FontAwesome.UNDO);
        }
    }
    
    /**
     * Sets the FontAwesome typeface and text on a button.
     *
     * @param button The button to modify. May be null.
     * @param text The text to set (may include FontAwesome characters).
     */
    private void setButtonTextAndTypeface(Button button, String text) {
        if (button != null && FontAwesome.getTypeface() != null) {
            button.setTypeface(FontAwesome.getTypeface());
            button.setText(text);
        }
    }
    
    /**
     * Updates the level display, including a star if the level is completed.
     * 
     * <p>If the FontAwesome typeface is available, a star icon is appended;
     * otherwise, a plain asterisk is used as a fallback.</p>
     */
    private void updateLevelDisplay() {
        Integer index = viewModel.getCurrentLevelIndex().getValue();
        Integer total = viewModel.getTotalLevels();
        if (index != null && total != null && total > 0) {
            textViewLevelDisplay.setText((index + 1) + " / " + total);
        }
        Set<Integer> completed = viewModel.getCompletedLevels().getValue();
        if (completed != null && index != null && completed.contains(index)) {
            if (FontAwesome.getTypeface() != null) {
                textViewLevelDisplay.append(" " + FontAwesome.STAR);
            } else {
                textViewLevelDisplay.append(" *");
            }
        }
    }
    
    // ========================================================================
    // Lifecycle – Pause / Resume
    // ========================================================================
    
    /**
     * Called when the activity is paused.
     * Stops the timer to save battery.
     */
    @Override
    protected void onPause() {
        super.onPause();
        viewModel.stopTimer();
    }
    
    /**
     * Called when the activity is resumed.
     * Restarts the timer if conditions allow.
     * 
     * <p>Conditions: not paused, not completed, and move count > 0.</p>
     */
    @Override
    protected void onResume() {
        super.onResume();
        if (viewModel.getIsPaused().getValue() == Boolean.FALSE &&
            viewModel.getIsGameCompleted().getValue() == Boolean.FALSE &&
            viewModel.getMoveCount().getValue() > 0) {
            viewModel.startTimer();
        }
    }
    
    /**
     * Handles the back button: unpauses if paused, otherwise exits.
     */
    @Override
    public void onBackPressed() {
        if (pauseOverlayView.getVisibility() == View.VISIBLE) {
            viewModel.togglePause();
        } else {
            super.onBackPressed();
        }
    }
}