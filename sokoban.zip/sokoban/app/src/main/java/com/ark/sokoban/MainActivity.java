package com.ark.sokoban;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ark.sokoban.FontAwesome;
import com.ark.sokoban.models.Direction;

import java.util.Set;

/**
 * Main Activity for the Sokoban puzzle game.
 *
 * <p>This activity serves as the primary user interface for the game.
 * It manages the game board rendering, user input handling, and
 * interaction with the GameViewModel.</p>
 *
 * <h3>Key Responsibilities:</h3>
 * <ul>
 *   <li>Initialize and bind UI components</li>
 *   <li>Observe and react to game state changes via LiveData</li>
 *   <li>Handle user input from buttons and keyboard</li>
 *   <li>Manage button debouncing (100ms)</li>
 *   <li>Handle auto-advance on level completion (2 seconds)</li>
 *   <li>Display best stats when level has been completed</li>
 * </ul>
 *
 * <p>Architecture:</p>
 * <ul>
 *   <li>Uses MVVM pattern with GameViewModel</li>
 *   <li>LiveData for reactive UI updates</li>
 *   <li>Separates game logic from UI concerns</li>
 * </ul>
 *
 * File Location: app/src/main/java/com/ark/sokoban/MainActivity.java
 *
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class MainActivity extends AppCompatActivity {

    // ========================================================================
    // Constants
    // ========================================================================

    /** Debounce delay in milliseconds to prevent rapid tapping. */
    private static final long DEBOUNCE_DELAY = 100L;

    /** Auto-advance delay in milliseconds after level completion. */
    private static final long AUTO_ADVANCE_DELAY = 2000L;

    // ========================================================================
    // UI Components
    // ========================================================================

    /** Custom view for rendering the game board. */
    private GameView gameView;

    /** Text view displaying the current level. */
    private TextView levelDisplay;

    /** Text view displaying the move count. */
    private TextView moveDisplay;

    /** Text view displaying remaining goals. */
    private TextView goalDisplay;

    /** Text view displaying the timer. */
    private TextView timerDisplay;

    /** Best stats row. */
    private View bestStatsRow;

    /** Text view displaying best move count. */
    private TextView textViewBestMoveCount;

    /** Text view displaying best goals. */
    private TextView textViewBestGoals;

    /** Text view displaying best timer. */
    private TextView textViewBestTimer;

    /** Previous level button. */
    private TextView prevButton;

    /** Reset level button. */
    private TextView resetButton;

    /** Pause button. */
    private TextView pauseButton;

    /** Next level button. */
    private TextView nextButton;

    /** Reset game button. */
    private TextView resetGameButton;

    /** Undo button. */
    private TextView undoButton;

    /** D-Pad up button. */
    private TextView dpadUp;

    /** D-Pad down button. */
    private TextView dpadDown;

    /** D-Pad left button. */
    private TextView dpadLeft;

    /** D-Pad right button. */
    private TextView dpadRight;

    // ========================================================================
    // ViewModel & Utilities
    // ========================================================================

    /** The GameViewModel instance. */
    private GameViewModel viewModel;

    /** Handler for auto-advance after level completion. */
    private final Handler autoAdvanceHandler = new Handler();

    /** Last click time for debouncing. */
    private long lastClickTime = 0;

    /** Flag to track auto-pause when app goes background. */
    private boolean wasAutoPaused = false;

    // ========================================================================
    // Lifecycle Methods
    // ========================================================================

    /**
     * Called when the activity is created.
     *
     * <p>Initializes Font Awesome, UI components, sets up the ViewModel,
     * and loads levels from assets.</p>
     *
     * @param savedInstanceState The saved instance state bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Initialize Font Awesome
        FontAwesome.init(this);
        
        setContentView(R.layout.activity_main);

        initViews();
        setupViewModel();
        setupObservers();
        setupListeners();

        try {
            viewModel.loadLevels("original.sbl");
        } catch (Exception e) {
            e.printStackTrace();
            showErrorDialog("Failed to load levels: " + e.getMessage());
        }
    }

    /**
     * Called when the activity is paused.
     *
     * <p>Stops the game timer and auto-pauses if game is active.</p>
     */
    @Override
    protected void onPause() {
        super.onPause();

        GameViewModel.GameDisplayState state = viewModel.getDisplayState().getValue();
        Boolean isPaused = viewModel.getIsPaused().getValue();

        if (state != null && !state.isCompleted &&
                isPaused != null && !isPaused) {
            viewModel.togglePause();
            wasAutoPaused = true;
        }

        viewModel.stopTimer();
    }

    /**
     * Called when the activity is resumed.
     *
     * <p>No auto-resume. User must manually resume with pause button.</p>
     */
    @Override
    protected void onResume() {
        super.onResume();
        wasAutoPaused = false;
    }

    /**
     * Called when the activity is destroyed.
     *
     * <p>Removes all pending callbacks to prevent memory leaks.</p>
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        autoAdvanceHandler.removeCallbacksAndMessages(null);
    }

    /**
     * Handles the back button press.
     *
     * <p>If the game is paused, it toggles pause state; otherwise, it
     * delegates to the superclass.</p>
     */
    @Override
    public void onBackPressed() {
        if (viewModel.getIsPaused().getValue() != null &&
                viewModel.getIsPaused().getValue()) {
            viewModel.togglePause();
        } else {
            super.onBackPressed();
        }
    }

    // ========================================================================
    // Initialization Methods
    // ========================================================================

    /**
     * Initializes all UI components by finding them from the layout.
     * Sets button texts using Font Awesome constants.
     */
    private void initViews() {
        gameView = findViewById(R.id.gameView);
        levelDisplay = findViewById(R.id.textViewLevelDisplay);
        moveDisplay = findViewById(R.id.textViewMoveCount);
        goalDisplay = findViewById(R.id.textViewRemainingGoals);
        timerDisplay = findViewById(R.id.textViewTimer);

        bestStatsRow = findViewById(R.id.bestStatsRow);
        textViewBestMoveCount = findViewById(R.id.textViewBestMoveCount);
        textViewBestGoals = findViewById(R.id.textViewBestGoals);
        textViewBestTimer = findViewById(R.id.textViewBestTimer);

        prevButton = findViewById(R.id.buttonPreviousLevel);
        resetButton = findViewById(R.id.buttonResetLevel);
        pauseButton = findViewById(R.id.buttonPause);
        nextButton = findViewById(R.id.buttonNextLevel);
        resetGameButton = findViewById(R.id.buttonResetGame);
        undoButton = findViewById(R.id.buttonUndo);

        dpadUp = findViewById(R.id.buttonDpadUp);
        dpadDown = findViewById(R.id.buttonDpadDown);
        dpadLeft = findViewById(R.id.buttonDpadLeft);
        dpadRight = findViewById(R.id.buttonDpadRight);

        // Set button texts using Font Awesome constants
        resetGameButton.setText(FontAwesome.RESET_GAME);
        prevButton.setText(FontAwesome.PREVIOUS_LEVEL);
        pauseButton.setText(FontAwesome.PAUSE);
        nextButton.setText(FontAwesome.NEXT_LEVEL);
        resetButton.setText(FontAwesome.RESET_LEVEL);
        undoButton.setText(FontAwesome.UNDO);
        dpadUp.setText(FontAwesome.DPAD_UP);
        dpadDown.setText(FontAwesome.DPAD_DOWN);
        dpadLeft.setText(FontAwesome.DPAD_LEFT);
        dpadRight.setText(FontAwesome.DPAD_RIGHT);
    }

    /**
     * Sets up the ViewModel instance using ViewModelProvider.
     */
    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(GameViewModel.class);
    }

    // ========================================================================
    // Observer Setup
    // ========================================================================

    /**
     * Sets up LiveData observers to react to game state changes.
     */
    private void setupObservers() {
        // Atomic display state – updates GameView with all rendering data at once
        viewModel.getDisplayState().observe(this, state -> {
            if (state == null) return;
            gameView.updateGameState(state.grid, state.playerRow, state.playerCol,
                    state.isCompleted);
            updateGoalDisplay();

            if (state.isCompleted) {
                // Save best stats
                int moves = viewModel.getMoveCount().getValue() != null ?
                        viewModel.getMoveCount().getValue() : 0;
                int seconds = viewModel.getTimerSeconds().getValue() != null ?
                        viewModel.getTimerSeconds().getValue() : 0;
                Integer levelIndex = viewModel.getCurrentLevelIndex().getValue();
                if (levelIndex != null) {
                    viewModel.saveBestStats(levelIndex, moves, seconds);
                }

                autoAdvanceHandler.removeCallbacksAndMessages(null);
                autoAdvanceHandler.postDelayed(() -> viewModel.goToNextLevel(),
                        AUTO_ADVANCE_DELAY);
            }
        });

        // Level index – for level display and best stats
        viewModel.getCurrentLevelIndex().observe(this, index -> {
            if (index != null) {
                updateLevelDisplay();
                updateBestStats(index);
            }
        });

        // Move count
        viewModel.getMoveCount().observe(this, moves ->
                moveDisplay.setText(EmojiConstants.FOOTSTEPS + " " + moves));

        // Timer
        viewModel.getTimerSeconds().observe(this, seconds -> {
            int minutes = seconds / 60;
            int secs = seconds % 60;
            timerDisplay.setText(EmojiConstants.CLOCK + " " +
                    String.format("%02d:%02d", minutes, secs));
        });

        // Pause state – calls GameView.setPaused() to show/hide pause overlay
        viewModel.getIsPaused().observe(this, paused -> {
            gameView.setPaused(paused != null && paused);
            if (paused != null && paused) {
                pauseButton.setText(FontAwesome.RESUME);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    pauseButton.setTooltipText(getString(R.string.hint_resume));
                }
            } else {
                pauseButton.setText(FontAwesome.PAUSE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    pauseButton.setTooltipText(getString(R.string.hint_pause));
                }
            }
        });

        // Completed levels – for level display
        viewModel.getCompletedLevels().observe(this, set -> updateLevelDisplay());

        // Refresh trigger for best stats
        viewModel.getRefreshBestStatsTrigger().observe(this, trigger -> {
            Integer index = viewModel.getCurrentLevelIndex().getValue();
            if (index != null) {
                updateBestStats(index);
            }
        });
    }

    // ========================================================================
    // Listener Setup
    // ========================================================================

    /**
     * Sets up click listeners for all buttons with debouncing.
     */
    private void setupListeners() {
        // Debounced click listener
        View.OnClickListener debouncedClickListener = v -> {
            long now = System.currentTimeMillis();
            if (now - lastClickTime < DEBOUNCE_DELAY) {
                return;
            }
            lastClickTime = now;
            animateButton(v);
            handleButtonClick(v);
        };

        // Apply to all buttons
        prevButton.setOnClickListener(debouncedClickListener);
        nextButton.setOnClickListener(debouncedClickListener);
        resetButton.setOnClickListener(debouncedClickListener);
        resetGameButton.setOnClickListener(debouncedClickListener);
        pauseButton.setOnClickListener(debouncedClickListener);
        undoButton.setOnClickListener(debouncedClickListener);
        dpadUp.setOnClickListener(debouncedClickListener);
        dpadDown.setOnClickListener(debouncedClickListener);
        dpadLeft.setOnClickListener(debouncedClickListener);
        dpadRight.setOnClickListener(debouncedClickListener);

        // Keyboard support
        gameView.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
                Direction dir = null;
                switch (keyCode) {
                    case android.view.KeyEvent.KEYCODE_DPAD_UP:
                    case android.view.KeyEvent.KEYCODE_W:
                        dir = Direction.UP;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_DOWN:
                    case android.view.KeyEvent.KEYCODE_S:
                        dir = Direction.DOWN;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_LEFT:
                    case android.view.KeyEvent.KEYCODE_A:
                        dir = Direction.LEFT;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_RIGHT:
                    case android.view.KeyEvent.KEYCODE_D:
                        dir = Direction.RIGHT;
                        break;
                    case android.view.KeyEvent.KEYCODE_U:
                        viewModel.undoMove();
                        return true;
                }
                if (dir != null) {
                    viewModel.attemptMove(dir);
                    return true;
                }
            }
            return false;
        });

        gameView.requestFocus();
    }

    /**
     * Handles button click actions based on which button was clicked.
     *
     * @param v The clicked view
     */
    private void handleButtonClick(View v) {
        int id = v.getId();

        if (id == R.id.buttonPreviousLevel) {
            viewModel.goToPreviousLevel();
        } else if (id == R.id.buttonNextLevel) {
            viewModel.goToNextLevel();
        } else if (id == R.id.buttonResetLevel) {
            showResetLevelDialog();
        } else if (id == R.id.buttonResetGame) {
            showResetGameDialog();
        } else if (id == R.id.buttonPause) {
            viewModel.togglePause();
        } else if (id == R.id.buttonUndo) {
            viewModel.undoMove();
        } else if (id == R.id.buttonDpadUp) {
            viewModel.attemptMove(Direction.UP);
        } else if (id == R.id.buttonDpadDown) {
            viewModel.attemptMove(Direction.DOWN);
        } else if (id == R.id.buttonDpadLeft) {
            viewModel.attemptMove(Direction.LEFT);
        } else if (id == R.id.buttonDpadRight) {
            viewModel.attemptMove(Direction.RIGHT);
        }
    }

    // ========================================================================
    // UI Update Methods
    // ========================================================================

    /**
     * Updates the level display with current level number and total levels.
     */
    private void updateLevelDisplay() {
        Integer index = viewModel.getCurrentLevelIndex().getValue();
        Integer total = viewModel.getTotalLevels();
        if (index != null && total != null && total > 0) {
            String text = EmojiConstants.LEVEL + " " + (index + 1) + " / " + total;
            levelDisplay.setText(text);
        }
    }

    /**
     * Updates the remaining goals display.
     */
    private void updateGoalDisplay() {
        int remaining = viewModel.getRemainingGoals();
        goalDisplay.setText(EmojiConstants.TARGET + " " + remaining);
    }

    /**
     * Updates the best stats display for a level.
     * Always shows the best stats row with placeholders if no best exists.
     *
     * @param levelIndex The level index to display stats for
     */
    private void updateBestStats(int levelIndex) {
        GameViewModel.BestStats stats = viewModel.getBestStats(levelIndex);

        // Best stats row is always visible
        bestStatsRow.setVisibility(View.VISIBLE);

        if (stats != null) {
            textViewBestMoveCount.setText(EmojiConstants.FOOTSTEPS + " " + stats.bestMoves);
            textViewBestMoveCount.setVisibility(View.VISIBLE);

            textViewBestGoals.setText(EmojiConstants.BEST );
            textViewBestGoals.setVisibility(View.VISIBLE);

            int minutes = stats.bestTime / 60;
            int secs = stats.bestTime % 60;
            textViewBestTimer.setText(EmojiConstants.CLOCK + " " +
                    String.format("%02d:%02d", minutes, secs));
            textViewBestTimer.setVisibility(View.VISIBLE);
        } else {
            // Show placeholders when no best exists
            textViewBestMoveCount.setText(EmojiConstants.FOOTSTEPS + " 0");
            textViewBestMoveCount.setVisibility(View.VISIBLE);

            textViewBestGoals.setText(EmojiConstants.BEST );
            textViewBestGoals.setVisibility(View.VISIBLE);

            textViewBestTimer.setText(EmojiConstants.CLOCK + " 00:00");
            textViewBestTimer.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Animates a button with a quick fade animation.
     *
     * @param view The button to animate
     */
    private void animateButton(View view) {
        Animation anim = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        anim.setDuration(80);
        view.startAnimation(anim);
    }

    // ========================================================================
    // Dialog Methods
    // ========================================================================

    /**
     * Shows a confirmation dialog before resetting the level.
     * Warns that best scores will be kept.
     */
    private void showResetLevelDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Reset Level")
                .setMessage("Reset this level? Your best score will be kept.")
                .setPositiveButton("Yes", (d, w) -> viewModel.resetCurrentLevel())
                .setNegativeButton("No", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFFC0C0C0);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(0xFFC0C0C0);
        });

        dialog.show();
    }

    /**
     * Shows a confirmation dialog before resetting the game.
     * Warns that all progress and best scores will be cleared.
     */
    private void showResetGameDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Reset Game")
                .setMessage("Reset entire game? This will clear all progress and best scores.")
                .setPositiveButton("Yes", (d, w) -> {
                    viewModel.resetEntireGame();
                    viewModel.clearBestStats();
                    // Best stats will show placeholders after reset
                    Integer index = viewModel.getCurrentLevelIndex().getValue();
                    if (index != null) {
                        updateBestStats(index);
                    }
                })
                .setNegativeButton("No", null)
                .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFFC0C0C0);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(0xFFC0C0C0);
        });

        dialog.show();
    }

    /**
     * Shows an error dialog with the given message.
     *
     * @param message The error message to display
     */
    private void showErrorDialog(String message) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .create();

        dialog.setOnShowListener(d ->
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFFC0C0C0));

        dialog.show();
    }
}