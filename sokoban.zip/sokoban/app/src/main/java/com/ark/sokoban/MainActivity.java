package com.ark.sokoban;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import java.util.List;
import java.util.Set;

/**
 * Main Activity for the Sokoban game.
 * 
 * <p>This activity hosts the game UI, observes the ViewModel's LiveData,
 * and handles user input from buttons and the D-pad. It also manages
 * the application lifecycle, pausing and resuming the timer as needed.</p>
 * 
 * <p>The activity follows Google's recommended architecture with
 * ViewModel and LiveData, ensuring separation of concerns and
 * lifecycle awareness.</p>
 * 
 * <p>All icons are displayed using emojis defined in EmojiConstants.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class MainActivity extends AppCompatActivity {
    
    // ========================================================================
    // UI Components
    // ========================================================================
    
    private GameView gameView;
    private TextView textViewLevelDisplay;
    private TextView textViewMoveCount;
    private TextView textViewRemainingGoals;
    private TextView textViewTimer;
    private TextView textViewPauseLabel;
    private TextView buttonPreviousLevel;
    private TextView buttonResetLevel;
    private TextView buttonResetGame;
    private TextView buttonPause;
    private TextView buttonNextLevel;
    private TextView buttonDpadUp;
    private TextView buttonDpadDown;
    private TextView buttonDpadLeft;
    private TextView buttonDpadRight;
    private TextView buttonUndo;
    private View pauseOverlayView;
    
    // ========================================================================
    // ViewModel and Helpers
    // ========================================================================
    
    private GameViewModel viewModel;
    private Handler autoAdvanceHandler = new Handler();
    
    // ========================================================================
    // Lifecycle Methods
    // ========================================================================
    
    /**
     * Called when the activity is created.
     * 
     * <p>Initializes the UI, sets up the ViewModel, loads levels,
     * and observes LiveData. All icons are set using emojis.</p>
     *
     * @param savedInstanceState The saved instance state (if any).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Initialize views
        gameView = findViewById(R.id.gameView);
        textViewLevelDisplay = findViewById(R.id.textViewLevelDisplay);
        textViewMoveCount = findViewById(R.id.textViewMoveCount);
        textViewRemainingGoals = findViewById(R.id.textViewRemainingGoals);
        textViewTimer = findViewById(R.id.textViewTimer);
        textViewPauseLabel = findViewById(R.id.textViewPauseLabel);
        buttonPreviousLevel = findViewById(R.id.buttonPreviousLevel);
        buttonResetLevel = findViewById(R.id.buttonResetLevel);
        buttonResetGame = findViewById(R.id.buttonResetGame);
        buttonPause = findViewById(R.id.buttonPause);
        buttonNextLevel = findViewById(R.id.buttonNextLevel);
        buttonDpadUp = findViewById(R.id.buttonDpadUp);
        buttonDpadDown = findViewById(R.id.buttonDpadDown);
        buttonDpadLeft = findViewById(R.id.buttonDpadLeft);
        buttonDpadRight = findViewById(R.id.buttonDpadRight);
        buttonUndo = findViewById(R.id.buttonUndo);
        pauseOverlayView = findViewById(R.id.pauseOverlayView);
        
        textViewPauseLabel.setText("PAUSED");
        
        // Setup ViewModel
        viewModel = new ViewModelProvider(this).get(GameViewModel.class);
        
        try {
            List<int[][]> levels = LevelParser.loadLevelsFromAsset(getAssets(), "levels/original.sbl");
            viewModel.setLevels(levels);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // ─── Observe LiveData ──────────────────────────────────────────────
        
        viewModel.getCurrentLevelIndex().observe(this, index -> updateLevelDisplay());
        
        viewModel.getGrid().observe(this, grid -> {
            if (grid == null) return;
            
            Integer playerRow = viewModel.getPlayerRow().getValue();
            Integer playerCol = viewModel.getPlayerCol().getValue();
            Boolean completed = viewModel.getIsGameCompleted().getValue();
            
            if (playerRow == null || playerCol == null) {
                playerRow = 0;
                playerCol = 0;
            }
            
            if (playerRow >= grid.length) playerRow = grid.length - 1;
            if (playerCol >= grid[0].length) playerCol = grid[0].length - 1;
            
            gameView.updateGameState(grid, playerRow, playerCol, completed != null && completed);
            
            int remaining = viewModel.countRemainingGoals(grid);
            textViewRemainingGoals.setText(String.valueOf(remaining));
        });
        
        viewModel.getMoveCount().observe(this, moves -> textViewMoveCount.setText(String.valueOf(moves)));
        
        viewModel.getTimerSeconds().observe(this, seconds -> {
            int minutes = seconds / 60;
            int secs = seconds % 60;
            textViewTimer.setText(String.format("%02d:%02d", minutes, secs));
        });
        
        viewModel.getIsPaused().observe(this, paused -> {
            if (paused != null && paused) {
                pauseOverlayView.setVisibility(View.VISIBLE);
                textViewPauseLabel.setVisibility(View.VISIBLE);
                buttonPause.setText(EmojiConstants.RESUME);
            } else {
                pauseOverlayView.setVisibility(View.GONE);
                textViewPauseLabel.setVisibility(View.GONE);
                buttonPause.setText(EmojiConstants.PAUSE);
            }
        });
        
        viewModel.getIsGameCompleted().observe(this, completed -> {
            if (completed != null && completed) {
                autoAdvanceHandler.postDelayed(() -> viewModel.goToNextLevel(), 1500);
            }
        });
        
        // ─── Button Listeners ──────────────────────────────────────────────
        
        buttonPreviousLevel.setOnClickListener(v -> {
            animateButtonPress(v);
            viewModel.goToPreviousLevel();
        });
        
        buttonResetLevel.setOnClickListener(v -> {
            animateButtonPress(v);
            viewModel.resetCurrentLevel();
        });
        
        buttonPause.setOnClickListener(v -> {
            animateButtonPress(v);
            viewModel.togglePause();
        });
        
        buttonNextLevel.setOnClickListener(v -> {
            animateButtonPress(v);
            viewModel.goToNextLevel();
        });
        
        buttonResetGame.setOnClickListener(v -> {
            animateButtonPress(v);
            new AlertDialog.Builder(this)
                    .setTitle("Reset Game")
                    .setMessage("Delete all progress and start from level 1?")
                    .setPositiveButton("Reset", (dialog, which) -> viewModel.resetEntireGame())
                    .setNegativeButton("Cancel", null)
                    .show();
        });
        
        buttonDpadUp.setOnClickListener(v -> {
            animateButtonPress(v);
            viewModel.attemptMove(-1, 0);
        });
        
        buttonDpadDown.setOnClickListener(v -> {
            animateButtonPress(v);
            viewModel.attemptMove(1, 0);
        });
        
        buttonDpadLeft.setOnClickListener(v -> {
            animateButtonPress(v);
            viewModel.attemptMove(0, -1);
        });
        
        buttonDpadRight.setOnClickListener(v -> {
            animateButtonPress(v);
            viewModel.attemptMove(0, 1);
        });
        
        buttonUndo.setOnClickListener(v -> {
            animateButtonPress(v);
            viewModel.undoMove();
        });
        
        gameView.setFocusable(true);
        gameView.requestFocus();
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Animates a button press with a bounce effect.
     * The button moves down 4px and springs back.
     *
     * @param view The view to animate.
     */
    private void animateButtonPress(View view) {
        view.animate()
            .translationY(4f)
            .setDuration(50)
            .withEndAction(() -> view.animate()
                .translationY(0f)
                .setDuration(100)
                .start())
            .start();
    }
    
    /**
     * Updates the level display with the current level and total levels.
     * If the current level is completed, a star emoji is appended.
     */
    private void updateLevelDisplay() {
        Integer index = viewModel.getCurrentLevelIndex().getValue();
        Integer total = viewModel.getTotalLevels();
        if (index != null && total != null && total > 0) {
            textViewLevelDisplay.setText((index + 1) + " / " + total);
        }
        Set<Integer> completed = viewModel.getCompletedLevels().getValue();
        if (completed != null && index != null && completed.contains(index)) {
            textViewLevelDisplay.append(" " + EmojiConstants.STAR);
        }
    }
    
    // ========================================================================
    // Lifecycle – Pause / Resume
    // ========================================================================
    
    /**
     * Called when the activity is paused.
     * Stops the timer to save battery.
     */
    @Override
    protected void onPause() {
        super.onPause();
        viewModel.stopTimer();
    }
    
    /**
     * Called when the activity is resumed.
     * Restarts the timer if conditions allow.
     * 
     * <p>Conditions: not paused, not completed, and move count > 0.</p>
     */
    @Override
    protected void onResume() {
        super.onResume();
        if (viewModel.getIsPaused().getValue() == Boolean.FALSE &&
            viewModel.getIsGameCompleted().getValue() == Boolean.FALSE &&
            viewModel.getMoveCount().getValue() > 0) {
            viewModel.startTimer();
        }
    }
    
    /**
     * Handles the back button: unpauses if paused, otherwise exits.
     */
    @Override
    public void onBackPressed() {
        if (pauseOverlayView.getVisibility() == View.VISIBLE) {
            viewModel.togglePause();
        } else {
            super.onBackPressed();
        }
    }
}