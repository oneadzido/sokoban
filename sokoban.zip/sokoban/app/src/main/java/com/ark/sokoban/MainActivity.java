package com.ark.sokoban;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ark.sokoban.models.Direction;

import java.util.Set;

/**
 * Main Activity for the Sokoban game.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class MainActivity extends AppCompatActivity {
    
    // UI Components
    private GameView gameView;
    private TextView levelDisplay;
    private TextView moveDisplay;
    private TextView goalDisplay;
    private TextView timerDisplay;
    private TextView pauseLabel;
    private View pauseOverlay;
    
    // Buttons
    private TextView prevButton;
    private TextView resetButton;
    private TextView pauseButton;
    private TextView nextButton;
    private TextView resetGameButton;
    private TextView undoButton;
    private TextView dpadUp;
    private TextView dpadDown;
    private TextView dpadLeft;
    private TextView dpadRight;
    
    // ViewModel
    private GameViewModel viewModel;
    private final Handler autoAdvanceHandler = new Handler();
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initViews();
        setupViewModel();
        setupObservers();
        setupListeners();
        
        // Load levels from assets
        try {
            viewModel.loadLevels("original.sbl");
        } catch (Exception e) {
            e.printStackTrace();
            showErrorDialog("Failed to load levels: " + e.getMessage());
        }
    }
    
    private void initViews() {
        gameView = findViewById(R.id.gameView);
        levelDisplay = findViewById(R.id.textViewLevelDisplay);
        moveDisplay = findViewById(R.id.textViewMoveCount);
        goalDisplay = findViewById(R.id.textViewRemainingGoals);
        timerDisplay = findViewById(R.id.textViewTimer);
        pauseLabel = findViewById(R.id.textViewPauseLabel);
        pauseOverlay = findViewById(R.id.pauseOverlayView);
        
        prevButton = findViewById(R.id.buttonPreviousLevel);
        resetButton = findViewById(R.id.buttonResetLevel);
        pauseButton = findViewById(R.id.buttonPause);
        nextButton = findViewById(R.id.buttonNextLevel);
        resetGameButton = findViewById(R.id.buttonResetGame);
        undoButton = findViewById(R.id.buttonUndo);
        
        dpadUp = findViewById(R.id.buttonDpadUp);
        dpadDown = findViewById(R.id.buttonDpadDown);
        dpadLeft = findViewById(R.id.buttonDpadLeft);
        dpadRight = findViewById(R.id.buttonDpadRight);
        
        // Set initial button texts
        prevButton.setText(EmojiConstants.PREVIOUS);
        resetButton.setText(EmojiConstants.RESET_LEVEL);
        pauseButton.setText(EmojiConstants.PAUSE);
        nextButton.setText(EmojiConstants.NEXT);
        resetGameButton.setText(EmojiConstants.RESET_GAME);
        undoButton.setText(EmojiConstants.UNDO);
        dpadUp.setText(EmojiConstants.DPAD_UP);
        dpadDown.setText(EmojiConstants.DPAD_DOWN);
        dpadLeft.setText(EmojiConstants.DPAD_LEFT);
        dpadRight.setText(EmojiConstants.DPAD_RIGHT);
        
        pauseLabel.setText("⏸️ PAUSED");
    }
    
    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(GameViewModel.class);
    }
    
    private void setupObservers() {
        // Level index
        viewModel.getCurrentLevelIndex().observe(this, index -> {
            updateLevelDisplay();
        });
        
        // Grid
        viewModel.getGrid().observe(this, grid -> {
            if (grid == null) return;
            Integer row = viewModel.getPlayerRow().getValue();
            Integer col = viewModel.getPlayerCol().getValue();
            Boolean completed = viewModel.getIsCompleted().getValue();
            
            if (row == null) row = 0;
            if (col == null) col = 0;
            if (completed == null) completed = false;
            
            gameView.updateGameState(grid, row, col, completed);
            updateGoalDisplay();
        });
        
        // Moves
        viewModel.getMoveCount().observe(this, moves -> {
            moveDisplay.setText(EmojiConstants.FOOTSTEPS + " " + moves);
        });
        
        // Timer
        viewModel.getTimerSeconds().observe(this, seconds -> {
            int minutes = seconds / 60;
            int secs = seconds % 60;
            timerDisplay.setText(EmojiConstants.CLOCK + " " + 
                String.format("%02d:%02d", minutes, secs));
        });
        
        // Pause
        viewModel.getIsPaused().observe(this, paused -> {
            if (paused != null && paused) {
                pauseOverlay.setVisibility(View.VISIBLE);
                pauseLabel.setVisibility(View.VISIBLE);
                pauseButton.setText(EmojiConstants.RESUME);
            } else {
                pauseOverlay.setVisibility(View.GONE);
                pauseLabel.setVisibility(View.GONE);
                pauseButton.setText(EmojiConstants.PAUSE);
            }
        });
        
        // Completion
        viewModel.getIsCompleted().observe(this, completed -> {
            if (completed != null && completed) {
                autoAdvanceHandler.postDelayed(() -> {
                    viewModel.goToNextLevel();
                }, 1500);
            }
        });
    }
    
    private void setupListeners() {
        // Navigation buttons
        prevButton.setOnClickListener(v -> {
            animateButton(v);
            viewModel.goToPreviousLevel();
        });
        
        nextButton.setOnClickListener(v -> {
            animateButton(v);
            viewModel.goToNextLevel();
        });
        
        // Reset
        resetButton.setOnClickListener(v -> {
            animateButton(v);
            viewModel.resetCurrentLevel();
        });
        
        resetGameButton.setOnClickListener(v -> {
            animateButton(v);
            new AlertDialog.Builder(this)
                .setTitle("Reset Game")
                .setMessage("Delete all progress and start from level 1?")
                .setPositiveButton("Reset", (dialog, which) -> viewModel.resetEntireGame())
                .setNegativeButton("Cancel", null)
                .show();
        });
        
        // Pause
        pauseButton.setOnClickListener(v -> {
            animateButton(v);
            viewModel.togglePause();
        });
        
        // Undo
        undoButton.setOnClickListener(v -> {
            animateButton(v);
            viewModel.undoMove();
        });
        
        // D-pad
        dpadUp.setOnClickListener(v -> {
            animateButton(v);
            viewModel.attemptMove(Direction.UP);
        });
        
        dpadDown.setOnClickListener(v -> {
            animateButton(v);
            viewModel.attemptMove(Direction.DOWN);
        });
        
        dpadLeft.setOnClickListener(v -> {
            animateButton(v);
            viewModel.attemptMove(Direction.LEFT);
        });
        
        dpadRight.setOnClickListener(v -> {
            animateButton(v);
            viewModel.attemptMove(Direction.RIGHT);
        });
        
        // Keyboard support
        gameView.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
                Direction dir = null;
                switch (keyCode) {
                    case android.view.KeyEvent.KEYCODE_DPAD_UP:
                    case android.view.KeyEvent.KEYCODE_W:
                        dir = Direction.UP;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_DOWN:
                    case android.view.KeyEvent.KEYCODE_S:
                        dir = Direction.DOWN;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_LEFT:
                    case android.view.KeyEvent.KEYCODE_A:
                        dir = Direction.LEFT;
                        break;
                    case android.view.KeyEvent.KEYCODE_DPAD_RIGHT:
                    case android.view.KeyEvent.KEYCODE_D:
                        dir = Direction.RIGHT;
                        break;
                    case android.view.KeyEvent.KEYCODE_U:
                        viewModel.undoMove();
                        return true;
                }
                if (dir != null) {
                    viewModel.attemptMove(dir);
                    return true;
                }
            }
            return false;
        });
        
        gameView.requestFocus();
    }
    
    private void updateLevelDisplay() {
        Integer index = viewModel.getCurrentLevelIndex().getValue();
        Integer total = viewModel.getTotalLevels();
        if (index != null && total != null && total > 0) {
            String text = (index + 1) + " / " + total;
            Set<Integer> completed = viewModel.getCompletedLevels().getValue();
            if (completed != null && completed.contains(index)) {
                text += " " + EmojiConstants.STAR;
            }
            levelDisplay.setText(text);
        }
    }
    
    private void updateGoalDisplay() {
        int remaining = viewModel.getRemainingGoals();
        goalDisplay.setText(EmojiConstants.TARGET + " " + remaining);
    }
    
    private void animateButton(View view) {
        Animation anim = AnimationUtils.loadAnimation(this, 
            android.R.anim.fade_in);
        anim.setDuration(50);
        view.startAnimation(anim);
    }
    
    private void showErrorDialog(String message) {
        new AlertDialog.Builder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show();
    }
    
    @Override
    protected void onPause() {
        super.onPause();
        viewModel.stopTimer();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        Boolean paused = viewModel.getIsPaused().getValue();
        Boolean completed = viewModel.getIsCompleted().getValue();
        Integer moves = viewModel.getMoveCount().getValue();
        
        if (paused != null && !paused && 
            completed != null && !completed && 
            moves != null && moves > 0) {
            viewModel.startTimer();
        }
    }
    
    @Override
    public void onBackPressed() {
        if (pauseOverlay.getVisibility() == View.VISIBLE) {
            viewModel.togglePause();
        } else {
            super.onBackPressed();
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        autoAdvanceHandler.removeCallbacksAndMessages(null);
    }
}