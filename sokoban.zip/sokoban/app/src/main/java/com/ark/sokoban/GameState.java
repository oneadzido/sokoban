package com.ark.sokoban;

import java.io.Serializable;

/**
 * Data class representing the complete game state for save/restore.
 * 
 * <p>This class holds all the information needed to fully restore
 * the game at any point, including the level index, grid state,
 * player position, move count, timer, and which levels have been
 * completed. It is serialized to JSON using Gson and stored in
 * SharedPreferences.</p>
 * 
 * <p>Follows Google's recommendations for data classes with
 * public fields for simplicity.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameState implements Serializable {
    
    // ========================================================================
    // Fields
    // ========================================================================
    
    /** The current level index (0-based). */
    public int currentLevelIndex;
    
    /** The 2D grid representing the current level state.
     *  0 = floor, 1 = wall, 2 = goal, 3 = box, 4 = player (not used in saved state),
     *  5 = box on goal, 6 = player on goal (not used). */
    public int[][] grid;
    
    /** The row of the player in the grid. */
    public int playerRow;
    
    /** The column of the player in the grid. */
    public int playerCol;
    
    /** The number of moves made so far. */
    public int moveCount;
    
    /** The elapsed time in seconds. */
    public int timerSeconds;
    
    /** Array indicating which levels have been completed (parallel to levels list). */
    public boolean[] completedLevels;
}