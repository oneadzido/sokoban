package com.ark.sokoban;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Data class representing the complete game state for save/restore.
 * 
 * <p>This class encapsulates all the data needed to fully restore a game session,
 * including the current level, grid state, player position, move count, timer,
 * completed levels, and undo history. It implements Serializable to support
 * persistence via SharedPreferences.</p>
 * 
 * <p>Note: Timer IS stored in the save state for app restart, but is NOT
 * restored during undo operations to keep it immutable during gameplay.</p>
 * 
 * <p>Key Features:</p>
 * <ul>
 *   <li>Complete game state snapshot for persistence</li>
 *   <li>Deep copy support for undo history</li>
 *   <li>Level completion checking</li>
 *   <li>Serializable for SharedPreferences storage</li>
 * </ul>
 * 
 * File Location: app/src/main/java/com/ark/sokoban/GameState.java
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameState implements Serializable {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Serial version UID for compatibility across versions. */
    private static final long serialVersionUID = 1L;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** The current level index (0-based). */
    public int currentLevelIndex;
    
    /** The 2D grid representing the current level state. */
    public int[][] grid;
    
    /** The row of the player in the grid. */
    public int playerRow;
    
    /** The column of the player in the grid. */
    public int playerCol;
    
    /** The number of moves made so far. */
    public int moveCount;
    
    /** Elapsed timer in seconds. */
    public int timerSeconds;
    
    /** Set of completed level indices (0-based). */
    public Set<Integer> completedLevels = new HashSet<>();
    
    /** History of previous states for undo. */
    public GameState[] history;
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Checks if a level has been completed.
     * 
     * @param levelIndex The level index to check
     * @return True if the level is completed, false otherwise
     */
    public boolean isLevelCompleted(int levelIndex) {
        return completedLevels != null && completedLevels.contains(levelIndex);
    }
    
    /**
     * Creates a deep copy of this GameState.
     * 
     * <p>This method creates a completely independent copy of the game state,
     * including a deep copy of the grid and history arrays. This is used for
     * implementing undo functionality where the previous state must be
     * preserved independently.</p>
     * 
     * @return A deep copy of this GameState
     */
    public GameState deepCopy() {
        GameState copy = new GameState();
        copy.currentLevelIndex = this.currentLevelIndex;
        copy.grid = copyGrid(this.grid);
        copy.playerRow = this.playerRow;
        copy.playerCol = this.playerCol;
        copy.moveCount = this.moveCount;
        copy.timerSeconds = this.timerSeconds;
        copy.completedLevels = new HashSet<>(this.completedLevels);
        
        if (this.history != null) {
            copy.history = new GameState[this.history.length];
            for (int i = 0; i < this.history.length; i++) {
                copy.history[i] = this.history[i].deepCopy();
            }
        }
        
        return copy;
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Creates a deep copy of a 2D grid.
     * 
     * @param src The source grid to copy
     * @return A deep copy of the grid, or null if source is null
     */
    private int[][] copyGrid(int[][] src) {
        if (src == null) return null;
        int[][] copy = new int[src.length][];
        for (int i = 0; i < src.length; i++) {
            copy[i] = src[i].clone();
        }
        return copy;
    }
}