package com.ark.sokoban;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * Data class representing the complete game state for save/restore.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameState implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    /** The current level index (0-based). */
    public int currentLevelIndex;
    
    /** The 2D grid representing the current level state. */
    public int[][] grid;
    
    /** The row of the player in the grid. */
    public int playerRow;
    
    /** The column of the player in the grid. */
    public int playerCol;
    
    /** The number of moves made so far. */
    public int moveCount;
    
    /** The elapsed time in seconds. */
    public int timerSeconds;
    
    /** Set of completed level indices (0-based). */
    public Set<Integer> completedLevels = new HashSet<>();
    
    /** History of previous states for undo. */
    public GameState[] history;
    
    /**
     * Checks if a level is completed.
     * 
     * @param levelIndex The level index
     * @return True if the level is completed
     */
    public boolean isLevelCompleted(int levelIndex) {
        return completedLevels != null && completedLevels.contains(levelIndex);
    }
    
    /**
     * Creates a deep copy of this GameState.
     * 
     * @return A deep copy
     */
    public GameState deepCopy() {
        GameState copy = new GameState();
        copy.currentLevelIndex = this.currentLevelIndex;
        copy.grid = copyGrid(this.grid);
        copy.playerRow = this.playerRow;
        copy.playerCol = this.playerCol;
        copy.moveCount = this.moveCount;
        copy.timerSeconds = this.timerSeconds;
        copy.completedLevels = new HashSet<>(this.completedLevels);
        
        if (this.history != null) {
            copy.history = new GameState[this.history.length];
            for (int i = 0; i < this.history.length; i++) {
                copy.history[i] = this.history[i].deepCopy();
            }
        }
        
        return copy;
    }
    
    /**
     * Creates a deep copy of a 2D grid.
     */
    private int[][] copyGrid(int[][] src) {
        if (src == null) return null;
        int[][] copy = new int[src.length][];
        for (int i = 0; i < src.length; i++) {
            copy[i] = src[i].clone();
        }
        return copy;
    }
}