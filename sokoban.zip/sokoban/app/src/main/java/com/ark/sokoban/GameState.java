package com.ark.sokoban;

import com.ark.sokoban.models.Direction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Data class representing the complete game state for save/restore.
 * 
 * <p>This class encapsulates all the data needed to fully restore a game session,
 * including the current level, grid state, player position, move count, timer,
 * solved levels, and move history.</p>
 * 
 * <p>History is stored as a List of Direction objects (the moves themselves).
 * This is the delta-based approach - we store only the directions, not full states.</p>
 * 
 * File Location: app/src/main/java/com/ark/sokoban/GameState.java
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class GameState implements Serializable {
    
    // ========================================================================
    // Constants
    // ========================================================================
    
    /** Serial version UID for compatibility across versions. */
    private static final long serialVersionUID = 1L;
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** The current level index (0-based). */
    public int currentLevelIndex;
    
    /** The 2D grid representing the current level state. */
    public int[][] grid;
    
    /** The row of the player in the grid. */
    public int playerRow;
    
    /** The column of the player in the grid. */
    public int playerCol;
    
    /** The number of moves made so far. */
    public int moveCount;
    
    /** Elapsed timer in seconds. */
    public int timerSeconds;
    
    /** Set of solved level indices (0-based). */
    public Set<Integer> solvedLevels = new HashSet<>();
    
    /** History stored as Directions (delta-based, no full states). */
    public List<Direction> history = new ArrayList<>();
    
    // ========================================================================
    // Public Methods
    // ========================================================================
    
    /**
     * Checks if a level has been solved.
     * 
     * @param levelIndex The level index to check
     * @return True if the level is solved, false otherwise
     */
    public boolean isLevelSolved(int levelIndex) {
        return solvedLevels != null && solvedLevels.contains(levelIndex);
    }
    
    /**
     * Creates a deep copy of this GameState.
     * 
     * <p>This method creates a completely independent copy of the game state,
     * including a deep copy of the grid. This is used for replaying moves.</p>
     * 
     * @return A deep copy of this GameState
     */
    public GameState deepCopy() {
        GameState copy = new GameState();
        copy.currentLevelIndex = this.currentLevelIndex;
        copy.grid = copyGrid(this.grid);
        copy.playerRow = this.playerRow;
        copy.playerCol = this.playerCol;
        copy.moveCount = this.moveCount;
        copy.timerSeconds = this.timerSeconds;
        copy.solvedLevels = new HashSet<>(this.solvedLevels);
        return copy;
    }
    
    // ========================================================================
    // Private Methods
    // ========================================================================
    
    /**
     * Creates a deep copy of a 2D grid.
     * 
     * @param src The source grid to copy
     * @return A deep copy of the grid, or null if source is null
     */
    private int[][] copyGrid(int[][] src) {
        if (src == null) return null;
        int[][] copy = new int[src.length][];
        for (int i = 0; i < src.length; i++) {
            copy[i] = src[i].clone();
        }
        return copy;
    }
}