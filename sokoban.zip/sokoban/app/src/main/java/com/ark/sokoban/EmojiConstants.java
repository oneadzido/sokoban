package com.ark.sokoban;

/**
 * Centralized emoji constants for the Sokoban game.
 * 
 * <p>All emojis used throughout the app should be defined here
 * to ensure consistency and ease of maintenance.</p>
 * 
 * <p>For vector icons (buttons, D-Pad), use {@link com.ark.sokoban.FontAwesome} instead.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class EmojiConstants {
    
    /**
     * Private constructor to prevent instantiation.
     * This class follows the utility class pattern.
     */
    private EmojiConstants() {
        // Utility class - prevent instantiation
    }
    
    // ========================================================================
    // Game Board Emojis
    // ========================================================================
    
    /** Wall emoji used for rendering walls on the game board. */
    public static final String WALL = "🧱";
    
    /** Box emoji used for rendering boxes on the game board. */
    public static final String BOX = "📦";
    
    /** Player emoji used for rendering the player on the game board. */
    public static final String PLAYER = "🧒🏾";
    
    // ========================================================================
    // Stats Emojis
    // ========================================================================
    
    /** Footsteps emoji displayed next to the move count. */
    public static final String FOOTSTEPS = "👣";
    
    /** Target emoji displayed next to the remaining goals count. */
    public static final String TARGET = "🎯";
    
    /** Clock emoji displayed next to the timer. */
    public static final String CLOCK = "⏱️";
    
    // ========================================================================
    // Completion & Record Stats
    // ========================================================================
    
    /** Record label displayed in the record stats row. */
    public static final String RECORD = "RECORD";
    
    /** Level icon displayed next to the level number. */
    public static final String LEVEL = "🪧";
}