package com.ark.sokoban;

/**
 * Centralized emoji constants for the Sokoban game.
 * 
 * <p>All emojis used throughout the app should be defined here
 * to ensure consistency and ease of maintenance.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class EmojiConstants {
    
    private EmojiConstants() {
        // Utility class - prevent instantiation
    }
    
    // ========================================================================
    // Game Board Emojis
    // ========================================================================
    
    /** Wall emoji. */
    public static final String WALL = "🧱";
    
    /** Box emoji. */
    public static final String BOX = "📦";
    
    /** Player emoji. */
    public static final String PLAYER = "🧒🏾";
    
    // ========================================================================
    // Stats Emojis
    // ========================================================================
    
    /** Footsteps emoji for move count. */
    public static final String FOOTSTEPS = "👣";
    
    /** Target emoji for goals. */
    public static final String TARGET = "🎯";
    
    /** Clock emoji for timer. */
    public static final String CLOCK = "⏱️";
    
    /** Star emoji for completion. */
    public static final String STAR = "⭐";
    
    // ========================================================================
    // Button Emojis
    // ========================================================================
    
    /** Previous level button. */
    public static final String PREVIOUS = "⏪";
    
    /** Reset level button. */
    public static final String RESET_LEVEL = "🔂";
    
    /** Pause button. */
    public static final String PAUSE = "⏸️";
    
    /** Resume button. */
    public static final String RESUME = "▶️";
    
    /** Reset game button. */
    public static final String RESET_GAME = "🔁";
    
    /** Next level button. */
    public static final String NEXT = "⏩";
    
    /** Undo button. */
    public static final String UNDO = "↩️";
    
    // ========================================================================
    // D-Pad Emojis
    // ========================================================================
    
    /** D-Pad up. */
    public static final String DPAD_UP = "⬆️";
    
    /** D-Pad down. */
    public static final String DPAD_DOWN = "⬇️";
    
    /** D-Pad left. */
    public static final String DPAD_LEFT = "⬅️";
    
    /** D-Pad right. */
    public static final String DPAD_RIGHT = "➡️";
    
    // ========================================================================
    // Completion & Best Stats
    // ========================================================================
    
    /** Best label for stats. */
    public static final String BEST = "BEST";
    
    /** Level icon. */
    public static final String LEVEL = "🪧";
    
    /** Clap emoji for congratulations. */
    public static final String CLAP = "👏🏾";
}