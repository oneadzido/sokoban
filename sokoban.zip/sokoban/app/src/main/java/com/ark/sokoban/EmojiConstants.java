package com.ark.sokoban;

/**
 * Centralized emoji constants for the Sokoban game.
 * 
 * <p>This class serves as the single source of truth for all emojis used
 * throughout the application. By centralizing emoji definitions, we ensure
 * consistency and make it easy to update emojis across the entire app.</p>
 * 
 * <p>Emojis are organized by their usage context:</p>
 * <ul>
 *   <li><b>Stats Emojis:</b> Used in the statistics row (moves, goals, timer)</li>
 *   <li><b>Game Board Emojis:</b> Used to render the game board (wall, target, box, player)</li>
 *   <li><b>Button Row Emojis:</b> Used for action buttons (prev, reset, pause, next)</li>
 *   <li><b>D-Pad Emojis:</b> Used for directional controls (up, down, left, right, undo)</li>
 * </ul>
 * 
 * <p>This class follows the utility class pattern with a private constructor
 * and all static fields. It should never be instantiated.</p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class EmojiConstants {
    
    // ========================================================================
    // Private Constructor - Utility class
    // ========================================================================
    
    /**
     * Private constructor to prevent instantiation.
     * This class is a utility and should never be instantiated.
     */
    private EmojiConstants() {
        // Private constructor to prevent instantiation
    }
    
    // ========================================================================
    // Stats Emojis
    // ========================================================================
    
    /** Moves counter icon - footsteps emoji. */
    public static final String FOOTSTEPS = "👣";
    
    /** Remaining goals icon - bullseye/target emoji. */
    public static final String TARGET = "🎯";
    
    /** Timer icon - clock emoji. */
    public static final String CLOCK = "⏱️";
    
    // ========================================================================
    // Game Board Emojis
    // ========================================================================
    
    /** Wall emoji - used to render walls on the game board. */
    public static final String WALL = "🧱";
    
    /** Goal/target emoji - used to render targets on the game board. */
    public static final String GOAL = "🎯";
    
    /** Box emoji - used to render boxes on the game board. */
    public static final String BOX = "📦";
    
    /** Player emoji - child with dark skin tone, represents the player character. */
    public static final String PLAYER = "🧒🏾";
    
    /** Star emoji - used for level completion indicators. */
    public static final String STAR = "⭐";
    
    // ========================================================================
    // Button Row Emojis
    // ========================================================================
    
    /** Previous level button - fast backward emoji. */
    public static final String PREVIOUS = "⏪";
    
    /** Reset current level button - repeat one emoji. */
    public static final String RESET_LEVEL = "🔂";
    
    /** Pause button - pause emoji. */
    public static final String PAUSE = "⏸️";
    
    /** Resume button - play emoji. */
    public static final String RESUME = "▶️";
    
    /** Reset entire game button - repeat all emoji (clears all progress). */
    public static final String RESET_GAME = "🔁";
    
    /** Next level button - fast forward emoji. */
    public static final String NEXT = "⏩";
    
    // ========================================================================
    // D-Pad Emojis
    // ========================================================================
    
    /** D-pad up - up arrow emoji. */
    public static final String DPAD_UP = "⬆️";
    
    /** D-pad down - down arrow emoji. */
    public static final String DPAD_DOWN = "⬇️";
    
    /** D-pad left - left arrow emoji. */
    public static final String DPAD_LEFT = "⬅️";
    
    /** D-pad right - right arrow emoji. */
    public static final String DPAD_RIGHT = "➡️";
    
    /** Undo button - undo/return emoji. */
    public static final String UNDO = "↩️";
}