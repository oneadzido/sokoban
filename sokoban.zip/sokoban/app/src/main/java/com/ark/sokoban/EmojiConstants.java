package com.ark.sokoban;

/**
 * Centralized emoji constants for the Sokoban game.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public final class EmojiConstants {
    
    private EmojiConstants() {
        // Utility class - prevent instantiation
    }
    
    // Stats
    public static final String FOOTSTEPS = "👣";
    public static final String TARGET = "🎯";
    public static final String CLOCK = "⏱️";
    public static final String STAR = "⭐";
    
    // Buttons
    public static final String PREVIOUS = "⏪";
    public static final String RESET_LEVEL = "🔂";
    public static final String PAUSE = "⏸️";
    public static final String RESUME = "▶️";
    public static final String RESET_GAME = "🔁";
    public static final String NEXT = "⏩";
    public static final String UNDO = "↩️";
    
    // D-Pad
    public static final String DPAD_UP = "⬆️";
    public static final String DPAD_DOWN = "⬇️";
    public static final String DPAD_LEFT = "⬅️";
    public static final String DPAD_RIGHT = "➡️";
}