package com.ark.sokoban.models;

import java.util.Arrays;

/**
 * Represents a Sokoban level with its grid and metadata.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 */
public class Level {
    private final int[][] grid;
    private final int rows;
    private final int cols;
    private final int playerStartRow;
    private final int playerStartCol;
    private final int goalCount;
    private String name;
    
    /**
     * Constructs a new Level with the given grid.
     * 
     * @param grid The 2D grid representing the level
     * @throws IllegalArgumentException if grid is null or empty
     */
    public Level(int[][] grid) {
        if (grid == null || grid.length == 0 || grid[0].length == 0) {
            throw new IllegalArgumentException("Grid cannot be null or empty");
        }
        
        this.grid = deepCopy(grid);
        this.rows = grid.length;
        this.cols = grid[0].length;
        
        // Find player position and count goals
        int playerRow = -1;
        int playerCol = -1;
        int goalCount = 0;
        
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int val = grid[r][c];
                if (val == CellType.PLAYER.getValue() || val == CellType.PLAYER_ON_GOAL.getValue()) {
                    playerRow = r;
                    playerCol = c;
                }
                if (val == CellType.GOAL.getValue() || val == CellType.BOX_ON_GOAL.getValue() || 
                    val == CellType.PLAYER_ON_GOAL.getValue()) {
                    goalCount++;
                }
            }
        }
        
        this.playerStartRow = playerRow >= 0 ? playerRow : 0;
        this.playerStartCol = playerCol >= 0 ? playerCol : 0;
        this.goalCount = goalCount;
        this.name = "Level " + (goalCount > 0 ? "" : " (Empty)");
    }
    
    /**
     * Gets the level grid.
     * 
     * @return A deep copy of the grid
     */
    public int[][] getGrid() {
        return deepCopy(grid);
    }
    
    /**
     * Gets the number of rows in the grid.
     */
    public int getRows() {
        return rows;
    }
    
    /**
     * Gets the number of columns in the grid.
     */
    public int getCols() {
        return cols;
    }
    
    /**
     * Gets the player's starting row.
     */
    public int getPlayerStartRow() {
        return playerStartRow;
    }
    
    /**
     * Gets the player's starting column.
     */
    public int getPlayerStartCol() {
        return playerStartCol;
    }
    
    /**
     * Gets the total number of goals in the level.
     */
    public int getGoalCount() {
        return goalCount;
    }
    
    /**
     * Gets the level name.
     */
    public String getName() {
        return name;
    }
    
    /**
     * Sets the level name.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Creates a deep copy of a 2D grid.
     * 
     * @param src The source grid
     * @return A deep copy
     */
    private int[][] deepCopy(int[][] src) {
        int[][] copy = new int[src.length][];
        for (int i = 0; i < src.length; i++) {
            copy[i] = src[i].clone();
        }
        return copy;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Level level = (Level) o;
        return rows == level.rows && 
               cols == level.cols && 
               Arrays.deepEquals(grid, level.grid);
    }
    
    @Override
    public int hashCode() {
        return Arrays.deepHashCode(grid);
    }
    
    @Override
    public String toString() {
        return name + " (" + rows + "x" + cols + ", " + goalCount + " goals)";
    }
}