package com.ark.sokoban.models;

import java.util.Arrays;

/**
 * Represents a Sokoban level with its grid and metadata.
 * 
 * <p>This class encapsulates all data related to a single Sokoban level,
 * including the grid layout, dimensions, player starting position,
 * and goal count. It provides methods for accessing the level data
 * and creating deep copies of the grid.</p>
 * 
 * <p>Grid values follow the standard Sokoban encoding:</p>
 * <ul>
 *   <li>0 - FLOOR: Empty traversable space</li>
 *   <li>1 - WALL: Impassable barrier</li>
 *   <li>2 - GOAL: Target location</li>
 *   <li>3 - BOX: Pushable object</li>
 *   <li>4 - PLAYER: Player character</li>
 *   <li>5 - BOX_ON_GOAL: Box on goal</li>
 *   <li>6 - PLAYER_ON_GOAL: Player on goal</li>
 * </ul>
 * 
 * File Location: app/src/main/java/com/ark/sokoban/models/Level.java
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class Level {
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** The 2D grid representing the level. */
    private final int[][] grid;
    
    /** The number of rows in the grid. */
    private final int rows;
    
    /** The number of columns in the grid. */
    private final int cols;
    
    /** The player's starting row position. */
    private final int playerStartRow;
    
    /** The player's starting column position. */
    private final int playerStartCol;
    
    /** The total number of goals in the level. */
    private final int goalCount;
    
    /** The name of the level. */
    private String name;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new Level with the given grid.
     * 
     * <p>This constructor analyzes the grid to find the player position
     * and count the total number of goals. The grid is deep-copied to
     * prevent external modification.</p>
     * 
     * @param grid The 2D grid representing the level
     * @throws IllegalArgumentException if grid is null or empty
     */
    public Level(int[][] grid) {
        if (grid == null || grid.length == 0 || grid[0].length == 0) {
            throw new IllegalArgumentException("Grid cannot be null or empty");
        }
        
        this.grid = deepCopy(grid);
        this.rows = grid.length;
        this.cols = grid[0].length;
        
        // Find player position and count goals
        int playerRow = -1;
        int playerCol = -1;
        int goalCount = 0;
        
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int val = grid[r][c];
                if (val == CellType.PLAYER.getValue() || val == CellType.PLAYER_ON_GOAL.getValue()) {
                    playerRow = r;
                    playerCol = c;
                }
                if (val == CellType.GOAL.getValue() || val == CellType.BOX_ON_GOAL.getValue() || 
                    val == CellType.PLAYER_ON_GOAL.getValue()) {
                    goalCount++;
                }
            }
        }
        
        this.playerStartRow = playerRow >= 0 ? playerRow : 0;
        this.playerStartCol = playerCol >= 0 ? playerCol : 0;
        this.goalCount = goalCount;
        this.name = "Level " + (goalCount > 0 ? "" : " (Empty)");
    }
    
    // ========================================================================
    // Getters
    // ========================================================================
    
    /**
     * Gets the level grid.
     * 
     * @return A deep copy of the grid
     */
    public int[][] getGrid() {
        return deepCopy(grid);
    }
    
    /**
     * Gets the number of rows in the grid.
     *
     * @return The number of rows
     */
    public int getRows() {
        return rows;
    }
    
    /**
     * Gets the number of columns in the grid.
     *
     * @return The number of columns
     */
    public int getCols() {
        return cols;
    }
    
    /**
     * Gets the player's starting row position.
     *
     * @return The starting row
     */
    public int getPlayerStartRow() {
        return playerStartRow;
    }
    
    /**
     * Gets the player's starting column position.
     *
     * @return The starting column
     */
    public int getPlayerStartCol() {
        return playerStartCol;
    }
    
    /**
     * Gets the total number of goals in the level.
     *
     * @return The total goal count
     */
    public int getGoalCount() {
        return goalCount;
    }
    
    /**
     * Gets the level name.
     *
     * @return The level name
     */
    public String getName() {
        return name;
    }
    
    // ========================================================================
    // Setters
    // ========================================================================
    
    /**
     * Sets the level name.
     *
     * @param name The new level name
     */
    public void setName(String name) {
        this.name = name;
    }
    
    // ========================================================================
    // Utility Methods
    // ========================================================================
    
    /**
     * Creates a deep copy of a 2D grid.
     * 
     * @param src The source grid
     * @return A deep copy of the grid
     */
    private int[][] deepCopy(int[][] src) {
        int[][] copy = new int[src.length][];
        for (int i = 0; i < src.length; i++) {
            copy[i] = src[i].clone();
        }
        return copy;
    }
    
    // ========================================================================
    // Object Overrides
    // ========================================================================
    
    /**
     * Compares this level with another object for equality.
     * 
     * <p>Two levels are considered equal if they have the same dimensions
     * and identical grid content.</p>
     *
     * @param o The object to compare with
     * @return True if the levels are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Level level = (Level) o;
        return rows == level.rows && 
               cols == level.cols && 
               Arrays.deepEquals(grid, level.grid);
    }
    
    /**
     * Returns the hash code for this level.
     *
     * @return The hash code based on the grid content
     */
    @Override
    public int hashCode() {
        return Arrays.deepHashCode(grid);
    }
    
    /**
     * Returns a string representation of this level.
     *
     * @return A descriptive string with name, dimensions, and goal count
     */
    @Override
    public String toString() {
        return name + " (" + rows + "x" + cols + ", " + goalCount + " goals)";
    }
}