package com.ark.sokoban.models;

/**
 * Represents the four possible movement directions in the game.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 */
public enum Direction {
    UP(-1, 0),
    DOWN(1, 0),
    LEFT(0, -1),
    RIGHT(0, 1);
    
    private final int deltaRow;
    private final int deltaCol;
    
    Direction(int deltaRow, int deltaCol) {
        this.deltaRow = deltaRow;
        this.deltaCol = deltaCol;
    }
    
    public int getDeltaRow() {
        return deltaRow;
    }
    
    public int getDeltaCol() {
        return deltaCol;
    }
    
    /**
     * Gets the opposite direction.
     * 
     * @return The opposite direction
     */
    public Direction opposite() {
        switch (this) {
            case UP: return DOWN;
            case DOWN: return UP;
            case LEFT: return RIGHT;
            case RIGHT: return LEFT;
            default: return this;
        }
    }
}