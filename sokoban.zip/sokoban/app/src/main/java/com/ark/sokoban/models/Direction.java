package com.ark.sokoban.models;

/**
 * Represents the four possible movement directions in the game.
 * 
 * <p>Each direction has a corresponding delta row and column value
 * that can be applied to a position to move in that direction.</p>
 * 
 * <p>Movement deltas:</p>
 * <ul>
 *   <li>UP: (-1, 0) - Move up one row</li>
 *   <li>DOWN: (1, 0) - Move down one row</li>
 *   <li>LEFT: (0, -1) - Move left one column</li>
 *   <li>RIGHT: (0, 1) - Move right one column</li>
 * </ul>
 * 
 * File Location: app/src/main/java/com/ark/sokoban/models/Direction.java
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public enum Direction {
    
    // ========================================================================
    // Enum Constants
    // ========================================================================
    
    /** Move up: delta row -1, delta col 0. */
    UP(-1, 0),
    
    /** Move down: delta row 1, delta col 0. */
    DOWN(1, 0),
    
    /** Move left: delta row 0, delta col -1. */
    LEFT(0, -1),
    
    /** Move right: delta row 0, delta col 1. */
    RIGHT(0, 1);
    
    // ========================================================================
    // Member Variables
    // ========================================================================
    
    /** The change in row when moving in this direction. */
    private final int deltaRow;
    
    /** The change in column when moving in this direction. */
    private final int deltaCol;
    
    // ========================================================================
    // Constructor
    // ========================================================================
    
    /**
     * Constructs a new Direction.
     *
     * @param deltaRow The change in row
     * @param deltaCol The change in column
     */
    Direction(int deltaRow, int deltaCol) {
        this.deltaRow = deltaRow;
        this.deltaCol = deltaCol;
    }
    
    // ========================================================================
    // Getters
    // ========================================================================
    
    /**
     * Gets the change in row for this direction.
     *
     * @return The delta row value
     */
    public int getDeltaRow() {
        return deltaRow;
    }
    
    /**
     * Gets the change in column for this direction.
     *
     * @return The delta column value
     */
    public int getDeltaCol() {
        return deltaCol;
    }
    
    // ========================================================================
    // Utility Methods
    // ========================================================================
    
    /**
     * Gets the opposite direction.
     * 
     * <p>UP ↔ DOWN, LEFT ↔ RIGHT</p>
     *
     * @return The opposite direction
     */
    public Direction opposite() {
        switch (this) {
            case UP: return DOWN;
            case DOWN: return UP;
            case LEFT: return RIGHT;
            case RIGHT: return LEFT;
            default: return this;
        }
    }
}