package com.ark.sokoban.utils;

import android.os.Handler;
import android.os.Looper;

/**
 * Utility class for managing the game timer.
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 */
public class TimerUtils {
    
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tickRunnable;
    private final TimerCallback callback;
    
    private boolean isRunning = false;
    private int elapsedSeconds = 0;
    
    /**
     * Callback interface for timer events.
     */
    public interface TimerCallback {
        void onTick(int seconds);
        void onStart();
        void onStop();
    }
    
    /**
     * Constructs a new TimerUtils instance.
     * 
     * @param callback The callback to receive timer events
     */
    public TimerUtils(TimerCallback callback) {
        this.callback = callback;
        this.tickRunnable = new Runnable() {
            @Override
            public void run() {
                if (isRunning) {
                    elapsedSeconds++;
                    if (callback != null) {
                        callback.onTick(elapsedSeconds);
                    }
                    handler.postDelayed(this, 1000);
                }
            }
        };
    }
    
    /**
     * Starts the timer.
     */
    public void start() {
        if (!isRunning) {
            isRunning = true;
            if (callback != null) {
                callback.onStart();
            }
            handler.post(tickRunnable);
        }
    }
    
    /**
     * Stops the timer.
     */
    public void stop() {
        if (isRunning) {
            isRunning = false;
            handler.removeCallbacks(tickRunnable);
            if (callback != null) {
                callback.onStop();
            }
        }
    }
    
    /**
     * Resets the timer to 0 and stops it.
     */
    public void reset() {
        stop();
        elapsedSeconds = 0;
        if (callback != null) {
            callback.onTick(0);
        }
    }
    
    /**
     * Gets the current elapsed time in seconds.
     * 
     * @return The elapsed seconds
     */
    public int getElapsedSeconds() {
        return elapsedSeconds;
    }
    
    /**
     * Checks if the timer is running.
     * 
     * @return True if the timer is running
     */
    public boolean isRunning() {
        return isRunning;
    }
    
    /**
     * Formats the elapsed time as MM:SS.
     * 
     * @return The formatted time string
     */
    public String getFormattedTime() {
        int minutes = elapsedSeconds / 60;
        int seconds = elapsedSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
    
    /**
     * Releases resources held by the timer.
     */
    public void release() {
        stop();
        handler.removeCallbacksAndMessages(null);
    }
}