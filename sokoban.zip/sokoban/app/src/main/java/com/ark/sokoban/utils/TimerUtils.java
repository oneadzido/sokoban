package com.ark.sokoban.utils;

import android.os.Handler;
import android.os.Looper;

/**
 * Utility class for managing the game timer.
 * 
 * <p>This class provides a simple timer implementation with start, stop,
 * reset, and formatting capabilities. It uses a Handler for posting
 * delayed updates on the main thread.</p>
 * 
 * <p>Usage example:
 * <pre>
 * TimerUtils timer = new TimerUtils(new TimerUtils.TimerCallback() {
 *     {@code @Override}
 *     public void onTick(int seconds) {
 *         // Update UI with current time
 *     }
 *     {@code @Override}
 *     public void onStart() {
 *         // Timer started
 *     }
 *     {@code @Override}
 *     public void onStop() {
 *         // Timer stopped
 *     }
 * });
 * timer.start();
 * </pre>
 * </p>
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public class TimerUtils {
    
    /** Handler for posting timer updates on the main thread. */
    private final Handler handler = new Handler(Looper.getMainLooper());
    
    /** Runnable that handles timer ticks. */
    private final Runnable tickRunnable;
    
    /** Callback for timer events. */
    private final TimerCallback callback;
    
    /** Flag indicating whether the timer is currently running. */
    private boolean isRunning = false;
    
    /** Current elapsed time in seconds. */
    private int elapsedSeconds = 0;
    
    /**
     * Callback interface for timer events.
     * 
     * <p>Implement this interface to receive timer events including
     * ticks, start, and stop notifications.</p>
     */
    public interface TimerCallback {
        /**
         * Called on each timer tick.
         *
         * @param seconds The current elapsed time in seconds
         */
        void onTick(int seconds);
        
        /**
         * Called when the timer starts.
         */
        void onStart();
        
        /**
         * Called when the timer stops.
         */
        void onStop();
    }
    
    /**
     * Constructs a new TimerUtils instance.
     * 
     * @param callback The callback to receive timer events
     */
    public TimerUtils(TimerCallback callback) {
        this.callback = callback;
        this.tickRunnable = new Runnable() {
            @Override
            public void run() {
                if (isRunning) {
                    elapsedSeconds++;
                    if (callback != null) {
                        callback.onTick(elapsedSeconds);
                    }
                    handler.postDelayed(this, 1000);
                }
            }
        };
    }
    
    /**
     * Starts the timer.
     * 
     * <p>If the timer is already running, this method does nothing.
     * The callback's onStart() method is called when starting.</p>
     */
    public void start() {
        if (!isRunning) {
            isRunning = true;
            if (callback != null) {
                callback.onStart();
            }
            handler.post(tickRunnable);
        }
    }
    
    /**
     * Stops the timer.
     * 
     * <p>If the timer is not running, this method does nothing.
     * The callback's onStop() method is called when stopping.</p>
     */
    public void stop() {
        if (isRunning) {
            isRunning = false;
            handler.removeCallbacks(tickRunnable);
            if (callback != null) {
                callback.onStop();
            }
        }
    }
    
    /**
     * Resets the timer to 0 and stops it.
     * 
     * <p>This method stops the timer and resets the elapsed time to 0.
     * The callback's onTick(0) method is called after reset.</p>
     */
    public void reset() {
        stop();
        elapsedSeconds = 0;
        if (callback != null) {
            callback.onTick(0);
        }
    }
    
    /**
     * Gets the current elapsed time in seconds.
     * 
     * @return The elapsed seconds
     */
    public int getElapsedSeconds() {
        return elapsedSeconds;
    }
    
    /**
     * Checks if the timer is currently running.
     * 
     * @return True if the timer is running, false otherwise
     */
    public boolean isRunning() {
        return isRunning;
    }
    
    /**
     * Formats the elapsed time as MM:SS.
     * 
     * @return The formatted time string (e.g., "01:30" for 90 seconds)
     */
    public String getFormattedTime() {
        int minutes = elapsedSeconds / 60;
        int seconds = elapsedSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
    
    /**
     * Releases resources held by the timer.
     * 
     * <p>This method stops the timer and removes all pending callbacks
     * to prevent memory leaks.</p>
     */
    public void release() {
        stop();
        handler.removeCallbacksAndMessages(null);
    }
}