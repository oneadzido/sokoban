package com.ark.sokoban;

import androidx.lifecycle.LiveData;
import java.util.List;
import java.util.Set;

/**
 * Game interface for the Sokoban puzzle game.
 * 
 * <p>This interface defines the contract between the game logic and its
 * UI components. It follows the Model-View-ViewModel (MVVM) architecture
 * pattern and provides methods for:
 * <ul>
 *   <li>Loading and managing levels</li>
 *   <li>Game state observation via LiveData</li>
 *   <li>Player movement and game logic</li>
 *   <li>Timer and pause functionality</li>
 *   <li>Save/restore and undo operations</li>
 * </ul>
 * </p>
 * 
 * <p>Implementation classes should be lifecycle-aware and maintain
 * state across configuration changes (e.g., screen rotation).</p>
 * 
 * File Location: app/src/main/java/com/ark/sokoban/GameInterface.java
 * 
 * @author Richard Korbla Adzido
 * @version 1.0.0
 * @since 1.0
 */
public interface GameInterface {
    
    // ========================================================================
    // Level Management
    // ========================================================================
    
    /**
     * Sets the list of levels and attempts to restore a saved state.
     * 
     * <p>If a saved state exists, it is restored. Otherwise, the first level
     * is loaded. This method should be called once during initialization.</p>
     *
     * @param levels The list of level grids. Must not be null.
     * @throws IllegalArgumentException if levels is null or empty.
     */
    void setLevels(List<int[][]> levels);
    
    /**
     * Loads a specific level, optionally restoring a saved grid.
     * 
     * <p>If savedGrid is provided, it is used directly; otherwise, a fresh
     * copy of the level is created from the original. The player position
     * is determined from the grid.</p>
     * 
     * <p>Cell values:</p>
     * <ul>
     *   <li>0: Floor (empty space)</li>
     *   <li>1: Wall (impassable)</li>
     *   <li>2: Goal (target location)</li>
     *   <li>3: Box (movable object)</li>
     *   <li>4: Player (character) - converted to floor when loading</li>
     *   <li>5: Box on goal (box correctly placed)</li>
     *   <li>6: Player on goal - converted to goal when loading</li>
     * </ul>
     *
     * @param levelIndex The index of the level to load (0-based).
     * @param savedGrid A previously saved grid, or null for fresh load.
     *                  If provided, must match the dimensions of the original level.
     * @throws IndexOutOfBoundsException if levelIndex is invalid.
     */
    void loadLevel(int levelIndex, int[][] savedGrid);
    
    /**
     * Returns the total number of levels available.
     *
     * @return The total level count, or 0 if no levels are loaded.
     */
    int getTotalLevels();
    
    // ========================================================================
    // Game State Observation (LiveData)
    // ========================================================================
    
    /**
     * Returns the current level index as LiveData.
     * 
     * <p>Observers will be notified when the level changes.</p>
     *
     * @return LiveData containing the current level index (0-based).
     */
    LiveData<Integer> getCurrentLevelIndex();
    
    /**
     * Returns the current grid state as LiveData.
     * 
     * <p>Observers will be notified when the grid changes (e.g., after
     * a move or level load).</p>
     *
     * @return LiveData containing the current grid (2D int array).
     */
    LiveData<int[][]> getGrid();
    
    /**
     * Returns the player's row position as LiveData.
     *
     * @return LiveData containing the player's row index.
     */
    LiveData<Integer> getPlayerRow();
    
    /**
     * Returns the player's column position as LiveData.
     *
     * @return LiveData containing the player's column index.
     */
    LiveData<Integer> getPlayerCol();
    
    /**
     * Returns the move count as LiveData.
     * 
     * <p>Observers will be notified when a move is made.</p>
     *
     * @return LiveData containing the number of moves made in the current level.
     */
    LiveData<Integer> getMoveCount();
    
    /**
     * Returns the elapsed timer in seconds as LiveData.
     * 
     * <p>The timer starts when the first move is made and stops when
     * the level is completed or paused.</p>
     *
     * @return LiveData containing the elapsed time in seconds.
     */
    LiveData<Integer> getTimerSeconds();
    
    /**
     * Returns the pause state as LiveData.
     *
     * @return LiveData containing true if the game is paused, false otherwise.
     */
    LiveData<Boolean> getIsPaused();
    
    /**
     * Returns the game completion state as LiveData.
     * 
     * <p>Observers will be notified when the level is completed.</p>
     *
     * @return LiveData containing true if the current level is completed.
     */
    LiveData<Boolean> getIsGameCompleted();
    
    /**
     * Returns the set of completed level indices as LiveData.
     * 
     * <p>Observers will be notified when a level is completed.</p>
     *
     * @return LiveData containing a Set of completed level indices (0-based).
     */
    LiveData<Set<Integer>> getCompletedLevels();
    
    // ========================================================================
    // Game Logic
    // ========================================================================
    
    /**
     * Attempts to move the player by the given delta.
     * 
     * <p>This method handles both walking and pushing boxes, updates the
     * grid and player position, checks for win condition, and saves the
     * state after each move.</p>
     * 
     * <p>If the move results in a win, the level is marked as completed
     * and the state is saved.</p>
     * 
     * <p>The method returns immediately if the game is paused or completed.</p>
     * 
     * <p>Valid deltas:</p>
     * <ul>
     *   <li>(-1, 0) - Move up</li>
     *   <li>(1, 0) - Move down</li>
     *   <li>(0, -1) - Move left</li>
     *   <li>(0, 1) - Move right</li>
     * </ul>
     *
     * @param deltaRow The change in row (-1, 0, or 1).
     * @param deltaCol The change in column (-1, 0, or 1).
     * @throws IllegalArgumentException if deltaRow or deltaCol are not in range [-1, 1].
     */
    void attemptMove(int deltaRow, int deltaCol);
    
    /**
     * Counts the number of remaining goals in the given grid.
     * 
     * <p>A goal is represented by cell value 2.</p>
     *
     * @param grid The grid to count goals in. Must not be null.
     * @return The number of remaining goals.
     * @throws NullPointerException if grid is null.
     */
    int countRemainingGoals(int[][] grid);
    
    // ========================================================================
    // Undo Functionality
    // ========================================================================
    
    /**
     * Reverses the last move.
     * 
     * <p>Pops the last state from the history and restores it. The completed
     * levels set is not affected by undo.</p>
     * 
     * <p>The method returns immediately if the game is paused, completed,
     * or if there is no history to undo.</p>
     */
    void undoMove();
    
    // ========================================================================
    // Reset Operations
    // ========================================================================
    
    /**
     * Resets the current level to its initial state.
     * 
     * <p>Reloads the level from the original data. The completed status
     * of the level is not changed.</p>
     */
    void resetCurrentLevel();
    
    /**
     * Resets the entire game: clears all progress, returns to level 1.
     * 
     * <p>This operation:</p>
     * <ul>
     *   <li>Clears the completed levels set</li>
     *   <li>Resets the current level index to 0</li>
     *   <li>Removes the saved state from persistent storage</li>
     *   <li>Stops the timer</li>
     * </ul>
     */
    void resetEntireGame();
    
    // ========================================================================
    // Level Navigation
    // ========================================================================
    
    /**
     * Moves to the next level, or wraps to the first if at the end.
     * 
     * <p>Saves the current state before switching.</p>
     * 
     * <p>The method returns immediately if the game is paused.</p>
     */
    void goToNextLevel();
    
    /**
     * Moves to the previous level, if possible.
     * 
     * <p>Saves the current state before switching.</p>
     * 
     * <p>The method returns immediately if the game is paused or if
     * already at the first level.</p>
     */
    void goToPreviousLevel();
    
    // ========================================================================
    // Timer Control
    // ========================================================================
    
    /**
     * Starts the timer if not already running.
     * 
     * <p>The timer increments every second and updates the timerSeconds
     * LiveData. The timer should start when the first move is made and
     * run until the level is completed or paused.</p>
     */
    void startTimer();
    
    /**
     * Stops the timer.
     * 
     * <p>Removes any pending timer updates and sets the running flag to false.</p>
     */
    void stopTimer();
    
    // ========================================================================
    // Pause Control
    // ========================================================================
    
    /**
     * Toggles the pause state.
     * 
     * <p>If pausing, stops the timer. If resuming and there have been moves,
     * starts the timer.</p>
     */
    void togglePause();
    
    // ========================================================================
    // Utility Methods
    // ========================================================================
    
    /**
     * Creates a snapshot of the current game state for persistence.
     *
     * @return A GameState object representing the current state.
     */
    GameState createStateSnapshot();
    
    /**
     * Checks if the current grid has no remaining goals (win condition).
     *
     * @param grid The grid to check. Must not be null.
     * @return True if all goals are covered (i.e., no cell with value 2).
     */
    boolean checkWin(int[][] grid);
}